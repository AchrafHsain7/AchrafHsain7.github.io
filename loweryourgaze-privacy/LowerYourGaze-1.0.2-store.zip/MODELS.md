# Models

| File | Source checkpoint | sha256 of source | sha256 of file |
|---|---|---|---|
| `models/lyg-n.onnx` | `yolov8n-oiv7.pt` | `3851dfbf39ed2a076b1f39215cc22dba64eb5646f282bf964703785b0bed6a41` | `b16b3df6e30ff9e0442799d6a2bbf2ae1feb7e1fac223577e6dea060b2a33906` |
| `models/lyg-s.onnx` | `yolov8s-oiv7.pt` | `4663086e1b8edbc4202a9ec589b03195ed149ef8aa8beeb4b503e0e35ff1731a` | `cfdaddeb58f92d04c40cd74731878f5e209d363c35b84c4a78082ca52348521a` |

Source: https://github.com/ultralytics/assets/releases/download/v8.2.0/ (Ultralytics YOLOv8 pretrained
on Open Images V7, 601 classes, AGPL-3.0).

No training or fine-tuning was done. `tools/export_pruned.py` keeps 36 of the 601 output channels
(people, body parts, statues and dolls, female-coded garments, general clothing; listed in
`src/shared/constants.js`), verifies that the kept outputs are numerically identical to the original
model's, and exports ONNX (opset 17, dynamic input size). To reproduce:

```
pip install ultralytics onnx onnxslim onnxruntime
python tools/export_pruned.py yolov8n-oiv7.pt models/lyg-n.onnx
python tools/export_pruned.py yolov8s-oiv7.pt models/lyg-s.onnx
```

Runtime: ONNX Runtime Web 1.31.1 (`vendor/ort/`), unmodified files from the npm package.


## Extra models (0.8, 0.9.1)

| File | Source | sha256 of file |
|---|---|---|
| `models/lyg-clip.onnx` | TinyCLIP ViT-40M/32 (text 19M, LAION-400M), `TinyCLIP-ViT-40M-32-Text-19M-LAION400M.pt` from github.com/wkcn/TinyCLIP-model-zoo releases; image encoder only, weights stored as float16, input RGB 0–255 at 224×224, output a unit-length 512-d embedding | `af2dc85ded8c744c1db1ac36e0640dea4d27f2a5e77419d2c0ba2f0c9c432e06` |
| `models/lyg-clip-text.bin` / `.json` | Text embeddings of the 50 whole-image prompts and 16 person-crop prompts, from the same model's text encoder; group ranges in the JSON | `3371d50d2de0e00c9ea7fd3244c59d2ffafb5c8c0baf5010dc5bc8a36da8d6db` |
| `models/lyg-clip-pca.bin` | Mean and 64 principal directions of the image embeddings of the test images (for the compact signature used by corrections) | `9c228546b41135f415bd339df9c14557f82e05d4cc745bb56622e5bc0c2137e3` |
| `models/lyg-face.onnx` | InsightFace `buffalo_s` / `det_500m.onnx` (SCRFD-500M face detector), unmodified | `5e4447f50245bbd7966bd6c0fa52938c61474a04ec7def48753668a9d8b4ea3a` |
| `models/lyg-face-gender.onnx` | InsightFace `buffalo_s` / `genderage.onnx`, unmodified | `4fde69b1c810857b88c64a335084f1c3fe8f01246c9a191b48c7bb756d6652fb` |

To reproduce the CLIP export: `lab/core/export_clip.py`. The weights of the decision (`src/shared/ensemble-data.js`)
are the lab's `final_tune2.py final` output of 2026-11-14 (`core/results/ensemble-data.new.js`), unchanged.
InsightFace models are released for non-commercial research use.
