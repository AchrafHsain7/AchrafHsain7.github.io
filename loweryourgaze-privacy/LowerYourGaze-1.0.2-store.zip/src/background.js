// LowerYourGaze — service worker: keeps the inference document alive and owns settings defaults.
// AGPL-3.0.
import { DEFAULTS, STORAGE_KEY } from './shared/constants.js';

let creating = null;
async function ensureOffscreen() {
    if (await chrome.offscreen.hasDocument()) return;
    creating ||= chrome.offscreen.createDocument({
        url: 'src/offscreen.html',
        reasons: ['WORKERS'],                     // the models run in a worker spawned by this document (0.19.4)
        justification: 'Decode images and run the on-device detector in a worker.',
    }).catch((error) => {
        // A concurrent creation is fine; anything else is a real failure.
        if (!/single offscreen/i.test(String(error?.message))) throw error;
    }).finally(() => { creating = null; });
    await creating;
}

async function readSettings() {
    const stored = await chrome.storage.local.get(STORAGE_KEY);
    return { ...DEFAULTS, ...(stored[STORAGE_KEY] || {}) };
}

// Settings are stored sparsely; every reader merges them over DEFAULTS, so nothing is written here.
chrome.runtime.onInstalled.addListener((details) => {
    ensureOffscreen().catch(() => {});
    // First install only (not updates): open the welcome page.
    if (details?.reason === 'install') chrome.tabs.create({ url: chrome.runtime.getURL('src/welcome.html') }).catch(() => {});
});
chrome.runtime.onStartup.addListener(() => { ensureOffscreen().catch(() => {}); });

// ------------------------------------------------------------------------------- messages
// The viewer's corrections do not pass through here any more: the backend holds the only copy of the list and applies every
// tab's choices one at a time (offscreen.js). 0.18 – 0.19.4 applied them here, to a list in the settings storage.
chrome.runtime.onMessage.addListener((msg, sender, respond) => {
    if (msg?.t === 'lyg-ensure') {
        ensureOffscreen().then(() => respond({ ok: true }), (error) => respond({ ok: false, error: String(error?.message || error) }));
        return true;
    }
    if (msg?.t === 'lyg-config') {
        readSettings().then((s) => respond({ model: s.model, threads: s.threads }));
        return true;
    }
});

// ------------------------------------------------------------------------------- menu and shortcuts
const MENU = [
    ['show-image', 'Show this image'],
    ['cover-image', 'Cover this image'],
    ['show-video', 'Show this video'],
    ['cover-video', 'Cover this video'],
    ['auto-video', 'Video: check it again (undo my choice)'],
    ['auto-any', 'Image: check it again (undo my choice)'],
    ['sep', null],
    ['site', 'Turn off / on for this site'],
];

function buildMenu() {
    chrome.contextMenus.removeAll(() => {
        for (const [id, title] of MENU) {
            chrome.contextMenus.create({
                id: `lyg-${id}`, contexts: ['all'], documentUrlPatterns: ['http://*/*', 'https://*/*', 'file:///*'],
                ...(title ? { title } : { type: 'separator' }),
            }, () => void chrome.runtime.lastError);
        }
    });
}
chrome.runtime.onInstalled.addListener(buildMenu);
chrome.runtime.onStartup.addListener(buildMenu);

async function toggleSite(url) {
    let host;
    try { const parsed = new URL(url); if (!/^https?:$/.test(parsed.protocol)) return; host = parsed.hostname.replace(/^www\./, ''); } catch { return; }
    const stored = (await chrome.storage.local.get(STORAGE_KEY))[STORAGE_KEY] || {};
    const sites = { ...(stored.sites || {}) };
    const paused = (stored.paused || []).filter((h) => h !== host);
    const wasOff = sites[host] === 'off' || (stored.paused || []).includes(host);
    if (wasOff) delete sites[host]; else sites[host] = 'off';
    await chrome.storage.local.set({ [STORAGE_KEY]: { ...stored, sites, paused } });
}

function choose(tabId, kind, mode, frameId) {
    const message = { t: 'lyg-choice', kind, mode, main: frameId === undefined };
    chrome.tabs.sendMessage(tabId, message, frameId === undefined ? {} : { frameId }).catch(() => {});
}

chrome.contextMenus.onClicked.addListener((info, tab) => {
    if (!tab?.id) return;
    const id = String(info.menuItemId).replace(/^lyg-/, '');
    if (id === 'site') { toggleSite(tab.url).catch(() => {}); return; }
    const [mode, kind] = id.split('-');
    choose(tab.id, kind, mode, info.frameId ?? 0);
});

chrome.commands.onCommand.addListener((command, tab) => {
    if (!tab?.id) return;
    if (command === 'toggle-site') toggleSite(tab.url).catch(() => {});
    else if (command === 'show-video') choose(tab.id, 'video', 'toggle');
    else if (command === 'cover-video') choose(tab.id, 'video', 'toggle-cover');     // pressed again: back to automatic (0.17)
});

// ------------------------------------------------------------------------------- toolbar icon
// Green shield while pictures are being filtered on the tab's site; terracotta when the extension is off or the site is.
const ICON = (state) => Object.fromEntries([16, 24, 32, 48, 128].map((s) => [s, `/icons/${state}/icon${s}.png`]));
function siteOff(settings, url) {
    try {
        const parsed = new URL(url || '');
        if (!/^https?:$/.test(parsed.protocol)) return false;
        const host = parsed.hostname.replace(/^www\./, '');
        return (settings.sites || {})[host] === 'off' || (settings.paused || []).includes(host);
    } catch { return false; }
}
async function paintIcon(tab, settings) {
    if (!tab?.id) return;
    settings ||= await readSettings();
    const on = settings.enabled && !siteOff(settings, tab.url);
    chrome.action.setIcon({ tabId: tab.id, path: ICON(on ? 'active' : 'inactive') }).catch(() => {});
}
async function paintAll() {
    const settings = await readSettings();
    for (const tab of await chrome.tabs.query({})) paintIcon(tab, settings);
}
chrome.tabs.onActivated.addListener(({ tabId }) => chrome.tabs.get(tabId).then((tab) => paintIcon(tab)).catch(() => {}));
chrome.tabs.onUpdated.addListener((tabId, change, tab) => { if (change.url || change.status === 'loading') paintIcon(tab); });
chrome.runtime.onInstalled.addListener(() => { paintAll().catch(() => {}); });
chrome.runtime.onStartup.addListener(() => { paintAll().catch(() => {}); });

// Model or thread choice changed: restart the detector.
chrome.storage.onChanged.addListener((changes, area) => {
    const change = area === 'local' && changes[STORAGE_KEY];
    if (!change) return;
    const before = change.oldValue || {}, after = change.newValue || {};
    paintAll().catch(() => {});
    if (before.model !== after.model || before.threads !== after.threads) {
        chrome.runtime.sendMessage({ t: 'lyg-reload-backend' }).catch(() => {});
    }
});
