// LowerYourGaze — runs in the page's own JavaScript world. It only announces things the content
// script cannot observe from outside: new shadow roots, and drawing on canvases. AGPL-3.0.
(() => {
    const proto = Element.prototype;
    const original = proto.attachShadow;
    if (typeof original !== 'function' || original.__lyg) return;
    function attachShadow(init) {
        const root = original.call(this, init);
        try { this.dispatchEvent(new CustomEvent('lyg-shadow', { bubbles: true, composed: true })); } catch {}
        return root;
    }
    attachShadow.__lyg = true;
    try { Object.defineProperty(proto, 'attachShadow', { value: attachShadow, writable: true, configurable: true }); } catch {}

    // Pictures reach a 2D canvas through drawImage or putImageData. Announce it, at most every 150 ms per canvas.
    const last = new WeakMap();
    const announce = (canvas) => {
        if (!canvas || typeof canvas.dispatchEvent !== 'function' || !canvas.isConnected) return;
        const now = performance.now();
        if (now - (last.get(canvas) || 0) < 150) return;
        last.set(canvas, now);
        // After the current drawing burst, so the content script sees the finished picture.
        setTimeout(() => { try { canvas.dispatchEvent(new CustomEvent('lyg-canvas', { bubbles: true, composed: true })); } catch {} }, 0);
    };
    const ctx = globalThis.CanvasRenderingContext2D && CanvasRenderingContext2D.prototype;
    for (const name of ['drawImage', 'putImageData']) {
        const method = ctx && ctx[name];
        if (typeof method !== 'function') continue;
        const wrapped = { [name](...args) { const result = method.apply(this, args); try { announce(this.canvas); } catch {} return result; } }[name];
        try { Object.defineProperty(ctx, name, { value: wrapped, writable: true, configurable: true }); } catch {}
    }
})();
