// LowerYourGaze — inference backend. Runs in the extension's offscreen document.
// One detector session shared by every tab; requests arrive over runtime Ports. AGPL-3.0.
import { RunWatchdog } from './shared/watchdog.js';
import { decode, mergeAnalyses } from './shared/decision.js';
import { mergeExtras, wantsSecondLook, personBoxes, earlyExit, protectedHit } from './shared/ensemble.js';
import { ENSEMBLE } from './shared/ensemble-data.js';
import { MODEL_VERSION } from './shared/constants.js';
import { Limiter, Flights } from './shared/limiter.js';
import { inputSize } from './shared/sizing.js';
import { record, forget, confirmed, summarize, wireSummary, FEEDBACK_MAX } from './shared/feedback.js';

const MODEL_INPUT = 'images';
const MODEL_OUTPUT = 'output0';
const FETCH_TIMEOUT_MS = 15000;
const MAX_IMAGE_BYTES = 40 * 1024 * 1024;
const FAST_MS = 150;        // 480px inference at or under this → tier "fast"
const UPGRADE_MS = 110;     // nano 480px inference at or under this → try the larger model
const BIG_MODEL_MAX_MS = 330;   // keep the larger model only if its 480px inference stays under this
const MAX_ANIMATION_SAMPLES = 8;

let ort = null;
let session = null;
let ready = null;
const state = { backend: null, model: null, tier: 'slow', threads: 1, bench: null, error: null, stage: 'boot' };
const stats = { runs: 0, totalMs: 0, hits: 0, misses: 0, errors: 0, recent: [], extraErrors: 0 };      // shown in the panel's status line

// Nothing about browsing is recorded or sent anywhere. Pre-release test builds kept a local log in this browser; it is deleted.
try { indexedDB.deleteDatabase('lyg-diag'); } catch {}
const r1 = (v) => Math.round(v * 10) / 10;

// ---------------------------------------------------------------------------- runtime setup
async function getConfig() {
    try { return (await chrome.runtime.sendMessage({ t: 'lyg-config' })) || {}; } catch { return {}; }
}

const PROXY = true;

// The models run on the CPU (multi-threaded WebAssembly). A graphics-card path existed but was never tested and was removed (0.19.4).
async function loadOrt() {
    const mod = await import('../vendor/ort/ort.wasm.bundle.min.mjs');
    const api = mod.InferenceSession ? mod : mod.default;
    api.env.wasm.wasmPaths = chrome.runtime.getURL('vendor/ort/');
    api.env.wasm.numThreads = state.threads;
    // CPU models run in ONNX Runtime's own worker, not on this page's main thread: every page of the extension (the panel,
    // the welcome page, this backend) shares one main thread, so model loading and inference here froze the panel.
    api.env.wasm.proxy = PROXY;
    api.env.logLevel = 'error';
    return api;
}

async function createSession(model) {
    const api = await loadOrt();
    const sess = await api.InferenceSession.create(chrome.runtime.getURL(`models/lyg-${model}.onnx`), {
        executionProviders: ['wasm'],
        graphOptimizationLevel: 'all',
    });
    return { api, sess };
}

async function timeRun(api, sess, size, repeats = 2) {
    let best = Infinity;
    for (let i = 0; i < repeats + 1; i++) {      // first run includes one-off setup
        // A fresh input each run: with the models in a worker, the input's memory moves to the worker and cannot be reused.
        const input = new api.Tensor('float32', new Float32Array(3 * size * size).fill(0.45), [1, 3, size, size]);
        const t0 = performance.now();
        await sess.run({ [MODEL_INPUT]: input });
        if (i > 0) best = Math.min(best, performance.now() - t0);
    }
    return best;
}

// A session's memory (the model and its work space, 20–170 MB) is given back only when the session is released. A session that
// was replaced is released once no check is running: a check keeps the session it started with (see infer).
function retire(old) {
    if (inferSlot.active) { setTimeout(() => retire(old), 1000); return; }
    try { Promise.resolve(old.release()).catch(() => {}); } catch {}
}

// The backend starts once per page. A change of detector or thread count reloads the page (see 'lyg-reload-backend'): the
// thread count is fixed when the WebAssembly runtime starts, and a reload gives the old models' memory back in one step.
async function init() {
    const cfg = await getConfig();
    const cores = navigator.hardwareConcurrency || 2;
    state.threads = self.crossOriginIsolated ? Math.max(1, Math.min(cores >= 12 ? 6 : 4, cores - 1)) : 1;
    if (self.crossOriginIsolated && Number.isInteger(cfg.threads) && cfg.threads > 0) state.threads = Math.min(8, cfg.threads);
    if (safeStart) state.threads = 1;                      // second restart after a hung start: the simplest configuration

    const firstModel = cfg.model === 's' ? 's' : 'n';
    state.stage = 'create';
    const made = await createSession(firstModel);
    await timeRun(made.api, made.sess, 320, 0);
    state.stage = 'bench';
    let ms = await timeRun(made.api, made.sess, 480);
    ort = made.api; session = made.sess;
    state.backend = 'wasm'; state.model = firstModel; state.bench = Math.round(ms);
    state.tier = ms <= FAST_MS ? 'fast' : 'slow';
    ema320 = ms * (320 / 480) ** 2;
    // The extra models are optional: without them the older rule decides.
    state.stage = 'extras';
    try { extras = await loadExtras(made.api); state.extras = true; }
    catch (error) { extras = null; state.extras = false; state.extrasError = String(error?.message || error); console.warn('LYG: extra models not loaded', error); }
    state.stage = 'ready';

    if (cfg.model !== 'n' && cfg.model !== 's' && ms <= UPGRADE_MS) {
        // Fast machine: switch to the more accurate model once it has loaded.
        // While it loads, checks wait behind it in the model worker: the watchdog gives them longer (watchdog.whileLoading).
        watchdog.whileLoading(async () => {
            const big = await createSession('s');
            const bigMs = await timeRun(big.api, big.sess, 480);
            if (bigMs > BIG_MODEL_MAX_MS) { retire(big.sess); return; }
            const small = session;
            ort = big.api; session = big.sess;
            retire(small);
            state.model = 's'; state.bench = Math.round(bigMs);
            state.tier = bigMs <= FAST_MS ? 'fast' : 'slow';
            ema320 = bigMs * (320 / 480) ** 2;
        }).catch((error) => console.warn('LYG: larger model not loaded', error));
    }
}

// ---------------------------------------------------------------------------- run-time watchdog
// After a good start the model runs are watched (shared/watchdog.js: hung or repeatedly failing runs reload this page,
// with bounded restarts). Separate from the start-up count above, which a good start clears.
const watchdog = new RunWatchdog({
    store: { get: () => sessionStorage.getItem('lygRunRestarts'), set: (v) => sessionStorage.setItem('lygRunRestarts', v) },
    restart: (reason) => { console.warn(`LYG: ${reason}; restarting the backend`); location.reload(); },
    onGiveUp: (reason) => { console.warn(`LYG: ${reason}; restart limit reached, pictures stay covered`); state.runError = reason; },
    onRecover: () => { state.runError = null; },
});
setInterval(() => watchdog.tick(), 5000);

/** One model run, watched. */
async function watchedInfer(...args) {
    const id = watchdog.begin();
    try {
        const out = await infer(...args);
        watchdog.end(id, true);
        return out;
    } catch (error) {
        watchdog.end(id, false, error);
        throw error;
    }
}

// ---------------------------------------------------------------------------- start-up watchdog
// A start that hangs (seen once on a cold first start on Windows: the panel froze and videos stayed covered until the browser
// restarted) or fails reloads this page — a fresh context and a fresh model worker. The first reload keeps the settings, the
// second uses one thread; after that the error is reported and everything stays covered. The count lives in sessionStorage,
// which survives a reload of this page and is cleared once a start succeeds.
const START_TIMEOUT_MS = 90000;
const MAX_RESTARTS = 2;
const restarts = Number(sessionStorage.getItem('lygRestarts')) || 0;
const safeStart = restarts >= 2;
state.restarts = restarts;

function restartPage(reason) {
    if (restarts >= MAX_RESTARTS) {
        state.error = state.error || reason;
        return;
    }
    console.warn(`LYG: ${reason}; restarting the backend (${restarts + 1} of ${MAX_RESTARTS})`);
    sessionStorage.setItem('lygRestarts', String(restarts + 1));
    location.reload();
}

function start() {
    let settled = false;
    const startTimer = setTimeout(() => { if (!settled) restartPage(`start-up took over ${START_TIMEOUT_MS / 1000} s`); }, START_TIMEOUT_MS);
    ready = init().then(() => {
        settled = true; clearTimeout(startTimer);
        sessionStorage.removeItem('lygRestarts');
    }, (error) => {
        settled = true; clearTimeout(startTimer);
        state.error = String(error?.message || error);
        console.error('LYG: backend failed to start', error);
        setTimeout(() => restartPage('start-up failed'), 3000);
        throw error;
    });
    ready.catch(() => {});
    return ready;
}
start();

// ---------------------------------------------------------------------------- verdict cache
const MEM_LIMIT = 4000;
const IDB_LIMIT = 30000;
const PRUNE_EVERY = 2000;       // saved results between two prunes
const mem = new Map();
let dbPromise = null;

function db() {
    dbPromise ||= new Promise((resolve) => {
        try {
            // Version 2: rows are keyed by a one-way hash of the picture's address, so no address is kept on disk.
            // Rows from version 1 were keyed by the address itself and are dropped.
            // Version 3 adds the learning memory ('fb', one row per correction) and 'meta'; the saved check results are kept.
            const open = indexedDB.open('lyg', 3);
            open.onupgradeneeded = (event) => {
                const handle = open.result;
                if (event.oldVersion < 2) {
                    if (handle.objectStoreNames.contains('analysis')) handle.deleteObjectStore('analysis');
                    handle.createObjectStore('analysis', { keyPath: 'k' }).createIndex('t', 't');
                }
                if (!handle.objectStoreNames.contains('fb')) handle.createObjectStore('fb', { keyPath: 'k' });
                if (!handle.objectStoreNames.contains('meta')) handle.createObjectStore('meta', { keyPath: 'k' });
            };
            // An open that stays blocked (another page of the extension holds an older version) is given up after a while:
            // the backend then runs without saved results rather than not at all.
            let given = false;
            const giveUp = setTimeout(() => { given = true; resolve(null); }, 8000);
            open.onsuccess = () => {
                clearTimeout(giveUp);
                if (given) { open.result.close(); return; }
                open.result.onversionchange = () => open.result.close();
                resolve(open.result);
            };
            open.onerror = () => { clearTimeout(giveUp); resolve(null); };
        } catch { resolve(null); }
    });
    return dbPromise;
}

/** One request or one whole transaction as a promise; null when the database cannot be used. */
function idb(stores, mode, work) {
    return db().then((handle) => new Promise((resolve) => {
        if (!handle) { resolve(null); return; }
        try {
            const tx = handle.transaction(stores, mode);
            const result = work(tx);
            tx.oncomplete = () => resolve(result && 'result' in result ? result.result : true);
            tx.onabort = tx.onerror = () => resolve(null);
        } catch { resolve(null); }
    }));
}

function memSet(key, analysis) {
    mem.delete(key);
    mem.set(key, analysis);
    if (mem.size > MEM_LIMIT) mem.delete(mem.keys().next().value);
}

/** The disk key of a picture: SHA-256 of its in-memory key (address or pixel hash), first 128 bits in hex. */
async function diskKey(key) {
    const digest = new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(key)));
    let hex = '';
    for (let i = 0; i < 16; i++) hex += digest[i].toString(16).padStart(2, '0');
    return hex;
}

async function cacheGet(key) {
    const hit = mem.get(key);
    if (hit) { memSet(key, hit); return hit; }
    const handle = await db();
    if (!handle) return null;
    const id = await diskKey(key);
    return new Promise((resolve) => {
        try {
            const request = handle.transaction('analysis').objectStore('analysis').get(id);
            request.onsuccess = () => {
                const row = request.result;
                if (row && row.a && row.a.v === MODEL_VERSION) { memSet(key, row.a); resolve(row.a); } else resolve(null);
            };
            request.onerror = () => resolve(null);
        } catch { resolve(null); }
    });
}

let putsSincePrune = 0;
async function cachePut(key, analysis) {
    memSet(key, analysis);
    const handle = await db();
    if (!handle) return;
    const id = await diskKey(key);
    try { handle.transaction('analysis', 'readwrite').objectStore('analysis').put({ k: id, a: analysis, t: Date.now() }); } catch {}
    // The backend can run for weeks without a restart: the limit is also enforced as results are added, not only at start.
    if (++putsSincePrune >= PRUNE_EVERY) { putsSincePrune = 0; cachePrune(); }
}

async function cachePrune() {
    const handle = await db();
    if (!handle) return;
    try {
        const store = handle.transaction('analysis', 'readwrite').objectStore('analysis');
        const count = store.count();
        count.onsuccess = () => {
            let excess = count.result - IDB_LIMIT;
            if (excess <= 0) return;
            store.index('t').openCursor().onsuccess = (event) => {
                const cursor = event.target.result;
                if (!cursor || excess-- <= 0) return;
                cursor.delete(); cursor.continue();
            };
        };
    } catch {}
}
setTimeout(cachePrune, 20000);

// ---------------------------------------------------------------------------- scheduling
// Three queues (shared/limiter.js). Lower priority number runs first; priority 0 (video frames) may use one slot beyond the
// limit. Work from a tab that is not on screen is parked: it waits, whatever its priority, until the tab is visible again.
const prepareSlots = new Limiter(3);   // bounds decoded tensors held in memory
// Downloads run outside the preparation slots (system lab: a download took 161 ms at the median and held a slot while the
// models sat idle 62 % of the time). Up to 8 at once, by priority.
const fetchSlots = new Limiter(8);
const inferSlot = new Limiter(1);      // the session is not re-entrant

// Workload control (0.15). The models run on this document's thread: while a picture is being judged, a video sample waits —
// in a lab measurement, page pictures (5 a second) pushed video samples' capture → verdict time from 208 to 677 ms at the
// 95th percentile, which froze and blurred videos that the models judged clear. While a video was sampled within the last
// second, pictures get at most VIDEO_IMAGE_SHARE of the model time: after a picture's models ran for d ms, the next picture
// waits d · (1 − share) / share ms. Video samples are not held (priority 0 takes a slot beyond the limit). The share is a design
// choice, not a fitted value: pictures still progress, the video keeps the larger part.
const VIDEO_IMAGE_SHARE = 0.4, VIDEO_ACTIVE_MS = 1000;
let lastVideoAt = -1e9, imageGapUntil = 0;
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
async function imageTurn(isCancelled) {
    for (;;) {
        const now = performance.now();
        if (now - lastVideoAt > VIDEO_ACTIVE_MS || now >= imageGapUntil) return;
        await sleep(Math.max(5, Math.min(50, imageGapUntil - now)));
        if (isCancelled()) throw new Error('cancelled');
    }
}
function imageDone(ms) {
    if (performance.now() - lastVideoAt <= VIDEO_ACTIVE_MS) imageGapUntil = performance.now() + ms * (1 - VIDEO_IMAGE_SHARE) / VIDEO_IMAGE_SHARE;
}

// ---------------------------------------------------------------------------- image → tensor
const canvases = new Map();
function canvasFor(size) {
    let entry = canvases.get(size);
    if (!entry) {
        const canvas = new OffscreenCanvas(size, size);
        entry = { canvas, ctx: canvas.getContext('2d', { willReadFrequently: true, alpha: false }) };
        canvases.set(size, entry);
    }
    return entry;
}

// Transparent pixels (cut-out renders, line drawings on a transparent background) are laid on mid-gray before any
// model sees them: on the opaque canvases they would otherwise turn black (black line art vanishes) or keep the
// previous picture's pixels. The lab composites the same way (lab/core/alpha_fix.py: gray beat white and black).
const MATTE = 'rgb(128,128,128)';

function toTensor(source, size) {
    const width = source.displayWidth || source.width;
    const height = source.displayHeight || source.height;
    if (!width || !height) throw new Error('empty image');
    const scale = Math.min(size / width, size / height);
    const nw = Math.max(1, Math.round(width * scale)), nh = Math.max(1, Math.round(height * scale));
    const padX = Math.floor((size - nw) / 2), padY = Math.floor((size - nh) / 2);
    const { ctx } = canvasFor(size);
    ctx.fillStyle = 'rgb(114,114,114)';
    ctx.fillRect(0, 0, size, size);
    ctx.fillStyle = MATTE;
    ctx.fillRect(padX, padY, nw, nh);
    ctx.imageSmoothingQuality = 'medium';
    ctx.drawImage(source, padX, padY, nw, nh);
    const rgba = ctx.getImageData(0, 0, size, size).data;
    const area = size * size;
    const data = new Float32Array(3 * area);
    for (let i = 0, p = 0; i < area; i++, p += 4) {
        data[i] = rgba[p] / 255;
        data[area + i] = rgba[p + 1] / 255;
        data[2 * area + i] = rgba[p + 2] / 255;
    }
    // A frame with no luminance variation carries no evidence either way (DRM, fades, placeholders).
    let lo = 255, hi = 0;
    const stepY = Math.max(1, Math.floor(nh / 24)), stepX = Math.max(1, Math.floor(nw / 24));
    for (let y = padY; y < padY + nh; y += stepY) {
        for (let x = padX; x < padX + nw; x += stepX) {
            const p = (y * size + x) * 4;
            const lum = (rgba[p] * 3 + rgba[p + 1] * 6 + rgba[p + 2]) / 10;
            if (lum < lo) lo = lum;
            if (lum > hi) hi = lum;
        }
    }
    return { data, blank: hi - lo < 14, lb: { size, scale, padX, padY, width, height } };
}

async function fetchImage(url) {
    const attempt = async (credentials) => {
        const response = await fetch(url, { credentials, signal: AbortSignal.timeout(FETCH_TIMEOUT_MS) });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const length = Number(response.headers.get('content-length') || 0);
        if (length > MAX_IMAGE_BYTES) throw new Error('image too large');
        const blob = await response.blob();
        if (blob.size > MAX_IMAGE_BYTES) throw new Error('image too large');
        return blob;
    };
    try { return await attempt('omit'); }
    catch (first) {
        if (first?.name === 'TimeoutError') throw first;
        return attempt('include');          // cookie-gated images
    }
}

// Formats that can carry an animation (0.17: PNG/APNG and AVIF too — 0.16 sent their original bytes but decoded them as one
// still frame — review of 0.16, finding 6).
const ANIMATABLE = /image\/(gif|webp|png|apng|avif)/i;

/**
 * Decode a picture into the frames to judge. An animation gives evenly spaced frames (every frame of a short one). Explicit
 * policy for an animatable format whose animation cannot be read (no ImageDecoder, unsupported type, decode error): the first
 * frame is judged and the result says so ({ animUnread: true }) — the page then treats the picture as changing content and
 * checks it again later (content/main.js), so one still frame never clears the whole animation for good.
 */
async function decodeFrames(blob, isVideoFrame) {
    const type = blob.type || '';
    if (/svg/i.test(type)) return { skip: 'svg' };
    if (!isVideoFrame && ANIMATABLE.test(type)) {
        let readable = false;
        try {
            if (typeof ImageDecoder === 'function' && await ImageDecoder.isTypeSupported(type)) {
                const decoder = new ImageDecoder({ data: await blob.arrayBuffer(), type });
                await decoder.tracks.ready;
                const track = decoder.tracks.selectedTrack;
                readable = true;
                if (track?.animated) {
                    await decoder.completed;
                    const count = track.frameCount;
                    // Every frame of a short animation; otherwise evenly spaced samples.
                    const samples = Math.min(count, MAX_ANIMATION_SAMPLES);
                    const picks = [...new Set(Array.from({ length: samples }, (_, i) => (samples === 1 ? 0 : Math.round(i * (count - 1) / (samples - 1)))))];
                    const frames = [];
                    for (const frameIndex of picks) frames.push((await decoder.decode({ frameIndex })).image);
                    decoder.close();
                    return { sources: frames };
                }
                decoder.close();
            }
        } catch { readable = false; }
        if (!readable) return { sources: [await createImageBitmap(blob)], animUnread: true };
    }
    return { sources: [await createImageBitmap(blob)] };
}

// Moving average of detector time, normalised to a 320 px input.
let ema320 = 0;
function noteSpeed(ms, size) {
    const norm = ms * (320 / size) ** 2;
    ema320 = ema320 ? ema320 + (norm - ema320) * 0.12 : norm;
}
// Work waiting for a turn. Parked work (hidden tabs) and work whose requester has gone away are not load.
const queueDepth = () => fetchSlots.depth + prepareSlots.depth + inferSlot.depth;
const pumpAll = () => { fetchSlots.pump(); prepareSlots.pump(); inferSlot.pump(); };
const sweepAll = () => { fetchSlots.sweep(); prepareSlots.sweep(); inferSlot.sweep(); };

/** Detector input size for a picture the backend downloads itself (the page names the size for pixels it sends). */
const chooseSize = (naturalLongest) => inputSize(naturalLongest, ema320, queueDepth());

// ---------------------------------------------------------------------------- extra signals
// Two more models run on every image and video frame: a CLIP image encoder compared against text
// prompts, and a face detector with a face-gender classifier. Their outputs go into the analysis:
//   x  [clip woman, clip group, clip man, clip no-people, clip text-like, face female, face score, face male]
//   e  the CLIP embedding reduced to 64 numbers (used to learn from the viewer's corrections)
//   c  [max P(woman), min P(man)] over the detected person crops — the second look, only for unsure images
// Request field x: 0 detector only, 1 + CLIP (video frames), 2 + face gender (images), 3 + second look always.
// They always run on the CPU path (WebAssembly), whatever the detector uses.
let extras = null;          // { clip, face, gender, text, meta } once loaded
const FACE_SIZE = 640, FACE_MIN = 0.3, FACE_MAX = 8, FACE_NMS = 0.4;
const round3 = (v) => Math.round(v * 1000) / 1000;

async function loadExtras(api) {
    const open = (name) => api.InferenceSession.create(chrome.runtime.getURL(`models/${name}`), { executionProviders: ['wasm'], graphOptimizationLevel: 'all' });
    const [clip, face, gender, meta, bin, pca] = await Promise.all([
        open('lyg-clip.onnx'), open('lyg-face.onnx'), open('lyg-face-gender.onnx'),
        fetch(chrome.runtime.getURL('models/lyg-clip-text.json')).then((r) => r.json()),
        fetch(chrome.runtime.getURL('models/lyg-clip-text.bin')).then((r) => r.arrayBuffer()),
        fetch(chrome.runtime.getURL('models/lyg-clip-pca.bin')).then((r) => r.arrayBuffer()),
    ]);
    return { clip, face, gender, meta, text: new Float32Array(bin), pca: new Float32Array(pca) };
}

function pixelsOf(ctx, width, height, scale, shift) {
    const rgba = ctx.getImageData(0, 0, width, height).data, area = width * height, data = new Float32Array(3 * area);
    for (let i = 0, p = 0; i < area; i++, p += 4) {
        data[i] = rgba[p] * scale + shift;
        data[area + i] = rgba[p + 1] * scale + shift;
        data[2 * area + i] = rgba[p + 2] * scale + shift;
    }
    return data;
}

/** CLIP image embedding of the whole source or of one region, squashed to the encoder's own input size (meta.image_size). */
async function embed(source, sx, sy, sw, sh) {
    const S = extras.meta.image_size || 224, { ctx } = canvasFor(S);
    ctx.fillStyle = MATTE;
    ctx.fillRect(0, 0, S, S);
    ctx.imageSmoothingQuality = 'high';
    if (sw) ctx.drawImage(source, sx, sy, sw, sh, 0, 0, S, S); else ctx.drawImage(source, 0, 0, S, S);
    const out = await extras.clip.run({ pixels: new ort.Tensor('float32', pixelsOf(ctx, S, S, 1, 0), [1, 3, S, S]) });
    return out.embedding.data;
}

/** Softmax over a block of text prompts; returns the probabilities. */
function promptProbs(e, offset, count) {
    const { dim, scale } = extras.meta, bias = extras.meta.bias || 0, text = extras.text, probs = new Float64Array(count);
    let top = -Infinity, sum = 0;
    for (let k = 0; k < count; k++) {
        let dot = 0;
        for (let i = 0, o = (offset + k) * dim; i < dim; i++) dot += e[i] * text[o + i];
        probs[k] = scale * dot + bias;
        if (probs[k] > top) top = probs[k];
    }
    for (let k = 0; k < count; k++) { probs[k] = Math.exp(probs[k] - top); sum += probs[k]; }
    for (let k = 0; k < count; k++) probs[k] /= sum;
    return probs;
}

/** CLIP on the whole image: mass of the prompt groups woman / group / man / no people / text-like, and the reduced embedding. */
async function clipSignals(source) {
    const e = await embed(source), { whole, dim, pca } = extras.meta, probs = promptProbs(e, 0, whole.count);
    const mass = ([from, to]) => { let m = 0; for (let k = from; k < to; k++) m += probs[k]; return m; };
    // Reduced embedding: centre, project, scale to unit length, store as small integers.
    const P = extras.pca, reduced = new Array(pca), g = whole.groups;
    let norm = 0;
    for (let j = 0; j < pca; j++) {
        let v = 0;
        for (let i = 0, o = dim + j * dim; i < dim; i++) v += (e[i] - P[i]) * P[o + i];
        reduced[j] = v; norm += v * v;
    }
    norm = Math.sqrt(norm) || 1;
    const out = { x: [mass(g.w), mass(g.g), mass(g.m), mass(g.n), mass(g.t)], e: reduced.map((v) => Math.round(127 * v / norm)) };
    // Probability mass on the protected descriptions (lingerie, nudity, immodest clothing; see ensemble.js protectedHit).
    const protect = extras.meta.protect;
    if (protect && Array.isArray(protect.ranges)) out.pr = round3(protect.ranges.reduce((sum, range) => sum + mass(range), 0));
    return out;
}

/** Second look: CLIP gender on the detected person crops. Returns [max P(woman), min P(man)] or null. */
async function cropSignals(source, analysis) {
    const width = source.displayWidth || source.width, height = source.displayHeight || source.height, { crop } = extras.meta;
    let female = 0, male = 1, used = 0;
    for (const [x1, y1, x2, y2] of personBoxes(analysis)) {
        const bw = (x2 - x1) * width, bh = (y2 - y1) * height;
        const left = Math.max(0, Math.floor(x1 * width - 0.08 * bw)), top = Math.max(0, Math.floor(y1 * height - 0.08 * bh));
        const right = Math.min(width, Math.floor(x2 * width + 0.08 * bw)), bottom = Math.min(height, Math.floor(y2 * height + 0.08 * bh));
        if (right - left < 8 || bottom - top < 8) continue;
        const probs = promptProbs(await embed(source, left, top, right - left, bottom - top), crop.offset, crop.count);
        let woman = 0;
        for (let k = crop.woman[0]; k < crop.woman[1]; k++) woman += probs[k];
        female = Math.max(female, woman); male = Math.min(male, 1 - woman); used++;
    }
    return used ? [round3(female), round3(male)] : null;
}

/** Faces and their gender: [max score × P(female), max score, max score × P(male)]. */
async function faceSignals(source) {
    const width = source.displayWidth || source.width, height = source.displayHeight || source.height;
    const S = FACE_SIZE, sc = Math.min(S / width, S / height), nw = Math.max(1, Math.round(width * sc)), nh = Math.max(1, Math.round(height * sc));
    const { ctx } = canvasFor(S);
    ctx.fillStyle = '#000';
    ctx.fillRect(0, 0, S, S);
    ctx.fillStyle = MATTE;
    ctx.fillRect(0, 0, nw, nh);
    ctx.imageSmoothingQuality = 'medium';
    ctx.drawImage(source, 0, 0, nw, nh);
    const session = extras.face;
    const out = await session.run({ [session.inputNames[0]]: new ort.Tensor('float32', pixelsOf(ctx, S, S, 1 / 128, -127.5 / 128), [1, 3, S, S]) });
    const found = [];
    [8, 16, 32].forEach((stride, level) => {
        const scores = out[session.outputNames[level]].data, boxes = out[session.outputNames[level + 3]].data, n = S / stride;
        for (let i = 0; i < scores.length; i++) {
            if (scores[i] < FACE_MIN) continue;
            const cell = i >> 1, cx = (cell % n) * stride, cy = Math.floor(cell / n) * stride;         // two anchors per cell
            found.push([(cx - boxes[4 * i] * stride) / sc, (cy - boxes[4 * i + 1] * stride) / sc, (cx + boxes[4 * i + 2] * stride) / sc, (cy + boxes[4 * i + 3] * stride) / sc, scores[i]]);
        }
    });
    found.sort((a, b) => b[4] - a[4]);
    const kept = [];
    for (const f of found) {
        if (kept.length >= FACE_MAX) break;
        const overlaps = kept.some((k) => {
            const iw = Math.min(k[2], f[2]) - Math.max(k[0], f[0]), ih = Math.min(k[3], f[3]) - Math.max(k[1], f[1]);
            if (iw <= 0 || ih <= 0) return false;
            const inter = iw * ih;
            return inter / ((k[2] - k[0]) * (k[3] - k[1]) + (f[2] - f[0]) * (f[3] - f[1]) - inter) >= FACE_NMS;
        });
        if (!overlaps) kept.push(f);
    }
    let female = 0, best = 0, male = 0;
    const crop = canvasFor(96).ctx;
    for (const [x1, y1, x2, y2, score] of kept) {
        const side = Math.max(x2 - x1, y2 - y1) * 1.5, cx = (x1 + x2) / 2, cy = (y1 + y2) / 2, k = 96 / side;
        crop.fillStyle = '#000';
        crop.fillRect(0, 0, 96, 96);
        crop.fillStyle = MATTE;
        crop.fillRect(48 - cx * k, 48 - cy * k, width * k, height * k);
        crop.imageSmoothingQuality = 'medium';
        crop.drawImage(source, 48 - cx * k, 48 - cy * k, width * k, height * k);
        const g = extras.gender, res = await g.run({ [g.inputNames[0]]: new ort.Tensor('float32', pixelsOf(crop, 96, 96, 1, 0), [1, 3, 96, 96]) });
        const p = res[g.outputNames[0]].data, pf = 1 / (1 + Math.exp(p[1] - p[0]));                    // index 0 = female
        female = Math.max(female, score * pf); male = Math.max(male, score * (1 - pf)); best = Math.max(best, score);
    }
    return [female, best, male];
}

/** Face (+ second look) after CLIP: the rest of the extra signals for a still image. */
async function restSignals(source, level, analysis, clip, vid = false) {
    const face = level >= 2 ? await faceSignals(source) : [];
    analysis.x = [...clip.x, ...face].map(round3);
    analysis.e = clip.e;
    if (clip.pr !== undefined) analysis.pr = clip.pr;
    if (level >= 3 || (level >= 2 && !vid && wantsSecondLook(analysis))) {      // video frames: no second look (one sample must stay short)
        const c = await cropSignals(source, analysis);
        if (c) analysis.c = c;
    }
}

async function extraSignals(source, level, analysis, vid = false) {
    const clip = await clipSignals(source);
    await restSignals(source, level, analysis, clip, vid);
}

const markProtected = (analysis) => { if (protectedHit(analysis, extras?.meta?.protect)) analysis.pc = 1; return analysis; };
const noteTime = (ms) => { stats.recent.push(Math.round(ms)); if (stats.recent.length > 50) stats.recent.shift(); };

/** @param {{model?: number}} tm  receives the models' own time for this frame, ms (it sets the video sample quality, 0.15) */
async function infer(frame, source, level = 2, tm = {}, vid = false) {
    const t0 = performance.now();
    // The detector session and its name are taken once: a model switch during this request cannot mix two models (0.16).
    const det = session, detApi = ort, detModel = state.model;
    const done = (result) => { const ms = performance.now() - t0; noteTime(ms); tm.model = r1(ms); return result; };
    // Still images with every model: CLIP first. A picture CLIP alone is sure of — or protected content — stops here,
    // without the detector (system lab: about a third less model time at the same women missed).
    let clip = null;
    if (extras && level >= 2 && !frame.blank && source && ENSEMBLE.cascade) {
        try {
            clip = await clipSignals(source);
            const first = { v: MODEL_VERSION, s: frame.lb.size, d: detModel, persons: [], parts: [], x: clip.x.map(round3), e: clip.e };
            if (clip.pr !== undefined) first.pr = clip.pr;
            markProtected(first);
            if (first.pc || earlyExit(first, 1) === 'cover') { first.ex = 1; return done(first); }
        } catch (error) { clip = null; stats.extraErrors++; }
    }
    const td = performance.now();
    const output = await det.run({ [MODEL_INPUT]: new detApi.Tensor('float32', frame.data, [1, 3, frame.lb.size, frame.lb.size]) });
    const tensor = output[MODEL_OUTPUT];
    const analysis = decode(tensor.data, tensor.dims[2], frame.lb);
    if (frame.blank) analysis.blank = true;
    const ms = performance.now() - td;
    noteSpeed(ms, frame.lb.size);
    stats.runs++; stats.totalMs += ms;
    analysis.d = detModel;
    if (extras && level > 0 && !frame.blank && source) {
        try {
            if (clip) {
                analysis.x = clip.x.map(round3); analysis.e = clip.e;
                if (clip.pr !== undefined) analysis.pr = clip.pr;
                markProtected(analysis);
                if (analysis.pc || earlyExit(analysis, 2)) analysis.ex = 2;
                else await restSignals(source, level, analysis, clip, vid);
            } else await extraSignals(source, level, analysis, vid);
            markProtected(analysis);
        } catch (error) { stats.extraErrors++; if (stats.extraErrors <= 3) console.warn('LYG: extra signals failed', error); }
    }
    return done(analysis);
}

// ---------------------------------------------------------------------------- one picture, one check
// The same picture is often on a page many times (avatars in a thread, a logo in the header and the footer) and in several
// tabs. While a check of a picture is under way, later requests for it wait for that check and then take its result from
// the saved results, exactly as a request arriving a moment later would. 0.19.4 looked in the saved results only when a
// request arrived: 60 pictures with 6 addresses cost 60 downloads and 60 model runs, and two copies of one picture on a page
// could be judged at different sizes.
const flights = new Flights(() => pumpAll());       // picture key → the check under way (shared/limiter.js)

/** Does a saved result answer this request? It must carry every model the request asks for, at a large enough input. */
function usable(hit, level, fixed) {
    if (!hit) return false;
    const complete = hit.skip || hit.blank || !extras || level === 0 || (hit.ex && hit.d === state.model)
        || (Array.isArray(hit.x) && hit.x.length >= (level >= 2 ? 8 : 5) && hit.d === state.model && (level < 3 || hit.c !== undefined || !personBoxes(hit).length));
    return !!complete && (!!hit.skip || hit.s >= 480 || hit.s >= (fixed || 320));
}

/** @param me the requester: { pri(), cancelled(), parked() } (shared/limiter.js) */
async function analyze(msg, me) {
    if (msg.vid) lastVideoAt = performance.now();
    const fixed = [256, 320, 480, 640].includes(msg.S) ? msg.S : 0;      // 0 → the backend decides once it has the image
    const key = msg.key && !msg.vid ? msg.key : null;
    const level = [0, 1, 3].includes(msg.x) ? msg.x : 2;
    const byUrl = !msg.data && !!msg.url && !msg.local;
    if (key) {
        for (;;) {
            const hit = await cacheGet(key);
            if (usable(hit, level, fixed)) { stats.hits++; return { a: hit, cached: true }; }
            const job = flights.get(key);
            if (!job) break;
            await flights.join(job, me);
            // A download that failed fails the same way for every requester of that address. Any other failure, or a result
            // that does not answer this request (a smaller input, fewer models), leaves this request to run by itself.
            if (job.failure && job.failure.message !== 'cancelled' && job.byUrl && byUrl) throw job.failure;
        }
    }
    if (!msg.data && !msg.url) return { need: 'pixels' };
    if (!msg.data && msg.local) return { need: 'pixels' };
    stats.misses++;
    if (!key) return check(msg, me, null, level, fixed);
    // From the look into the saved results (above) to here nothing waits, so a picture never has two checks.
    return flights.begin(key, me, (who) => check(msg, who, key, level, fixed), { byUrl });
}

/** Download, decode and judge one picture for `who`: one requester, or all the requesters of a shared check. */
async function check(msg, who, key, level, fixed) {
    const isCancelled = () => who.cancelled();
    // A picture's decoding and tensor work also runs on this thread: while a video plays, it waits for its turn before it
    // starts, not only before its models run.
    if (!msg.vid) await imageTurn(isCancelled);

    const blob = msg.data ? await (await fetch(msg.data)).blob() : await fetchSlots.run(async () => {
        if (isCancelled()) throw new Error('cancelled');
        return fetchImage(msg.url);
    }, who);
    return prepareSlots.run(async () => {
        if (isCancelled()) throw new Error('cancelled');
        const t2 = performance.now();
        const decoded = await decodeFrames(blob, !!msg.vid);
        const decodeMs = performance.now() - t2;
        const tm = {};
        let analysis;
        if (decoded.skip) {
            analysis = { v: MODEL_VERSION, s: 640, persons: [], parts: [], skip: decoded.skip };
        } else {
            const results = [];
            let tensorMs = 0;
            try {
                for (const source of decoded.sources) {
                    const longest = Math.max(source.displayWidth || source.width, source.displayHeight || source.height);
                    const tt = performance.now();
                    const frame = toTensor(source, fixed || chooseSize(longest));
                    if (results.length === 0) tensorMs = performance.now() - tt;
                    results.push(await inferSlot.run(async () => {
                        if (isCancelled()) throw new Error('cancelled');
                        if (!msg.vid) await imageTurn(isCancelled);     // a playing video keeps most of the backend
                        const out = await watchedInfer(frame, source, level, results.length === 0 ? tm : {}, !!msg.vid);
                        if (!msg.vid) imageDone((tm.model ?? 0) + decodeMs + tensorMs);     // all the thread time of this picture
                        return out;
                    }, who));
                }
            } finally {
                for (const source of decoded.sources) source.close?.();
            }
            analysis = results.length > 1 ? mergeAnalyses(results) : results[0];
            if (results.length > 1) { analysis.d = results[0].d; const x = mergeExtras(results); if (x && results.every((r) => r.x || r.blank)) { analysis.x = x; analysis.e = results.find((r) => r.e)?.e; const cs = results.map((r) => r.c).filter(Boolean); if (cs.length) analysis.c = [Math.max(...cs.map((c) => c[0])), Math.min(...cs.map((c) => c[1]))]; } }
            if (results.length > 1) {                       // an animation: any frame covered at once covers it
                if (results.some((r) => r.pc)) analysis.pc = 1;
                if (results.some((r) => r.ex === 1)) analysis.ex = 1;
                else if (results.some((r) => r.ex) && !(Array.isArray(analysis.x) && analysis.x.length >= 8)) analysis.ex = 2;
            }
            if (decoded.animUnread) analysis.au = 1;        // an animation that could not be read: covers (verdict.js)
        }
        if (key) cachePut(key, analysis);
        return { a: analysis, ms: { model: tm.model ?? null } };
    }, who);
}

// ---------------------------------------------------------------------------- the viewer's corrections
// The learning memory (shared/feedback.js) is held here, once, for every tab. Each answer carries what the memory says about
// that picture (four numbers); the page applies it. A choice made on a page is sent here, applied to the list, saved (one row
// per correction in this extension's own database, on this computer) and announced to every tab, which then asks again for
// the pictures it shows. Up to 0.19.4 every frame of every tab kept the whole list and its index (41 MB per frame at 100,000
// corrections), and each new correction sent the old and the new list to every frame.
const fb = { events: [], version: Date.now() % 1e9, seq: 1, first: 1, ready: null };
const ports = new Set();          // one "post" per connected frame
const announce = () => { for (const post of ports) post({ t: 'fb', fv: fb.version }); };
const summaryFor = (embedding, key) => wireSummary(summarize(embedding, confirmed(fb.events, Date.now()), typeof key === 'string' ? key : null));
const rowsOf = (events, from) => events.map((event, i) => ({ k: event.k, y: event.y, e: event.e ?? null, t: event.t, n: from + i }));

async function loadCorrections() {
    const rows = (await idb(['fb'], 'readonly', (tx) => tx.objectStore('fb').getAll())) || [];
    rows.sort((a, b) => a.n - b.n);
    fb.seq = rows.length ? rows[rows.length - 1].n + 1 : 1;
    fb.first = rows.length ? rows[0].n : 1;
    fb.events = rows.map(({ k, y, e, t }) => ({ k, y, e, t }));
    const moved = await idb(['meta'], 'readonly', (tx) => tx.objectStore('meta').get('fb-moved'));
    legacy.since = moved?.t || 0;
    legacy.pending = true;
    askForLegacy();
}
fb.ready = loadCorrections().catch(() => {});

// 0.19.4 and earlier kept the list in the extension's settings storage ('lyg-fb'), where every frame of every tab read it.
// It is moved here. This document cannot read that storage, so at each start one connected page is asked for the list (after
// the move there is none, and the answer is "none"). The list counts from the moment it arrives; its rows and the time of
// the move are written together, and only when they are written is the page told to remove the list there. Answers wait
// for the list — a few seconds at most — so that no picture is judged without the corrections already made.
// A list found after a move (the removal did not happen, or an older version was used again for a while) gives only the
// corrections made since the move: older ones were moved then, and may have been undone here since.
const LEGACY_WAIT_MS = 4000;
const legacy = { pending: false, since: 0, asked: null, deadline: 0, done: null, settle: null };
legacy.done = new Promise((resolve) => { legacy.settle = resolve; });
/** Wait for the list — until LEGACY_WAIT_MS after the first page was asked, not longer, whoever waits. */
function legacyTurn() {
    const left = legacy.pending ? (legacy.deadline || Infinity) - performance.now() : 0;
    return left > 0 ? Promise.race([legacy.done, sleep(Math.min(left, LEGACY_WAIT_MS))]) : Promise.resolve();
}

function askForLegacy() {
    if (!legacy.pending || legacy.asked) return;
    for (const post of ports) {
        if (post.silent) continue;
        legacy.asked = post;
        legacy.deadline ||= performance.now() + LEGACY_WAIT_MS;
        post({ t: 'legacy' });
        // No answer: ask another page.
        setTimeout(() => { if (legacy.pending && legacy.asked === post) { post.silent = true; legacy.asked = null; askForLegacy(); } }, LEGACY_WAIT_MS);
        return;
    }
}

/** @param list the list as 0.19.4 stored it, or null when there is none */
function adoptLegacy(list, post) {
    if (!legacy.pending || legacy.asked !== post) return;
    legacy.pending = false;
    legacy.settle();
    if (!Array.isArray(list)) return;
    const have = new Set(fb.events.map((event) => event.k));
    const room = Math.max(0, FEEDBACK_MAX - fb.events.length);
    const old = room ? list.filter((event) => event && typeof event.k === 'string' && !have.has(event.k) && !(event.t <= legacy.since)).slice(-room) : [];
    const first = fb.first - old.length;                // older than anything already here
    if (old.length) {
        fb.first = first;
        fb.events = [...old.map(({ k, y, e, t }) => ({ k, y, e: e ?? null, t })), ...fb.events];
        fb.version++;
        announce();
    }
    idb(['fb', 'meta'], 'readwrite', (tx) => {
        const store = tx.objectStore('fb');
        for (const row of rowsOf(old, first)) store.put(row);
        tx.objectStore('meta').put({ k: 'fb-moved', t: Date.now() });
    }).then((written) => {
        // Without a usable database the list stays where it was, and is read from there again at the next start.
        if (written) post({ t: 'legacy', done: true });
    });
}

/** Save the difference between two lists (lists are replaced, never edited: unchanged entries are the same objects). */
function persist(before, after) {
    const kept = new Set(after), had = new Set(before);
    const removed = before.filter((event) => !kept.has(event)), added = after.filter((event) => !had.has(event));
    if (!removed.length && !added.length) return;
    idb(['fb'], 'readwrite', (tx) => {
        const store = tx.objectStore('fb');
        for (const event of removed) store.delete(event.k);
        for (const row of rowsOf(added, fb.seq)) store.put(row);
        fb.seq += added.length;
    });
}

/** A choice made on a page: { op: 'record' | 'forget', k, y, e, sys, spread }. Applied one at a time, in arrival order. */
async function correct(op) {
    await fb.ready; await legacyTurn();
    if (typeof op.k !== 'string') return;
    const before = fb.events;
    const after = op.op === 'forget' ? forget(before, op.k) : record(before, op.k, op.y, op.e, op.sys, Date.now(), op.spread !== false);
    if (after.length === before.length && after.every((event, i) => event === before[i])) return;
    fb.events = after; fb.version++;
    persist(before, after);
    announce();
}

// ---------------------------------------------------------------------------- messaging
chrome.runtime.onConnect.addListener((port) => {
    if (port.name !== 'lyg') return;
    let alive = true;
    let hidden = false;                    // the tab is not on screen: its work waits (only visible tabs are processed)
    const requests = new Map();            // request id → its requester
    const post = (message) => { if (alive) { try { port.postMessage(message); } catch { alive = false; } } };
    ports.add(post);
    port.onDisconnect.addListener(() => {
        alive = false; ports.delete(post);
        for (const me of requests.values()) me.wake?.();
        sweepAll();
        if (legacy.asked === post) { legacy.asked = null; askForLegacy(); }
    });
    ready.then(
        () => post({ t: 'hello', tier: state.tier, backend: state.backend, model: state.model, t320: Math.round(ema320 || state.bench * (320 / 480) ** 2) }),
        () => post({ t: 'hello', error: state.error }),
    );
    fb.ready.then(() => { askForLegacy(); return legacyTurn(); }).then(() => post({ t: 'fb', fv: fb.version }));
    port.onMessage.addListener(async (msg) => {
        if (msg.t === 'x') {                 // the picture is no longer wanted
            const me = requests.get(msg.id);
            if (me) { me.gone = true; me.wake?.(); sweepAll(); }
            return;
        }
        if (msg.t === 'p') {                 // the element moved into or out of view
            const me = requests.get(msg.id);
            if (me) { me.level = msg.pri; pumpAll(); }
            return;
        }
        if (msg.t === 'v') { hidden = !!msg.hidden; if (!hidden) pumpAll(); return; }
        if (msg.t === 'c') { correct(msg).catch(() => {}); return; }
        if (msg.t === 'legacy') { adoptLegacy(msg.list, post); return; }
        if (msg.t === 'f') {                 // what does the learning memory say about these pictures now? [[key, signature], …]
            await fb.ready; await legacyTurn();
            const list = Array.isArray(msg.q) ? msg.q : [];
            post({ t: 'fr', id: msg.id, f: list.map((item) => summaryFor(item?.[1], item?.[0])), fv: fb.version });
            return;
        }
        if (msg.t !== 'a') return;
        const me = { level: msg.pri ?? 5, gone: false, wake: null, pri: () => me.level, cancelled: () => !alive || me.gone, parked: () => hidden };
        requests.set(msg.id, me);
        try {
            await ready;
            const result = await analyze(msg, me);
            if (result.a && !msg.vid) { await fb.ready; await legacyTurn(); result.f = summaryFor(result.a.e, msg.fk); }
            post({ t: 'r', id: msg.id, ...result, q: queueDepth(), e: Math.round(ema320), fv: fb.version });
        } catch (error) {
            const text = String(error?.message || error);
            if (text !== 'cancelled') stats.errors++;
            post({ t: 'r', id: msg.id, err: text, q: queueDepth() });
        } finally {
            requests.delete(msg.id);
        }
    });
});

chrome.runtime.onMessage.addListener((msg, sender, respond) => {
    if (msg?.t === 'lyg-stats') {
        const recent = stats.recent.slice().sort((a, b) => a - b);
        respond({
            ...state,
            runs: stats.runs, hits: stats.hits, misses: stats.misses, errors: stats.errors,
            avgMs: stats.runs ? Math.round(stats.totalMs / stats.runs) : null,
            medianMs: recent.length ? recent[recent.length >> 1] : null,
            t320: Math.round(ema320),
            queued: queueDepth(),
        });
        return;
    }
    if (msg?.t === 'lyg-reload-backend') {
        // The detector or the thread count was changed: start afresh. A reload ends the model worker and returns all of its
        // memory, and the new thread count takes effect. (0.19.4 started again inside the same page: the old sessions were
        // never released — 70 to 170 MB more with every change — and the thread count stayed what it was at the first start.)
        respond({ ok: true });
        setTimeout(() => location.reload(), 0);
        return;
    }
    if (msg?.t === 'lyg-clear-cache') {        // "Delete learning memory": the saved check results and the corrections
        mem.clear();
        fb.ready.then(() => {
            // The panel has removed the list of 0.19.4 from the settings storage itself: there is nothing left to move.
            legacy.pending = false; legacy.settle();
            fb.events = []; fb.version++;
            announce();
            return idb(['analysis', 'fb', 'meta'], 'readwrite', (tx) => { tx.objectStore('analysis').clear(); tx.objectStore('fb').clear(); tx.objectStore('meta').put({ k: 'fb-moved', t: Date.now() }); });
        }).then(() => respond({ ok: true }), () => respond({ ok: true }));
        return true;
    }
});
