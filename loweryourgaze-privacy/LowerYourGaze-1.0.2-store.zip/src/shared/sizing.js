// LowerYourGaze — the detector's input size for a picture. One rule for the page (which names the size when it sends
// pixels) and the backend (which picks it for pictures it downloads itself). Pure, unit-tested. AGPL-3.0.

const BUDGET_MS = 220;          // target detector time for one picture when nothing is waiting
const DEFAULT_T320_MS = 140;    // before the first measurement

/**
 * On the benchmark a 480 px input halves the miss rate of 320 px, and 256 px doubles it, so: never below 320, 480 whenever
 * the machine can afford it, 640 for large pictures on fast machines. A growing queue lowers the budget. Work done ahead of
 * time gets the same size as visible work: its verdict is cached and reused when the picture scrolls into view.
 * @param {number} naturalLongest  the picture's longer side, px
 * @param {number} t320            moving average of the detector's time at 320 px, ms (0: not measured yet)
 * @param {number} depth           work waiting in the backend (parked work of hidden tabs does not count)
 */
export function inputSize(naturalLongest, t320, depth) {
    const t = t320 || DEFAULT_T320_MS;
    const budget = depth > 24 ? BUDGET_MS / 3 : depth > 8 ? BUDGET_MS / 2 : BUDGET_MS;
    let pick = 320;
    if (naturalLongest > 320 && t * 2.25 <= budget) pick = 480;
    if (naturalLongest >= 900 && t * 4 <= budget) pick = 640;
    return pick;
}
