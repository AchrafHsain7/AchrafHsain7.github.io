// LowerYourGaze — run-time watchdog for the models. AGPL-3.0.
//
// After a good start, the backend's model runs are watched. The backend page is reloaded (a fresh context and a fresh model
// worker) when:
//   - a model run has not returned after `hangMs` of awake time (`loadingHangMs` while a model is being loaded in the
//     background: runs then wait behind the load in the model worker), or
//   - `failStreak` model runs have failed in a row (cancellations do not count; any success resets the count).
//
// Edge cases, each covered by tests/unit/watchdog.test.mjs:
//   - Runs may overlap (a video frame may use one slot beyond the limit): every run has its own age.
//   - Time is counted by the watchdog's own ticks. A gap longer than `suspendGapMs` between two ticks (the computer slept,
//     the page was frozen) is not counted: waking up never looks like a hang. Throttled ticks (once a minute) still count.
//   - Restarts are bounded: at most `maxRestarts` within `windowMs` of each other, and `maxTotal` in the life of the page
//     (sessionStorage survives the reload). Beyond that the watchdog gives up: everything stays covered and `onGiveUp`
//     reports why. A later successful run clears that report (`onRecover`).
//   - One trip reloads once: after `restart` is called the watchdog stops acting.

export const WATCHDOG = Object.freeze({
    hangMs: 60_000,             // a picture takes well under 2 s even on one slow thread
    loadingHangMs: 300_000,     // runs may wait behind a model load in the worker
    suspendGapMs: 70_000,       // longer than Chrome's once-a-minute timer throttling, shorter than any sleep worth noticing
    failStreak: 5,
    maxRestarts: 3,
    windowMs: 30 * 60_000,
    maxTotal: 6,
});

const isCancel = (error) => String(error?.message || error) === 'cancelled';

export class RunWatchdog {
    /**
     * @param o.store   { get(): string|null, set(string) } — survives a reload of the page (sessionStorage)
     * @param o.restart (reason) => void — reloads the backend page
     * @param o.onGiveUp (reason) => void, o.onRecover () => void
     * @param o.now     monotonic clock in ms; o.wall: wall clock in ms
     */
    constructor({ store, restart, onGiveUp = () => {}, onRecover = () => {}, now = () => performance.now(), wall = () => Date.now(), ...limits } = {}) {
        Object.assign(this, WATCHDOG, limits);
        Object.assign(this, { store, restart, onGiveUp, onRecover, now, wall });
        this.runs = new Map();          // run id → awake ms
        this.seq = 0;
        this.fails = 0;
        this.loading = 0;               // background model loads in progress
        this.lastTick = now();
        this.stopped = false;           // a restart was requested: do nothing more
        this.gaveUp = null;             // the reason, while given up
    }

    begin() {
        const id = ++this.seq;
        this.runs.set(id, 0);
        return id;
    }

    end(id, ok, error = null) {
        this.runs.delete(id);
        if (ok) {
            this.fails = 0;
            if (this.gaveUp) { this.gaveUp = null; this.onRecover(); }
            return;
        }
        if (isCancel(error)) return;
        if (++this.fails >= this.failStreak) this.trip(`${this.fails} model runs failed in a row`);
    }

    /** Called every few seconds. */
    tick() {
        const t = this.now(), gap = t - this.lastTick;
        this.lastTick = t;
        if (this.stopped || !this.runs.size || !(gap >= 0) || gap > this.suspendGapMs) return;
        const limit = this.loading > 0 ? this.loadingHangMs : this.hangMs;
        for (const [id, age] of this.runs) {
            const next = age + gap;
            this.runs.set(id, next);
            if (next > limit) { this.trip(`a model run took over ${Math.round(limit / 1000)} s`); return; }
        }
    }

    /** Wraps a background model load: runs waiting behind it get the longer limit. */
    async whileLoading(promiseOrFn) {
        this.loading++;
        try { return await (typeof promiseOrFn === 'function' ? promiseOrFn() : promiseOrFn); }
        finally { this.loading--; }
    }

    record() {
        try { const r = JSON.parse(this.store.get() || 'null'); if (r && Number.isFinite(r.n) && Number.isFinite(r.t) && Number.isFinite(r.total)) return r; } catch {}
        return { n: 0, t: 0, total: 0 };
    }

    trip(reason) {
        if (this.stopped) return;
        const r = this.record(), wall = this.wall();
        const recent = wall - r.t <= this.windowMs ? r.n : 0;
        if (recent >= this.maxRestarts || r.total >= this.maxTotal) {
            if (this.gaveUp !== reason) { this.gaveUp = reason; this.onGiveUp(reason); }
            return;
        }
        this.store.set(JSON.stringify({ n: recent + 1, t: wall, total: r.total + 1 }));
        this.stopped = true;
        this.restart(reason);
    }
}
