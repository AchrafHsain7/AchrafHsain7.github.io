// LowerYourGaze — text cues. Words near a picture (its own alt text and link, the card or section around it,
// the page's address and title) make that one picture's decision stricter: strong words more, soft words less,
// and the nearer the words the larger the step. Nothing is covered on words alone. Pure functions. AGPL-3.0.

// Words that name women's content outright. Used on page addresses, page titles and image captions.
const STRONG = [
    "wom[ae]n'?s?", 'ladies', 'lady', 'girls?', 'females?', 'femmes?', 'filles?', 'mujer(?:es)?', 'chicas?', 'damen', 'frauen', 'donna', 'donne',
    'lingerie', 'bikinis?', 'swimwear', 'swimsuits?', 'bras?', 'bralettes?', 'panties', 'underwear',
    // "dress" on its own, not the men's-wear compounds
    'dress(?:es)?(?![ -](?:shirts?|pants|trousers|shoes?|socks?|code|watch(?:es)?|belts?|up))',
    'skirts?', 'leggings', 'bodysuits?', 'nightwear', 'sleepwear', 'maternity', 'bridal', 'brides?', 'bridesmaids?', 'vestidos?', 'kleid(?:er)?',
];
// Words that only make sense as cues inside a caption, not inside an address or a page title.
const CAPTION_ONLY = [
    'she', 'her', 'hers', 'herself', 'girlfriend', 'wife', 'actress(?:es)?', 'mom', 'mother', 'daughter', 'sister', 'queen', 'princess',
    'hijab', 'abaya',
];
const NON_LATIN = /نساء|امرأة|امراة|فتاة|فتيات|بنات|فساتين|فستان|женщин|девуш|女|妇/;

const build = (words) => new RegExp(`(?:^|[^a-z])(?:${words.join('|')})(?:$|[^a-z])`, 'i');
// Words that often go with pictures of women without naming them: a smaller step than the strong words.
const SOFT = [
    'hot', 'sexy', 'beaut(?:y|iful|ies)', 'cute', 'gorgeous', 'stunning', 'babes?', 'models?', 'modeling', 'fashion', 'outfits?', 'ootd', 'haul', 'try[ -]?on',
    'makeup', 'make[ -]up', 'skincare', 'hairstyles?', 'yoga', 'dance', 'dancing', 'cosplay', 'waifu', 'actress(?:es)?', 'singer', 'influencer', 'vlog', 'grwm',
    'jolie', 'belle', 'bella', 'hermosa', 'linda', 'guapa', 'sch[oö]n', 'hübsch',
];
const SOFT_NON_LATIN = /جميلة|جمال|حلوة|موضة|مكياج|красив|мода|美女|美人/;
const SOFT_RE = build(SOFT);
const URL_RE = build(STRONG);
const CAPTION_RE = build([...STRONG, ...CAPTION_ONLY]);

/** Does this page address, title or breadcrumb point to women's content? */
export function urlIsFemale(url) {
    let text = String(url || '');
    try { text = decodeURIComponent(text); } catch {}
    return URL_RE.test(text.toLowerCase()) || NON_LATIN.test(text);
}

/** Does this caption or page title carry a soft cue (beauty, fashion, hot, …)? */
export function textIsSoft(text) {
    if (!text) return false;
    const value = String(text).slice(0, 600);
    return SOFT_RE.test(value.toLowerCase()) || SOFT_NON_LATIN.test(value);
}

/** Does this caption (alt text, title, link label) point to a woman? */
export function textIsFemale(text) {
    if (!text) return false;
    const value = String(text).slice(0, 400);
    return CAPTION_RE.test(value.toLowerCase()) || NON_LATIN.test(value);
}

/** Strength of the cue in a piece of text: 2 strong word, 1 soft word, 0 none. `caption` also counts the caption-only words (she, her, …). */
export function cueOf(text, caption = true) {
    if (!text) return 0;
    if (caption ? textIsFemale(text) : urlIsFemale(text)) return 2;
    return textIsSoft(text) ? 1 : 0;
}
