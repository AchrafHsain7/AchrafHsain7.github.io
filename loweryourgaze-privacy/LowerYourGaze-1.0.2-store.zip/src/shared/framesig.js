// LowerYourGaze — frame signatures for video: is this frame (nearly) the same picture as an earlier one? AGPL-3.0.
//
// A signature is the frame shrunk to 64 × 36: its luma, its edges (gradient magnitude of the luma) and the mean colour
// (Cb, Cr) of each of 8 × 6 blocks. Two signatures are compared block by block, as frame-difference filters in video
// analytics do (NoScope's "blocked" difference detector, Reducto's pixel / edge features), with three signals:
//   structure  SSIM (Wang et al. 2004) of the luma in each block: brightness, contrast and pattern;
//   edges      change of the edge map in each block (Reducto found edges catch the small changes pixels miss);
//   colour     change of the block's mean colour.
// The worst block decides, so that a small change (a woman entering a corner, an inset) is not drowned by a large
// unchanged background. With `shift`, each block may match the other frame displaced by one pixel (≈ 1.6 % of the
// width): a speaking head or a slow pan stays "the same picture", a new object does not.
// The three signals are combined either by a rule (every signal within its limit) or by weights fitted in the lab.

export const SIG_W = 64, SIG_H = 36, BLOCK_W = 8, BLOCK_H = 6;
const BX = SIG_W / BLOCK_W, BY = SIG_H / BLOCK_H, N = BLOCK_W * BLOCK_H, NB = BX * BY;
const C1 = (0.01 * 255) ** 2, C2 = (0.03 * 255) ** 2;
const SHIFTS = [[0, 0], [1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]];

/** Signature from luma (64 × 36) and block colours (8 × 6 each). Used by the lab with stored signatures. */
export function fromParts(y, cb, cr) {
    const g = new Float32Array(SIG_W * SIG_H);
    for (let r = 0; r < SIG_H; r++) for (let c = 0; c < SIG_W; c++) {
        const at = (rr, cc) => y[Math.min(SIG_H - 1, Math.max(0, rr)) * SIG_W + Math.min(SIG_W - 1, Math.max(0, cc))];
        const gx = at(r, c + 1) - at(r, c - 1), gy = at(r + 1, c) - at(r - 1, c);
        g[r * SIG_W + c] = Math.hypot(gx, gy);
    }
    return { y, g, cb, cr };
}

/** Signature of a 64 × 36 RGBA frame (ImageData.data). */
export function signature(rgba) {
    const y = new Uint8Array(SIG_W * SIG_H), cb = new Float32Array(NB), cr = new Float32Array(NB);
    for (let i = 0, p = 0; i < SIG_W * SIG_H; i++, p += 4) {
        const r = rgba[p], g = rgba[p + 1], b = rgba[p + 2];
        y[i] = 0.299 * r + 0.587 * g + 0.114 * b;
        const block = Math.floor(Math.floor(i / SIG_W) / BLOCK_H) * BX + Math.floor((i % SIG_W) / BLOCK_W);
        cb[block] += -0.1687 * r - 0.3313 * g + 0.5 * b;
        cr[block] += 0.5 * r - 0.4187 * g - 0.0813 * b;
    }
    for (let k = 0; k < NB; k++) { cb[k] /= N; cr[k] /= N; }
    return fromParts(y, cb, cr);
}

// Structure (SSIM) and edge change of block (bx, by) of b against a, a displaced by (dx, dy). null when off the frame.
function block(a, b, bx, by, dx, dy) {
    const x0 = bx * BLOCK_W + dx, y0 = by * BLOCK_H + dy;
    if (x0 < 0 || y0 < 0 || x0 + BLOCK_W > SIG_W || y0 + BLOCK_H > SIG_H) return null;
    let sa = 0, sb = 0, saa = 0, sbb = 0, sab = 0, gd = 0, gs = 0;
    for (let yy = 0; yy < BLOCK_H; yy++) {
        const ra = (y0 + yy) * SIG_W + x0, rb = (by * BLOCK_H + yy) * SIG_W + bx * BLOCK_W;
        for (let xx = 0; xx < BLOCK_W; xx++) {
            const u = a.y[ra + xx], v = b.y[rb + xx];
            sa += u; sb += v; saa += u * u; sbb += v * v; sab += u * v;
            const p = a.g[ra + xx], q = b.g[rb + xx];
            gd += Math.abs(p - q); gs += p + q;
        }
    }
    const ma = sa / N, mb = sb / N;
    const va = saa / N - ma * ma, vb = sbb / N - mb * mb, cov = sab / N - ma * mb;
    const ssim = ((2 * ma * mb + C1) * (2 * cov + C2)) / ((ma * ma + mb * mb + C1) * (va + vb + C2));
    const edge = gd / (gs + 8 * N);          // 0 = same edges, → 1 = different; the constant keeps flat blocks quiet
    return { ssim, edge };
}

/**
 * Compare two signatures.
 * @returns {{ssim:number, mean:number, edge:number, chroma:number, ssim2:number}}
 *   ssim: worst block structure (1 = identical) · ssim2: second worst · mean: mean block structure ·
 *   edge: worst block edge change (0 = identical) · chroma: largest change of a block's mean colour (0–255 scale)
 */
export function compare(a, b, { shift = false } = {}) {
    let worst = 1, second = 1, sum = 0, edge = 0, chroma = 0, edgeSum = 0;
    const shifts = shift ? SHIFTS : SHIFTS.slice(0, 1);
    for (let by = 0; by < BY; by++) for (let bx = 0; bx < BX; bx++) {
        let s = -1, e = Infinity;
        for (const [dx, dy] of shifts) {
            const r = block(a, b, bx, by, dx, dy);
            if (!r) continue;
            if (r.ssim > s) s = r.ssim;           // best match over the allowed displacements, for each signal
            if (r.edge < e) e = r.edge;
        }
        if (s < worst) { second = worst; worst = s; } else if (s < second) second = s;
        sum += s; edgeSum += e;
        if (e > edge) edge = e;
        const k = by * BX + bx;
        const dc = Math.hypot(a.cb[k] - b.cb[k], a.cr[k] - b.cr[k]);
        if (dc > chroma) chroma = dc;
    }
    return { ssim: worst, ssim2: second, mean: sum / NB, edge, edgeMean: edgeSum / NB, chroma };
}

/**
 * Same picture, as far as the viewer could tell.
 * Rule: worst-block structure ≥ ssim, worst-block edge change ≤ edge, largest colour change ≤ chroma.
 * Fitted (lab): { type: 'rule', ssim, edge, chroma, shift } — limits chosen under safety limits — or
 *               { type: 'logistic', features, weights, bias, threshold, shift } — a logistic score of the signals.
 */
export function similar(a, b, { ssim = 0.9, chroma = 8, edge = 1, shift = false, fit = null } = {}) {
    if (!a || !b) return false;
    if (fit?.type === 'rule') ({ ssim, chroma, edge, shift } = fit);           // limits chosen in the lab
    const c = compare(a, b, { shift: fit ? !!fit.shift : shift });
    if (fit && fit.type !== 'rule') return sameScore(c, fit) >= fit.threshold;
    return c.ssim >= ssim && c.chroma <= chroma && c.edge <= edge;
}

/** Logistic score of a comparison, with weights fitted in the lab: { features: [names], weights, bias }. */
export function sameScore(c, fit) {
    let z = fit.bias;
    fit.features.forEach((name, i) => { z += fit.weights[i] * c[name]; });
    return 1 / (1 + Math.exp(-z));
}
