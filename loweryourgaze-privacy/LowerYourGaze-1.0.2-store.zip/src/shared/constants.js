// LowerYourGaze — shared constants. AGPL-3.0.

// Output channels of the pruned detector, in order (see tools/export_pruned.py).
export const CLASSES = [
    'Woman', 'Girl', 'Man', 'Boy', 'Person',
    'Human face', 'Human head', 'Human hair', 'Human body', 'Human arm',
    'Human leg', 'Human hand', 'Human foot', 'Human eye', 'Human mouth',
    'Human nose', 'Human ear', 'Human beard',
    'Sculpture', 'Bust', 'Doll',
    'Dress', 'Skirt', 'Miniskirt', 'Brassiere', 'Swimwear', 'High heels', 'Lipstick',
    'Clothing', 'Jeans', 'Trousers', 'Shorts', 'Shirt', 'Jacket', 'Coat', 'Suit',
];
export const C = Object.fromEntries(CLASSES.map((name, i) => [name, i]));

// Bump when the model or decode() changes: cached analyses are keyed on it.
export const MODEL_VERSION = 'oiv7-p36-e2';      // detector classes + extra signals (8-bit CLIP, 0.11 descriptions, face gender)

export const STORAGE_KEY = 'lyg';
export const COVER_KEY = 'lyg-cover';      // images the viewer chose to cover: list of address hashes

export const DEFAULTS = {
    enabled: true,
    mode: 'full',            // 'full' | 'region'
    strictness: 'balanced',  // 'balanced' | 'strict'
    images: true,
    videos: true,
    videoMode: 'verified',   // 'verified': frames are checked before they are shown (short delay) | 'direct'
    videoCuts: true,         // direct mode: re-blur a revealed video the moment the scene changes
    backgrounds: true,
    canvases: true,
    context: 'on',           // words near a picture make its decision stricter (own text > section > page): 'on' | 'off'
    blur: 28,                // px
    gray: true,
    model: 'auto',           // 'auto' | 'n' | 's'
    threads: 0,              // CPU threads for the detector; 0 = automatic
    extras: true,            // run CLIP and face gender beside the detector and decide by their weighted score
    sites: {},               // hostname → 'off' | 'anyone' | 'all'  (absent = normal)
    paused: [],              // legacy list of hostnames where filtering is off
    // Video tuning (Advanced; verified video only).
    videoFreezeMs: 700,      // a late verdict freezes the last verified frame up to this long, then blurs
    videoDelayMs: 0,         // how late frames are shown: 0 = automatic (about twice the verdict time), else fixed ms
    videoSample: 'auto',     // 'auto': 480 px + CLIP + face when the machine keeps up | 'fast': 320 px (shorter delay)
    videoSimilar: 'auto',    // same-picture check: 'off' | 'keep': drop a cover on a frame that looks like the last clear one
                             // | 'reuse': a frame that looks like the last judged one takes its verdict without the models | 'both'
                             // | 'auto' (0.18): 'reuse' on a slow machine (see screen.js, AUTO_REUSE_*), 'off' otherwise
    videoSimBy: 'rule',      // 'rule': the limits below | 'fit': weights fitted in the lab (when the build carries them)
    videoSimSsim: 0.875,     // "looks like": every 8 × 6 block of a 64 × 36 copy at least this similar in structure (SSIM)…
    videoSimEdge: 1,         // …its edges changed at most this much (0–1; 1 = not checked)…
    videoSimColour: 6,       // …and its mean colour moved at most this much (0–255)
                             // (0.875 / 6 with movement: the best limits under the safety check, lab on v7, 15 Nov)
    videoSimShift: true,     // each block may match one pixel away (a speaking head, a slow pan)
    videoSimRefreshMs: 2000, // 'reuse': a clear verdict is re-checked in the background after this (0 = only on change)
    videoSimClip: 0,         // 'keep': also drop a cover when CLIP sees the same scene as the last clear frame (cosine ≥; 0 = off)
};

// Rendered elements smaller than this on either side are cleared without inference.
export const TINY_PX = 24;
// Canvases smaller than this on either side are shown without a check.
export const CANVAS_MIN_PX = 96;
