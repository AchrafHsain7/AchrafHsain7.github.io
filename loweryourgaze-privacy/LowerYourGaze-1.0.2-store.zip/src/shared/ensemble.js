// LowerYourGaze — the weighted decision over several model signals. Pure functions, unit-tested. AGPL-3.0.
//
//   score = Σ weight · signal        (signed weights: positive argues for covering)
//   margin = score − threshold       (≥ 0 → cover)
//
// Signals come from three models: the object detector (persons, body parts, garments), a CLIP image
// encoder compared against text prompts (woman / group / man / no people / text-like), and a face
// detector with a face-gender classifier. Still images whose first margin is close to zero get a
// second look: CLIP on the detected person crops, judged with its own weight set; when that is also
// close to zero the image is covered. Video frames use the detector and CLIP only.
// Weights, thresholds and bands were fitted offline on every labelled image (lab/) and live in
// ensemble-data.js.

import { ENSEMBLE } from './ensemble-data.js';

const HUMAN_PARTS = [5, 16], BEARD = 17, FIGURES = [18, 20], FEMALE_GARMENTS = [21, 27];     // class index ranges, see constants.js
const PERSON_MIN = 0.25;        // detector confidence for a person box to get a crop
export const MAX_CROPS = 3;
export const X_FULL = 8, X_VIDEO = 5;     // analysis.x: [clip woman, group, man, no-people, text-like, face female, face score, face male]

/** Scalar signals of one analysis, by name. Missing models contribute zeros. */
export function signals(a) {
    let f = 0, m = 0, p = 0, part = 0, beard = 0, fig = 0, fgar = 0;
    for (const person of a.persons || []) {
        if (person[4] > f) f = person[4];
        if (person[5] > m) m = person[5];
        if (person[6] > p) p = person[6];
    }
    for (const item of a.parts || []) {
        const c = item[0], s = item[5];
        if (c >= HUMAN_PARTS[0] && c <= HUMAN_PARTS[1]) { if (s > part) part = s; }
        else if (c === BEARD) { if (s > beard) beard = s; }
        else if (c >= FIGURES[0] && c <= FIGURES[1]) { if (s > fig) fig = s; }
        else if (c >= FEMALE_GARMENTS[0] && c <= FEMALE_GARMENTS[1]) { if (s > fgar) fgar = s; }
    }
    const x = a.x || [], c = a.c || [];
    return {
        det_f: f, det_p: p, det_part: part, det_fig: fig, det_fgar: fgar, det_m: m, det_beard: beard,
        clip_w: x[0] || 0, clip_g: x[1] || 0, clip_m: x[2] || 0, clip_n: x[3] || 0, clip_t: x[4] || 0,
        face_f: x[5] || 0, face_s: x[6] || 0, face_m: x[7] || 0,
        crop_f: c[0] || 0, crop_m: c[1] || 0,
    };
}

// A picture that stopped after CLIP + detector (early exit, stage 2) is judged with that stage's own weights.
const firstSet = (a) => (a.ex === 2 && ENSEMBLE.cascade?.sets?.[`${a.d}_c2`]) || ENSEMBLE.sets[a.x.length >= X_FULL ? a.d : `${a.d}v`];
const secondSet = (a) => (Array.isArray(a.c) && a.x.length >= X_FULL ? ENSEMBLE.sets[`${a.d}2`] : null);

/** Does this analysis carry what the weighted decision needs? */
export const hasEnsemble = (a) => !!a && Array.isArray(a.x) && a.x.length >= X_VIDEO && !!firstSet(a);

function marginOf(set, s, strictness) {
    let total = 0;
    for (const name in set.weights) total += set.weights[name] * s[name];
    return total - (set.thresholds[strictness] ?? set.thresholds.strict);
}

/** First-look margin: ≥ 0 means cover. */
export function margin(a, strictness = 'strict') {
    return marginOf(firstSet(a), signals(a), strictness);
}

/**
 * The margin the verdict rests on, after the second look when there was one.
 * Both looks unsure → +0 (cover). Returns { margin, looks, unsure }.
 */
export function finalMargin(a, strictness = 'strict') {
    const s = signals(a), first = marginOf(firstSet(a), s, strictness), second = secondSet(a);
    if (!second) return { margin: first, looks: 1, unsure: false };
    const m2 = marginOf(second, s, strictness);
    if (Math.abs(m2) < second.unsure) return { margin: Math.max(m2, 0), looks: 2, unsure: true };
    return { margin: m2, looks: 2, unsure: false };
}

/** Is the first look unsure enough to pay for a second one? (Asked by the detector process.) */
export function wantsSecondLook(a) {
    if (!hasEnsemble(a) || a.x.length < X_FULL || !ENSEMBLE.sets[`${a.d}2`] || !personBoxes(a).length) return false;
    const set = firstSet(a), s = signals(a);
    return marginOf(set, s, 'strict') >= -set.band && marginOf(set, s, 'balanced') <= set.band;
}

/** Up to MAX_CROPS person boxes [x1, y1, x2, y2] (normalised), largest first. */
export function personBoxes(a) {
    return (a.persons || [])
        .filter((p) => Math.max(p[4], p[5], p[6]) >= PERSON_MIN)
        .sort((p, q) => (q[2] - q[0]) * (q[3] - q[1]) - (p[2] - p[0]) * (p[3] - p[1]))
        .slice(0, MAX_CROPS)
        .map((p) => p.slice(0, 4));
}

/** Did the detector find a person (of any gender)? */
export function hasPerson(a) {
    for (const p of a.persons || []) if (Math.max(p[4], p[5], p[6]) >= PERSON_MIN) return true;
    return false;
}

/** Video frames get no second look: a frame with a person whose margin is within this of zero is covered. */
export const videoUnsure = () => ENSEMBLE.videoUnsure;

/** A cover with a margin below this is weak: in a video it needs a neighbouring covered sample to count. */
export const weakBelow = (a) => firstSet(a).hysteresis * ENSEMBLE.weakBands;

/** Hysteresis band of the set this analysis is judged with. */
export const hysteresisOf = (a) => firstSet(a).hysteresis;

/**
 * Every weight set a picture or a video frame can be judged with must carry finite weights, thresholds and — for the sets of the
 * first look — a hysteresis band. 0.11 shipped the early-exit sets without "hysteresis": a covered video frame judged with them
 * got margin + undefined = NaN, which covered it. Their band is 0, set explicitly: a frame judged with an exit set passed the
 * exit at |margin| ≥ 1 (exits.clear2 / cover2) on both strictness levels, beyond any band (0.27–0.28), so a band there could
 * never change the verdict. Returns a list of problems ([] when sound); the unit tests require [].
 */
export function ensembleProblems(data = ENSEMBLE) {
    const problems = [], finite = (v) => typeof v === 'number' && Number.isFinite(v);
    const check = (name, set, first) => {
        if (!set) { problems.push(`${name}: missing`); return; }
        for (const [w, v] of Object.entries(set.weights || {})) if (!finite(v)) problems.push(`${name}: weight ${w} not finite`);
        if (!set.weights || !Object.keys(set.weights).length) problems.push(`${name}: no weights`);
        for (const level of ['strict', 'balanced']) if (!finite(set.thresholds?.[level])) problems.push(`${name}: threshold ${level} not finite`);
        if (first && !finite(set.hysteresis)) problems.push(`${name}: hysteresis not finite`);
    };
    for (const [name, set] of Object.entries(data.sets || {})) check(name, set, !/2$/.test(name));
    for (const [name, set] of Object.entries(data.cascade?.sets || {})) check(`cascade ${name}`, set, true);
    if (!finite(data.weakBands)) problems.push('weakBands not finite');
    if (!finite(data.videoUnsure)) problems.push('videoUnsure not finite');
    for (const [name, exit] of Object.entries(data.cascade?.exits || {})) {
        for (const k of ['cover1', 'clear2', 'cover2']) if (exit[k] !== undefined && !finite(exit[k])) problems.push(`exit ${name}.${k} not finite`);
        // the explicit band of 0 on the exit sets is exact only while every exit margin is beyond every first-look band
        const bands = Object.values(data.sets || {}).map((s) => s.hysteresis).filter(finite);
        for (const k of ['clear2', 'cover2']) if (finite(exit[k]) && bands.some((b) => b >= exit[k])) problems.push(`exit ${name}.${k} within a hysteresis band`);
    }
    return problems;
}

/**
 * A picture of text and nothing else: slide, code, chart, document, screenshot — CLIP calls it text-like,
 * sees no people in it, and neither the detector nor the face model found anything. Such a picture is
 * shown whatever its score, also on pages that are otherwise covered as a whole. On the labelled images
 * the rule holds for 91 % of the text-like ones and for none of the 2,216 with women.
 */
export function isPlainText(a) {
    if (!hasEnsemble(a)) return false;
    const s = signals(a), rule = ENSEMBLE.text;            // video frames carry no face signal: face_s is 0 there
    return s.clip_t >= rule.text && s.clip_w + s.clip_g <= rule.people && s.face_s < rule.face
        && Math.max(s.det_f, s.det_p, s.det_m, s.det_part, s.det_fig, s.det_fgar) < rule.detector;
}

/** Combine the extra signals of several frames of one animation: the most covering reading of each. */
export function mergeExtras(list) {
    const xs = list.map((a) => a.x).filter(Array.isArray);
    if (!xs.length) return null;
    const size = Math.min(...xs.map((x) => x.length)), pick = (i, fn) => fn(...xs.map((x) => x[i] || 0));
    const out = [pick(0, Math.max), pick(1, Math.max), pick(2, Math.min), pick(3, Math.min), pick(4, Math.min)];
    if (size >= X_FULL) out.push(pick(5, Math.max), pick(6, Math.max), pick(7, Math.min));
    return out;
}

// ---------------------------------------------------------------------------- early exits and protected content (0.11)

/**
 * Early exits, CLIP first (system lab, rounds 2–3): stage 1 is CLIP alone, stage 2 CLIP + detector,
 * stage 3 the full decision. A picture stops early only when the exit holds at both Strict and Balanced, so a later
 * change of strictness can re-judge it from what it carries. Returns 'cover' | 'clear' | null (go on).
 */
export function earlyExit(a, stage) {
    const cas = ENSEMBLE.cascade;
    if (!cas || !Array.isArray(a.x) || a.x.length < X_VIDEO) return null;
    const exits = (level) => cas.exits?.[`${a.d}_${level}`];
    const levels = ['strict', 'balanced'];
    if (levels.some((level) => !exits(level))) return null;
    if (stage === 1) {
        const set = cas.sets?.[`${a.d}_c1`];
        if (!set) return null;
        const s = signals(a);
        return levels.every((level) => marginOf(set, s, level) > exits(level).cover1) ? 'cover' : null;
    }
    const set = cas.sets?.[`${a.d}_c2`] || ENSEMBLE.sets[`${a.d}v`];
    if (!set) return null;
    const s = signals(a);
    if (levels.every((level) => marginOf(set, s, level) < -exits(level).clear2)) return 'clear';
    if (levels.every((level) => marginOf(set, s, level) > exits(level).cover2)) return 'cover';
    return null;
}

/**
 * Lingerie, nudity, immodest or sexual clothing, worn or alone: covered at once, whatever the weighted decision says.
 * Two signals: CLIP's probability mass on the protected descriptions (a.pr, computed by the detector process) and the
 * detector's Miniskirt / Brassiere / Swimwear classes. Thresholds were set on pictures that must stay visible (lab round 3).
 */
export function protectedHit(a, protect) {
    if (!a || !protect) return false;
    if (Number.isFinite(a.pr) && Number.isFinite(protect.clip_threshold) && a.pr > protect.clip_threshold) return true;
    if (!Number.isFinite(protect.detector_threshold)) return false;
    const classes = protect.detector_classes || [];
    for (const item of a.parts || []) if (classes.includes(item[0]) && item[5] > protect.detector_threshold) return true;
    return false;
}
