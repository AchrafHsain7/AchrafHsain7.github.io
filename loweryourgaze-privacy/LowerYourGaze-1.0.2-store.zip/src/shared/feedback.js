// LowerYourGaze — learning from the viewer's own corrections. Pure functions, unit-tested. AGPL-3.0.
//
// When the viewer shows an image the extension covered, or covers one it showed, the image's compact signature (64 numbers:
// its CLIP embedding reduced by PCA, so similarity means "shows the same kind of thing", not "same pixels") is remembered with
// the correction. Similarity is the cosine of two signatures. The two directions are treated differently on purpose:
//   - a "cover" pulls every picture that looks alike towards covering (similarity above coverFloor, up to `cover`; the safe
//     direction);
//   - a "show" shows the same picture (its key) and its near-copies (similarity ≥ showSim: resized, recompressed,
//     re-uploaded) outright, and pulls similar pictures towards showing (similarity above showFloor, up to `showPull`).
//     The pull is graded and capped below the cover pull: it tips borderline pictures (men and thumbnails covered by mistake),
//     and a picture the models clearly see as a woman keeps its cover (0.19.3, owner's decision: the learning mechanism).
//     The round-2 lab measured wider "show" reach before the guards below existed; the next lab measures this rule.
//   - a "show" does not spread when the extension had strong grounds to cover (0.18.1, owner's rule): CLIP alone was sure
//     (early exit 1), protected content, or a strong word in the picture's own text or its card. Such a "show" is kept for
//     that picture only (stored without its signature), and a picture with those grounds is not reached by other "shows".
//   - the viewer's own "cover" of a picture is never undone by another picture's "show".
// Many examples never add up: the strongest cover and the strongest show count, so every pull stays within its cap.
// A choice made before the picture's signature arrived is learned when it arrives (main.js); a key-only "show" needs none.

import { ENSEMBLE } from './ensemble-data.js';

const F = { dim: 64, max: 100000, confirmMs: 0, coverFloor: 0.8, coverPower: 2, cover: 4, showSim: 0.985, show: 1000, showFloor: 0.9, showPower: 2, showPull: 2, ...(ENSEMBLE.corrections || {}) };
export const FEEDBACK_KEY = 'lyg-fb';
export const FEEDBACK_MAX = F.max;
export const CONFIRM_MS = F.confirmMs;

// Signatures are stored as base64 text of 64 signed bytes (88 characters, about a third of a JSON number list), so the
// memory can keep up to `max` corrections: 100,000 take about 14 MB (the manifest asks for unlimited storage).
// Lists written before 0.19.2 hold plain number arrays; both forms are read.
export function packSignature(embedding) {
    const bytes = new Uint8Array(embedding.length);
    for (let i = 0; i < embedding.length; i++) bytes[i] = Math.max(-127, Math.min(127, Math.round(embedding[i]))) & 255;
    let text = '';
    for (const b of bytes) text += String.fromCharCode(b);
    return btoa(text);
}

function unpack(e) {
    if (typeof e === 'string') {
        try { const raw = atob(e); if (raw.length !== F.dim) return null; const v = new Int8Array(F.dim); for (let i = 0; i < F.dim; i++) v[i] = (raw.charCodeAt(i) << 24) >> 24; return v; } catch { return null; }
    }
    return Array.isArray(e) && e.length === F.dim ? Int8Array.from(e) : null;
}

// A list is indexed once into packed tables (signatures one after another, with their lengths) and the index is kept while
// the list is in use; lists are replaced, never edited in place. 100,000 corrections: about 6 ms per picture, 75 ms to index.
const indexes = new WeakMap();
function indexOf(events) {
    let index = indexes.get(events);
    if (index) return index;
    const keys = new Map();                                     // key → its event (one per picture)
    const parts = { c: [], s: [] };
    for (const event of events) {
        keys.set(event.k, event);
        const v = event.e ? unpack(event.e) : null;
        if (v) (event.y > 0 ? parts.c : parts.s).push([v, event.k]);
    }
    const pack = (list) => {
        const mat = new Int8Array(list.length * F.dim), norm = new Float64Array(list.length), ks = new Array(list.length);
        list.forEach(([v, k], j) => { mat.set(v, j * F.dim); let n = 0; for (let i = 0; i < F.dim; i++) n += v[i] * v[i]; norm[j] = Math.sqrt(n); ks[j] = k; });
        return { mat, norm, keys: ks, count: list.length };
    };
    index = { keys, cover: pack(parts.c), show: pack(parts.s) };
    indexes.set(events, index);
    return index;
}

/**
 * Add a correction to the list. An event is { k: image key, y: +1 cover | -1 show, e: embedding, t: time }.
 * `systemCovers` is what the extension decided by itself: a choice that agrees with it teaches nothing and
 * only removes an earlier correction for the same image. Returns the new list.
 */
export function record(list, key, y, embedding, systemCovers, now, spread = true) {
    const rest = (list || []).filter((event) => event.k !== key);
    const agrees = (y > 0) === !!systemCovers;
    const hasE = Array.isArray(embedding) && embedding.length === F.dim;
    // A cover teaches by likeness, so it needs the embedding. A show keeps its embedding (to reach near-copies) only when it
    // may spread; otherwise it is matched by key alone.
    if (!agrees && key && (hasE || y < 0)) rest.push({ k: key, y: y > 0 ? 1 : -1, e: hasE && (y > 0 || spread) ? packSignature(embedding) : null, t: now });
    return rest.length > FEEDBACK_MAX ? rest.slice(rest.length - FEEDBACK_MAX) : rest;
}

/** Remove the correction for one image ("check it again"). */
export const forget = (list, key) => (list || []).filter((event) => event.k !== key);

/** Corrections old enough to count. */
export const confirmed = (list, now) => (CONFIRM_MS > 0 ? (list || []).filter((event) => now - event.t >= CONFIRM_MS) : (list || []));

/**
 * How far the corrections move this image's margin. Positive: towards covering.
 * Cover examples pull with weight ((similarity − floor) / (1 − floor))^power, zero below the floor; the strongest counts,
 * so any number of them moves a margin by at most `cover`. A cover of this very picture counts in full.
 * A show example shows the same picture (the same key) and a near-copy (similarity ≥ showSim) outright, and pulls a similar
 * picture towards showing with weight ((similarity − showFloor) / (1 − showFloor))^showPower, at most `showPull`; both only
 * when `reach` allows it (the picture has no strong grounds to be covered) and the example kept its signature.
 */
export function correction(embedding, events, key = null, reach = true) {
    return explainCorrection(embedding, events, key, reach).total;
}

/**
 * The same, with what made it: { total, cover, show, pull, from }. show: 1 the same picture, 2 a near-copy;
 * pull: the weight (0–1) of the strongest similar show.
 * `from` is the key of the deciding example.
 */
export function explainCorrection(embedding, events, key = null, reach = true) {
    return explainFrom(summarize(embedding, events, key), reach);
}

// The matching is done in two steps, so that the list is held in one place (the backend) and not in every frame of every
// tab: summarize() looks the picture up in the list — the only step that needs the list — and explainFrom() applies `reach`,
// which only the page knows (it depends on the words around the picture). 0.19.4 kept the whole list, and its index, in each
// content script: 41 MB per frame at 100,000 corrections.

/**
 * What the list says about one picture, whatever `reach` turns out to be:
 * [own, cover, near, pull, coverFrom, nearFrom, pullFrom, key] — own: −1 this picture was shown, +1 covered, 0 neither;
 * cover: weight (0–1) of the strongest similar cover; near: 1 when a shown picture is a near-copy; pull: weight (0–1) of the
 * strongest similar show. The first four are numbers and travel with the analysis; the rest name the deciding examples.
 * null when there are no corrections.
 */
export function summarize(embedding, events, key = null) {
    if (!events || !events.length) return null;
    const index = indexOf(events);
    const own = key ? index.keys.get(key) : null;
    if (own && own.y < 0) return [-1, 0, 0, 0, null, null, null, key];
    if (own && own.y > 0) return [1, 0, 0, 0, null, null, null, key];
    const out = [0, 0, 0, 0, null, null, null, key];
    if (!Array.isArray(embedding) || embedding.length !== F.dim) return out;
    const q = Int8Array.from(embedding);
    let qn = 0;
    for (let i = 0; i < F.dim; i++) qn += q[i] * q[i];
    qn = Math.sqrt(qn);
    const cosine = (table, j) => {
        const mat = table.mat, o = j * F.dim;
        let dot = 0;
        for (let i = 0; i < F.dim; i++) dot += q[i] * mat[o + i];
        return qn && table.norm[j] ? dot / (qn * table.norm[j]) : 0;
    };
    for (let j = 0; j < index.cover.count; j++) {
        const sim = cosine(index.cover, j);
        if (sim > F.coverFloor) {
            const w = Math.min(1, ((sim - F.coverFloor) / (1 - F.coverFloor)) ** F.coverPower);
            if (w > out[1]) { out[1] = w; out[4] = index.cover.keys[j]; }
        }
    }
    for (let j = 0; j < index.show.count; j++) {
        const sim = cosine(index.show, j);
        if (sim >= F.showSim) { out[2] = 1; out[5] = index.show.keys[j]; break; }
        if (sim > F.showFloor) {
            const w = Math.min(1, ((sim - F.showFloor) / (1 - F.showFloor)) ** F.showPower);
            if (w > out[3]) { out[3] = w; out[6] = index.show.keys[j]; }
        }
    }
    return out;
}

/** The correction for a picture from its summary. `reach`: may a show of another picture reach this one? */
export function explainFrom(summary, reach = true) {
    const out = { total: 0, cover: 0, show: 0, pull: 0, from: null };
    if (!summary) return out;
    const [own, cover, near, pull, coverFrom = null, nearFrom = null, pullFrom = null, key = null] = summary;
    if (own < 0) { out.show = 1; out.from = key; }
    else if (own > 0) { out.cover = 1; out.from = key; }
    else {
        out.cover = cover; out.from = coverFrom;
        if (reach) {
            if (near) { out.show = 2; out.from = nearFrom; }
            else { out.pull = pull; if (pull && !out.from) out.from = pullFrom; }
        }
    }
    out.total = out.show ? -F.show : F.cover * out.cover - F.showPull * out.pull;
    return out;
}

/** The part of a summary that travels with an analysis: four numbers. */
export const wireSummary = (summary) => (summary ? summary.slice(0, 4) : null);

/** The parameters in force (for tests). */
export const CORRECTIONS = F;
