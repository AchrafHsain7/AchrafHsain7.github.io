// LowerYourGaze — the backend's work queues. Pure, unit-tested. AGPL-3.0.
//
// Every piece of queued work belongs to a requester, asked live each time the queue moves:
//   who.pri()        lower runs first; 0 (video frames) may use one slot beyond the limit
//   who.cancelled()  the requester has gone away (scrolled past, tab closed): sweep() rejects the work with
//                    Error('cancelled') without waiting for its turn
//   who.parked()     the requester's tab is not on screen: the work waits, whatever its priority
// Parked and cancelled work is not load: it is left out of `depth`, the figure that lowers the detector's input size and
// holds back look-ahead checks (0.19.4 counted it, so one hidden tab with queued pictures made every visible tab judge
// its pictures at 320 px, and a hidden tab closed with downloads queued did so until the browser restarted).

export class Limiter {
    constructor(limit) { this.limit = limit; this.active = 0; this.waiting = []; }

    /** Queue `task` for `who`; resolves or rejects with the task. Work for a requester that has already gone is not queued. */
    run(task, who) {
        if (who.cancelled()) return Promise.reject(new Error('cancelled'));
        return new Promise((resolve, reject) => {
            this.waiting.push({ task, resolve, reject, who });
            this.pump();
        });
    }

    /** Reject queued work whose requester has gone away, without waiting for its turn. */
    sweep() {
        for (let i = this.waiting.length - 1; i >= 0; i--) {
            const entry = this.waiting[i];
            if (entry.who.cancelled()) { this.waiting.splice(i, 1); entry.reject(new Error('cancelled')); }
        }
    }

    /** Queued work that is really waiting for a turn. */
    get depth() {
        let count = 0;
        for (const entry of this.waiting) if (!entry.who.parked() && !entry.who.cancelled()) count++;
        return count;
    }

    pump() {
        this.sweep();
        while (this.waiting.length) {
            let best = -1, bestPri = 0;
            for (let i = 0; i < this.waiting.length; i++) {
                const entry = this.waiting[i];
                if (entry.who.parked()) continue;
                const pri = entry.who.pri();
                if (best < 0 || pri < bestPri) { best = i; bestPri = pri; }      // equal priority: the oldest (the list is in arrival order)
            }
            if (best < 0) return;
            if (this.active >= this.limit + (bestPri === 0 ? 1 : 0)) return;
            const next = this.waiting.splice(best, 1)[0];
            this.active++;
            Promise.resolve().then(next.task).then(next.resolve, next.reject).finally(() => { this.active--; this.pump(); });
        }
    }
}

/**
 * Several requesters of the same work, seen as one: as urgent as the most urgent of them, parked only while every one of
 * them is parked, gone only when all of them are. `members` is a live Set; requesters that have gone away do not count.
 */
export function together(members) {
    return {
        pri() {
            let best = Infinity;
            for (const who of members) if (!who.cancelled()) best = Math.min(best, who.pri());
            return best;
        },
        cancelled() {
            for (const who of members) if (!who.cancelled()) return false;
            return true;
        },
        parked() {
            for (const who of members) if (!who.cancelled() && !who.parked()) return false;
            return true;
        },
    };
}

/**
 * One piece of work per key at a time. The first requester starts it; requesters that come while it runs join it instead of
 * starting their own, and the work is then done for all of them (together()). `changed` is called when a requester joins:
 * the work may have become more urgent, or is no longer parked.
 */
export class Flights {
    constructor(changed = () => {}) { this.jobs = new Map(); this.changed = changed; }

    get(key) { return this.jobs.get(key); }
    get size() { return this.jobs.size; }

    /**
     * Start the work for `key` for requester `me`. `run(who)` does it, for everyone who has asked by then or asks later.
     * Returns the work's promise. `info` is kept on the job ({ who, done, failure, ...info }).
     */
    begin(key, me, run, info = {}) {
        const job = { ...info, who: new Set([me]), failure: null, done: null };
        job.done = Promise.resolve().then(() => run(together(job.who)))
            .catch((error) => { job.failure = error; throw error; })
            .finally(() => { if (this.jobs.get(key) === job) this.jobs.delete(key); });
        this.jobs.set(key, job);
        return job.done;
    }

    /**
     * Wait for a job another requester started. Resolves when the job has ended, however it ended (job.failure tells);
     * rejects with Error('cancelled') as soon as `me` goes away — me.wake() is called for that — while the job goes on for
     * the others.
     */
    join(job, me) {
        if (me.cancelled()) return Promise.reject(new Error('cancelled'));
        job.who.add(me);
        this.changed();
        return new Promise((resolve, reject) => {
            me.wake = () => reject(new Error('cancelled'));
            job.done.then(resolve, resolve);
        }).finally(() => { me.wake = null; job.who.delete(me); });
    }
}
