// LowerYourGaze — the verdict the extension acts on. AGPL-3.0.
//
// With the extra models' signals present, the weighted decision (ensemble.js) decides for the Strict
// and Balanced settings, adjusted by the viewer's confirmed corrections (feedback.js) and by words near
// the picture (keywordStep). The older rule (decision.js) still decides when the viewer set a site to
// cover every person ("Anyone"), when the extra models did not run, and for invalid, blank or skipped
// analyses; it also supplies the boxes for region blur.

import { judge } from './decision.js';
import { ENSEMBLE } from './ensemble-data.js';
import { hasEnsemble, margin, finalMargin, hysteresisOf, isPlainText, weakBelow, hasPerson, videoUnsure } from './ensemble.js';
import { explainCorrection, explainFrom, confirmed } from './feedback.js';

let enabled = true, events = [], active = [], activeAt = 0, systemOnly = false;
/** Setting "Extra models": off → the older rule decides everything. */
export function setEnsembleEnabled(on) { enabled = !!on; }
/** A list of corrections to match here (tools and tests; all of them — the confirmed ones are picked at decision time). */
export function setFeedback(list) { events = Array.isArray(list) ? list : []; activeAt = 0; }

// In a page the list is not held here: the backend, which holds the only copy, looks each picture up when it answers and
// sends the summary with the analysis (analysis.f — feedback.js, summarize). Only `reach` is applied here, because it depends
// on the words around the picture. A list set with setFeedback() is matched directly, through the same two steps.
function feedbackFor(analysis, now, key, reach) {
    if (systemOnly) return NONE;                                  // systemCovers(): the extension's verdict without the corrections
    if (analysis.f) return explainFrom(analysis.f, reach);
    if (!events.length) return NONE;
    if (now - activeAt > 30000 || !activeAt) { active = confirmed(events, now); activeAt = now; }
    return explainCorrection(analysis.e, active, key, reach);
}
const NONE = { total: 0, cover: 0, show: 0, pull: 0, from: null };

/** Steps added to the margin by words near a picture: strong / soft word, and the weight of the section and page scopes. */
export const KEYWORDS = { strong: 1, soft: 0.5, section: 0.6, page: 0.3, ...(ENSEMBLE.keywords || {}) };

/**
 * May a "show" spread to or from this picture (near-copies)? Not when the extension had strong grounds to cover it: CLIP alone
 * was sure (early exit 1), protected content, or a strong word in its own text or its card (a word step of at least a strong
 * word in the card scope). Those pictures learn and are shown by their own key only (0.18.1, owner's rule).
 */
export function showSpreads(analysis, bonus = 0) {
    if (!analysis || analysis.pc || analysis.ex === 1) return false;
    return !(bonus >= KEYWORDS.strong * KEYWORDS.section - 1e-9);
}

/**
 * Strictness step for one picture from the words around it. Each cue is 0 (none), 1 (soft word) or 2 (strong word),
 * for the picture's own text (alt, title, link, caption), its card or section, and the page (address, title, breadcrumb).
 * The nearest scope counts most; the largest weighted step wins. Words never cover a picture by themselves, and they count
 * only when a person is found in the picture (decide).
 */
export function keywordStep(own = 0, section = 0, page = 0) {
    const step = (cue) => (cue >= 2 ? KEYWORDS.strong : cue === 1 ? KEYWORDS.soft : 0);
    return Math.max(step(own), KEYWORDS.section * step(section), KEYWORDS.page * step(page));
}

/**
 * @param analysis    what the detector process returned
 * @param strictness  'strict' | 'balanced' | 'anyone'
 * @param elevated    the viewer set this site to "Anyone": cover every person
 * @param wasCovered  previous verdict for the same video (true / false), or null for a still image
 * @param bonus       added to the margin (keywordStep)
 * @param key         the picture's key (hash of its address): a remembered "show" applies to that picture only
 * @returns {{block: boolean, reasons: string[], regions: number[][]|null, margin?: number, fb?: number}}
 *          fb: how far the viewer's corrections moved the margin (absent when they did not)
 */
export function decide(analysis, strictness = 'strict', elevated = false, wasCovered = null, bonus = 0, now = Date.now(), key = null) {
    // A file that can be animated (GIF, WebP, APNG, AVIF) whose animation the backend could not read: one still frame cannot
    // vouch for the rest, so it stays covered (0.17 — review of 0.16, finding 6). The viewer can still show it by hand.
    if (analysis?.au) return { block: true, reasons: ['animation-unread'], regions: [], margin: Infinity, weak: false };
    // Covered at once: protected content (lingerie, nudity, immodest clothing) and pictures CLIP alone was sure of (early exit).
    // A remembered "show" of that very picture wins over CLIP's early exit, never over protected content (0.18): protected
    // content is covered on every visit, and only a "show" the viewer gives on the page itself (main.js) reveals it.
    const fb = wasCovered === null && enabled ? feedbackFor(analysis || {}, now, key, showSpreads(analysis, bonus)) : NONE;
    if (analysis && (analysis.pc || analysis.ex === 1) && !analysis.skip) {
        if (analysis.pc || !(fb.total <= -100)) return { block: true, reasons: [analysis.pc ? 'protected' : 'score'], regions: [], margin: Infinity };
    }
    const old = judge(analysis, strictness, elevated);
    if (!enabled || strictness === 'anyone' || elevated || !hasEnsemble(analysis) || analysis.skip || analysis.blank || old.reasons[0] === 'invalid') return old;
    if (isPlainText(analysis)) return { block: false, reasons: ['text-only'], regions: [], margin: -Infinity };
    const level = strictness === 'balanced' ? 'balanced' : 'strict';
    // Words near a picture count only when a person is found in it: covers caused by words alone were products with no
    // person ("Queen" sheets, a "Women's" watch, toys "for girls").
    if (!hasPerson(analysis)) bonus = 0;
    let m, reason = 'score';
    if (wasCovered === null) {
        const look = finalMargin(analysis, level);
        m = look.margin + bonus + fb.total;
        if (look.unsure) reason = 'unsure';
    } else {
        // Frames of one video: once covered, the margin has to fall a band below zero before the cover is released.
        m = margin(analysis, level) + bonus + (wasCovered ? hysteresisOf(analysis) : 0);
        // No second look for video: a person whose margin is close to zero is covered (both unsure → cover).
        if (m < 0 && m >= -videoUnsure() && hasPerson(analysis)) { m = 0; reason = 'unsure'; }
    }
    // A margin that is not a number (a weight set without one of its parameters) covers — and says so — instead of falling
    // through comparisons that are all false (0.11: NaN made "m < 0" false, which covered without a reason anyone could see).
    if (Number.isNaN(m)) return { block: true, reasons: ['invalid-margin'], regions: [], margin: NaN, weak: false };
    const tag = fb.total ? { fb: fb.total } : {};
    if (m < 0) return { block: false, reasons: fb.show === 1 ? ['shown-before'] : fb.show === 2 ? ['shown-copy'] : fb.pull && m - fb.total >= 0 ? ['learned-show'] : [], regions: [], margin: m, ...tag };
    // Region blur needs boxes: the older rule's, when it also covers; otherwise the whole image.
    const boxes = old.block ? old : judge(analysis, 'strict');
    // A weak cover (score barely over the threshold, no person found) needs a covered neighbour to count in a video:
    // that removes the lone flashes of blur over slides, code and objects. A frame with a person is never weak.
    const weak = wasCovered !== null && !hasPerson(analysis) && m - (wasCovered ? hysteresisOf(analysis) : 0) < weakBelow(analysis);
    return { block: true, reasons: [fb.cover && m - fb.total < 0 ? 'learned-cover' : reason], regions: boxes.block ? boxes.regions : [], margin: m, weak, ...tag };
}

/** On a page that is covered as a whole: may this image be shown because it is nothing but text? */
export function plainText(analysis) {
    return enabled && !!analysis && !analysis.skip && !analysis.blank && isPlainText(analysis);
}

/**
 * What the extension decides by itself — the models and the words around the picture (`bonus`), without the viewer's
 * corrections — to tell whether a choice is a correction. 0.18: the words were left out, so a picture covered only because
 * of them (margin −0.1, a +0.3 cue) was taken for a picture the extension showed, and a "show" of it taught nothing.
 */
export function systemCovers(analysis, strictness, elevated, bonus = 0) {
    systemOnly = true;
    try { return decide(analysis, strictness, elevated, null, bonus).block; } finally { systemOnly = false; }
}
