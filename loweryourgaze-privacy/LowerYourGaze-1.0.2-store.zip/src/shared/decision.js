// LowerYourGaze — detector post-processing and the reveal rule. Pure functions, no DOM.
// AGPL-3.0.
import { C, CLASSES, MODEL_VERSION } from './constants.js';

const PERSON_CANDIDATE = 0.10;   // lowest score kept for a person-like anchor
const PART_CANDIDATE = 0.15;     // lowest score kept for parts, figures, garments
const NMS_IOU = 0.5;
const MAX_PERSONS = 40;
const MAX_PARTS = 60;

const round3 = (v) => Math.round(v * 1000) / 1000;

function iou(a, b) {
    const x1 = Math.max(a[0], b[0]), y1 = Math.max(a[1], b[1]);
    const x2 = Math.min(a[2], b[2]), y2 = Math.min(a[3], b[3]);
    const inter = Math.max(0, x2 - x1) * Math.max(0, y2 - y1);
    const ua = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - inter;
    return ua > 0 ? inter / ua : 0;
}

function nms(items, limit) {
    items.sort((p, q) => q.score - p.score);
    const kept = [];
    for (const item of items) {
        if (kept.length >= limit) break;
        if (kept.every((k) => iou(k.box, item.box) < NMS_IOU)) kept.push(item);
    }
    return kept;
}

/**
 * Turn the raw detector output into a compact, cacheable analysis.
 * @param {Float32Array} out   tensor data, layout [1, 4 + K, N] (channel-major)
 * @param {number} n           number of anchors N
 * @param {{size:number, scale:number, padX:number, padY:number, width:number, height:number}} lb
 *        letterbox geometry: model input side, resize factor, padding, source size
 * @returns {{v:string, s:number, persons:number[][], parts:number[][]}}
 *        persons: [x1,y1,x2,y2,f,m,p]  parts: [class,x1,y1,x2,y2,score]; boxes normalised to the source image
 */
export function decode(out, n, lb) {
    const K = CLASSES.length;
    const ch = (c) => (4 + c) * n;
    const toBox = (i) => {
        const cx = out[i], cy = out[n + i], w = out[2 * n + i], h = out[3 * n + i];
        const nx = (v) => Math.min(1, Math.max(0, (v - lb.padX) / lb.scale / lb.width));
        const ny = (v) => Math.min(1, Math.max(0, (v - lb.padY) / lb.scale / lb.height));
        return [nx(cx - w / 2), ny(cy - h / 2), nx(cx + w / 2), ny(cy + h / 2)];
    };

    const persons = [];
    const partsByClass = new Map();
    const W = ch(C.Woman), G = ch(C.Girl), M = ch(C.Man), B = ch(C.Boy), P = ch(C.Person);
    for (let i = 0; i < n; i++) {
        const f = Math.max(out[W + i], out[G + i]);
        const m = Math.max(out[M + i], out[B + i]);
        const p = out[P + i];
        const g = Math.max(f, m, p);
        if (g >= PERSON_CANDIDATE) persons.push({ box: toBox(i), score: g, f, m, p });
    }
    for (let c = C['Human face']; c < K; c++) {
        const base = ch(c);
        let list = null;
        for (let i = 0; i < n; i++) {
            const s = out[base + i];
            if (s >= PART_CANDIDATE) (list ||= []).push({ box: toBox(i), score: s, c });
        }
        if (list) partsByClass.set(c, list);
    }

    const keptPersons = nms(persons, MAX_PERSONS);
    const keptParts = [];
    for (const list of partsByClass.values()) keptParts.push(...nms(list, 12));
    keptParts.sort((a, b) => b.score - a.score);

    return {
        v: MODEL_VERSION,
        s: lb.size,
        persons: keptPersons.map((d) => [...d.box.map(round3), round3(d.f), round3(d.m), round3(d.p)]),
        parts: keptParts.slice(0, MAX_PARTS).map((d) => [d.c, ...d.box.map(round3), round3(d.score)]),
    };
}

/** Union of several analyses (frames of an animated image). */
export function mergeAnalyses(list) {
    const first = list[0];
    return {
        v: first.v, s: first.s, frames: list.length,
        blank: list.every((a) => a.blank) || undefined,
        persons: list.flatMap((a) => a.persons).slice(0, MAX_PERSONS * 2),
        parts: list.flatMap((a) => a.parts).slice(0, MAX_PARTS * 2),
    };
}

// ---------------------------------------------------------------------------------------------
// Reveal rule: an image is shown only on positive evidence that it is safe.
//   - a person is "male-clear" only if the male score is confident and dominant;
//   - every other detected person (female or undetermined) blocks;
//   - a face / head / hair / body / limb outside a male-clear person blocks;
//   - statues, busts, dolls and female-coded garments outside a male-clear person block.
// ---------------------------------------------------------------------------------------------
export const RULES = {
    balanced: {
        person: 0.10,       // min score for an undetermined person to block (close crops of legs or hips score low)
        female: 0.10,       // min female score to block outright
        femaleRatio: 0.4,   // ...unless the male score dominates by more than 1/ratio
        male: 0.30,         // min male score for male-clear
        maleFemaleMax: 0.03,// max female score tolerated on a male-clear person
        // The model often answers "Person" for men it is fairly sure about. Such a person also clears
        // when the male score is present and the female score is essentially zero.
        hedgeMale: 0.12,
        hedgeFemaleMax: 0.008,
        parts: {
            'Human face': 0.25, 'Human head': 0.3, 'Human hair': 0.3, 'Human body': 0.25,
            'Human arm': 0.35, 'Human leg': 0.3,
        },
        figures: { Sculpture: 0.3, Bust: 0.3, Doll: 0.3 },
        garments: { Brassiere: 0.25, Swimwear: 0.25, Miniskirt: 0.25, Dress: 0.35, Skirt: 0.35 },
    },
    strict: {
        person: 0.10,
        female: 0.10,
        femaleRatio: 0.2,
        male: 0.55,
        maleFemaleMax: 0.03,
        parts: {
            'Human face': 0.2, 'Human head': 0.2, 'Human hair': 0.2, 'Human body': 0.2,
            'Human arm': 0.25, 'Human leg': 0.2, 'Human hand': 0.3, 'Human foot': 0.3,
            'Human eye': 0.3, 'Human mouth': 0.3, 'Human nose': 0.35, 'Human ear': 0.35,
        },
        figures: { Sculpture: 0.2, Bust: 0.2, Doll: 0.2 },
        garments: { Brassiere: 0.2, Swimwear: 0.2, Miniskirt: 0.2, Dress: 0.25, Skirt: 0.25, 'High heels': 0.4, Lipstick: 0.4 },
    },
};

// Used on pages and images whose text points to women's content, and for sites set to "Anyone":
// no person clears, and any human part, figure or garment blocks at a low threshold.
RULES.anyone = {
    person: 0.10, female: 0.05, femaleRatio: 0, male: 2, maleFemaleMax: 0,
    parts: {
        'Human face': 0.15, 'Human head': 0.15, 'Human hair': 0.15, 'Human body': 0.15, 'Human arm': 0.2,
        'Human leg': 0.15, 'Human hand': 0.25, 'Human foot': 0.25, 'Human eye': 0.3, 'Human mouth': 0.3,
        'Human nose': 0.3, 'Human ear': 0.3,
    },
    figures: { Sculpture: 0.15, Bust: 0.15, Doll: 0.15 },
    garments: {
        Brassiere: 0.15, Swimwear: 0.15, Miniskirt: 0.15, Dress: 0.15, Skirt: 0.15, 'High heels': 0.3, Lipstick: 0.3,
        Clothing: 0.15, Jeans: 0.15, Trousers: 0.15, Shorts: 0.15, Shirt: 0.15, Jacket: 0.15, Coat: 0.15, Suit: 0.15,
    },
};

const REGION_MARGIN = 0.25;       // each blocked box grows by this fraction of its size per side
const REGION_MIN_MARGIN = 0.04;   // ...and by at least this fraction of the image
const REGION_MAX_AREA = 0.55;     // above this covered fraction, blur the whole image
const REGION_MAX_BOXES = 8;

function containedFraction(inner, outer) {
    const x1 = Math.max(inner[0], outer[0]), y1 = Math.max(inner[1], outer[1]);
    const x2 = Math.min(inner[2], outer[2]), y2 = Math.min(inner[3], outer[3]);
    const inter = Math.max(0, x2 - x1) * Math.max(0, y2 - y1);
    const area = (inner[2] - inner[0]) * (inner[3] - inner[1]);
    return area > 0 ? inter / area : 0;
}

function expand(box) {
    const w = box[2] - box[0], h = box[3] - box[1];
    const mx = Math.max(w * REGION_MARGIN, REGION_MIN_MARGIN);
    const my = Math.max(h * REGION_MARGIN, REGION_MIN_MARGIN);
    return [Math.max(0, box[0] - mx), Math.max(0, box[1] - my), Math.min(1, box[2] + mx), Math.min(1, box[3] + my)];
}

function mergeBoxes(boxes) {
    const out = boxes.map((b) => b.slice());
    let merged = true;
    while (merged) {
        merged = false;
        outer: for (let i = 0; i < out.length; i++) {
            for (let j = i + 1; j < out.length; j++) {
                const a = out[i], b = out[j];
                if (a[0] <= b[2] && b[0] <= a[2] && a[1] <= b[3] && b[1] <= a[3]) {
                    out[i] = [Math.min(a[0], b[0]), Math.min(a[1], b[1]), Math.max(a[2], b[2]), Math.max(a[3], b[3])];
                    out.splice(j, 1);
                    merged = true;
                    break outer;
                }
            }
        }
    }
    return out;
}

function unionArea(boxes) {
    // boxes are disjoint after mergeBoxes
    return boxes.reduce((s, b) => s + (b[2] - b[0]) * (b[3] - b[1]), 0);
}

/**
 * Apply the reveal rule. `elevated` selects the "anyone" rule regardless of strictness.
 * @returns {{block:boolean, reasons:string[], regions:number[][]|null}}
 *   regions: conservative boxes to blur in region mode, or null when the whole image must be blurred.
 */
export function judge(analysis, strictness = 'balanced', elevated = false) {
    if (!analysis || analysis.v !== MODEL_VERSION || !Array.isArray(analysis.persons)) {
        return { block: true, reasons: ['invalid'], regions: null };
    }
    if (analysis.skip) return { block: false, reasons: [analysis.skip], regions: [] };
    const R = elevated ? RULES.anyone : (RULES[strictness] || RULES.balanced);
    const blocked = [];
    const reasons = new Set();
    const maleClear = [];

    for (const [x1, y1, x2, y2, f, m, p] of analysis.persons) {
        const box = [x1, y1, x2, y2];
        if (f >= R.female && f >= m * R.femaleRatio) {
            blocked.push(box); reasons.add('female');
        } else if ((m >= R.male && f <= R.maleFemaleMax && m >= p)
            || (R.hedgeMale !== undefined && p > m && m >= R.hedgeMale && f <= R.hedgeFemaleMax && m >= 4 * f)) {
            maleClear.push(box);
        } else if (Math.max(f, m, p) >= R.person) {
            blocked.push(box); reasons.add('person');
        }
    }

    const explained = (box) => maleClear.some((mc) => containedFraction(box, mc) >= 0.6);
    for (const [c, x1, y1, x2, y2, score] of analysis.parts) {
        const name = CLASSES[c];
        const box = [x1, y1, x2, y2];
        const kind = name in R.parts ? 'part' : name in R.figures ? 'figure' : name in R.garments ? 'garment' : null;
        if (!kind) continue;
        const threshold = R.parts[name] ?? R.figures[name] ?? R.garments[name];
        if (score < threshold || explained(box)) continue;
        blocked.push(box); reasons.add(kind);
    }

    if (!blocked.length) return { block: false, reasons: [], regions: [] };

    let regions = null;
    if (!analysis.frames && blocked.length <= REGION_MAX_BOXES * 3) {
        const merged = mergeBoxes(blocked.map(expand));
        if (merged.length <= REGION_MAX_BOXES && unionArea(merged) <= REGION_MAX_AREA) regions = merged.map((b) => b.map(round3));
    }
    return { block: true, reasons: [...reasons], regions };
}
