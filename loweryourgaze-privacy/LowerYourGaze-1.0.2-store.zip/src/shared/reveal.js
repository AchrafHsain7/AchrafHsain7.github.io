// LowerYourGaze — the rule that decides whether a buffered video frame may be shown. AGPL-3.0.
//
// Frames are numbered in presentation order. Some of them were sampled by the detector:
//   seqs      ascending frame numbers of the samples
//   samples   Map: frame number → { v: 'c' clear | 'b' covered | 'w' weakly covered | 'n' blank, t: capture time in ms,
//             o: frame number of the model sample a reused verdict was copied from (absent on model samples),
//             h: capture time of that model sample }
// A reused verdict (same picture as an earlier model sample) covers its own frame like any sample, but it is not new evidence:
// it does not corroborate the weak cover it was copied from, and the cover band (holdMs) runs from the model sample's time.
// 0.16 — before, copies counted as detections (a lone weak cover became "two") and each copy restarted the hold.
//   cuts      [{ lo, hi }]: a new scene starts at some frame in lo..hi (not every frame is compared)

/** A new scene may have started after frame a, up to and including frame b. */
export function maybeCut(cuts, a, b) {
    for (const cut of cuts) if (cut.lo <= b && cut.hi > a) return true;
    return false;
}

/** A new scene certainly started after frame a, up to and including frame b. */
export function surelyCut(cuts, a, b) {
    for (const cut of cuts) if (cut.lo > a && cut.hi <= b) return true;
    return false;
}

/**
 * Does sample i count as covered? A solid cover always does. A weak one (score barely over the threshold)
 * counts only when a neighbouring sample of the same scene is covered too — a lone weak cover between
 * clear samples is detector noise. While the next sample is still unknown, a weak cover counts.
 */
export function covers(i, seqs, samples, cuts) {
    const me = samples.get(seqs[i]), v = me.v;
    if (v === 'b') return true;
    if (v !== 'w') return false;
    const origin = me.o ?? seqs[i];
    const same = (j) => (samples.get(seqs[j]).o ?? seqs[j]) === origin;       // a copy of the same detection
    const backs = (j) => { const u = samples.get(seqs[j]).v; return (u === 'b' || u === 'w') && !surelyCut(cuts, seqs[Math.min(i, j)], seqs[Math.max(i, j)]); };
    let before = i - 1; while (before >= 0 && same(before)) before--;
    let after = i + 1; while (after < seqs.length && same(after)) after++;
    if (before >= 0 && backs(before)) return true;
    if (after >= seqs.length) return true;
    return backs(after);
}

/**
 * May this frame be shown sharp?  true / false, or null while its verdict is still pending.
 *  - The next sample at or after the frame must be clear, unless it certainly shows a later scene.
 *  - A covered sample earlier in the same scene keeps the screen covered for holdMs. A scene cut ends
 *    that hold at once: the new scene is judged on its own samples.
 *  - At the end of a scene, where the next sample may already show the following scene, the previous
 *    sample has to vouch for the frame and must be recent (tailMs).
 * @param {{seq:number, t:number}} frame
 */
export function mayShow(frame, seqs, samples, cuts, holdMs, tailMs) {
    const why = explain(frame, seqs, samples, cuts, holdMs, tailMs);
    return why === 'ok' ? true : why === 'pending' ? null : false;
}

/**
 * The same rule, with its reason: 'ok' · 'pending' (no sample at or after the frame yet) · 'cover' (the next sample covers) ·
 * 'hold' (a cover earlier in the scene, within holdMs) · 'tail' (end of a scene, no recent clear sample before the frame).
 */
export function explain(frame, seqs, samples, cuts, holdMs, tailMs) {
    let at = seqs.length;
    while (at > 0 && seqs[at - 1] >= frame.seq) at--;
    if (at >= seqs.length) return 'pending';
    const afterSeq = seqs[at];
    if (covers(at, seqs, samples, cuts) && !surelyCut(cuts, frame.seq, afterSeq)) return 'cover';
    for (let i = at - 1; i >= 0; i--) {
        const sample = samples.get(seqs[i]);
        if (frame.t - sample.t >= holdMs) break;
        if (frame.t - (sample.h ?? sample.t) >= holdMs) continue;                 // a copy of an older detection
        if (covers(i, seqs, samples, cuts) && !surelyCut(cuts, seqs[i], frame.seq)) return 'hold';
    }
    if (!maybeCut(cuts, frame.seq, afterSeq)) return 'ok';
    if (!at) return 'tail';
    return !covers(at - 1, seqs, samples, cuts) && frame.t - samples.get(seqs[at - 1]).t <= tailMs && !surelyCut(cuts, seqs[at - 1], frame.seq) ? 'ok' : 'tail';
}
