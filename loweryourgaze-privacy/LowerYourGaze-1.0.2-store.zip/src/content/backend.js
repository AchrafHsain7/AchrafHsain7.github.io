// LowerYourGaze — content-script side of the detector: the Port client, pixel capture, and the
// request flow that turns an image URL into an analysis. AGPL-3.0.
import { inputSize } from '../shared/sizing.js';
import { FEEDBACK_KEY } from '../shared/feedback.js';

let port = null, greeted = false, connecting = null, seq = 1, connections = 0;
const pending = new Map();          // request id → { resolve, reject, ticket: the page may withdraw it }
const idleListeners = new Set();
const feedbackListeners = new Set();
const reconnectListeners = new Set();
const outbox = [];                  // the viewer's choices not yet handed to the backend

/** Live figures reported by the backend. fv: the version of the learning memory its answers were made with. */
export const perf = { tier: 'slow', t320: 0, queue: 0, model: null, backend: null, fv: null };

/**
 * The version of the learning memory, as the backend states it: announced on every connection and after every change
 * (a choice in this or another tab), and carried by every answer.
 */
function noteFeedback(version, announced = false) {
    if (version === undefined || (version === perf.fv && !announced)) return;
    perf.fv = version;
    for (const listener of feedbackListeners) listener();
}

function onMessage(msg) {
    if (msg.t === 'hello') {
        if (msg.t320) perf.t320 = msg.t320;
        perf.tier = msg.tier || perf.tier; perf.model = msg.model; perf.backend = msg.backend;
        return;
    }
    if (msg.t === 'fb') { noteFeedback(msg.fv, true); return; }
    if (msg.t === 'legacy') {
        // The backend takes over the corrections list that 0.19.4 kept in the settings storage (it cannot read that storage
        // itself), and says when it has saved it: only then is the list removed here.
        if (msg.done) chrome.storage.local.remove(FEEDBACK_KEY).catch(() => {});
        else chrome.storage.local.get(FEEDBACK_KEY).then((stored) => { try { port?.postMessage({ t: 'legacy', list: stored[FEEDBACK_KEY] ?? null }); } catch {} }, () => {});
        return;
    }
    if (msg.t === 'fr') {
        const waiter = pending.get(msg.id);
        if (waiter) { pending.delete(msg.id); waiter.resolve(msg); }
        return;
    }
    if (msg.t !== 'r') return;
    if (typeof msg.q === 'number') perf.queue = msg.q;
    if (msg.e) perf.t320 = msg.e;
    // What the learning memory says about this picture travels with its analysis (verdict.js reads analysis.f).
    if (msg.a && msg.fv !== undefined) { msg.a.f = msg.f ?? null; msg.a.fv = msg.fv; }
    const waiter = pending.get(msg.id);
    if (waiter) {
        pending.delete(msg.id);
        if (msg.err) waiter.reject(new Error(msg.err)); else waiter.resolve(msg);
    }
    noteFeedback(msg.fv);
    if (perf.queue <= 1) for (const listener of idleListeners) listener();
}

/**
 * The connection to the backend, once the backend has greeted. The greeting carries the machine's speed, which sets the
 * detector's input size (pickSize): a request sized before it arrived was sized for an unknown — slow — machine. 0.19.4 sent
 * at once, so the first pictures of every page (often everything above the fold) were judged at 320 px on machines that
 * afford 480 or 640. The greeting comes when the models are loaded; until then requests waited in the backend anyway.
 */
export function connect() {
    if (port && greeted) return Promise.resolve(port);
    connecting ||= (async () => {
        const reply = await chrome.runtime.sendMessage({ t: 'lyg-ensure' });
        if (!reply?.ok) throw new Error(reply?.error || 'backend unavailable');
        const opened = chrome.runtime.connect({ name: 'lyg' });
        let hello;
        const greeting = new Promise((resolve) => { hello = resolve; });
        opened.onMessage.addListener((msg) => { onMessage(msg); if (msg.t === 'hello') hello(); });
        opened.onDisconnect.addListener(() => {
            void chrome.runtime.lastError;
            if (port === opened) { port = null; greeted = false; }
            for (const waiter of pending.values()) waiter.reject(new Error('disconnected'));
            pending.clear();
            hello();
            reconnectLater();
        });
        port = opened; greeted = false;
        tellVisibility();
        flushOutbox();
        await greeting;
        if (port !== opened) throw new Error('disconnected');
        greeted = true;
        if (connections++) for (const listener of reconnectListeners) listener();
        return opened;
    })().finally(() => { connecting = null; });
    return connecting;
}

// A page that has been connected stays connected: changes of the learning memory are announced over the connection, so a
// page that lost it (the backend started again, the page came back from the back/forward cache) connects again by itself,
// waiting longer after each failure — and then hears what the memory says now (onFeedback).
let retryTimer = 0, retryMs = 1000;
function reconnectLater() {
    if (retryTimer || !chrome.runtime?.id) return;              // no id: the extension was updated or removed; this script is done
    retryTimer = setTimeout(() => {
        retryTimer = 0;
        connect().then(() => { retryMs = 1000; }, () => { retryMs = Math.min(60000, retryMs * 2); reconnectLater(); });
    }, retryMs);
}

// Only tabs on screen are processed: while this tab is hidden the backend parks its requests (pictures stay covered) and
// runs them when the tab is shown again.
function tellVisibility() {
    if (!port) return;
    try { port.postMessage({ t: 'v', hidden: typeof document !== 'undefined' && document.visibilityState === 'hidden' }); } catch {}
}
// When the tab goes to the background, its queued pictures are given back: the backend drops them — and the bytes it held
// for them — and the page asks again when it is shown (a withdrawn picture returns to "wait", main.js). 0.19.4 left them
// parked in the backend: three hidden tabs of 140 PNG pictures held 614 MB there. Video samples and canvas checks (no
// ticket) stay parked: there is one per video or canvas, and their callers do not expect a withdrawal.
function onVisibility() {
    tellVisibility();
    if (document.visibilityState !== 'hidden') return;
    for (const [id, waiter] of pending) if (waiter.ticket) cancel(id);
}
if (typeof document !== 'undefined') document.addEventListener('visibilitychange', onVisibility);

/** Resolves when the tab is on screen. A hidden tab captures no pixels and sends no work (its pictures stay covered). */
export function whenVisible() {
    if (typeof document === 'undefined' || document.visibilityState !== 'hidden') return Promise.resolve();
    return new Promise((resolve) => {
        const check = () => { if (document.visibilityState !== 'hidden') { document.removeEventListener('visibilitychange', check); resolve(); } };
        document.addEventListener('visibilitychange', check);
    });
}

// How many of the extra models run beside the detector: 2 CLIP + face gender, 1 CLIP only, 0 none.
let extraLevel = 2;
export function setExtraLevel(level) { extraLevel = level; }

export async function send(payload, ticket) {
    const channel = await connect();
    if (ticket?.gone) throw new Error('cancelled');             // withdrawn while the connection was being made
    const id = seq++;
    if (ticket) ticket.id = id;
    return new Promise((resolve, reject) => {
        pending.set(id, { resolve, reject, ticket: !!ticket });
        try { channel.postMessage({ t: 'a', id, x: extraLevel, ...payload }); }
        catch (error) { pending.delete(id); reject(error); }
    });
}

// ------------------------------------------------------------------------------- the viewer's corrections
// The backend holds the learning memory. A choice is handed to it (kept here until a connection exists); what the memory says
// about a picture comes back with the picture's analysis, and can be asked again after the memory changed.

/** Hand a choice to the backend: { op: 'record' | 'forget', k, y, e, sys, spread }. */
export function correct(op) {
    outbox.push(op);
    flushOutbox();                              // at once when a connection exists, also while the models are still loading
    connect().then(flushOutbox, () => {});
}
function flushOutbox() {
    while (port && outbox.length) {
        try { port.postMessage({ t: 'c', ...outbox[0] }); } catch { return; }
        outbox.shift();
    }
}

/** Ask what the learning memory says now about pictures already judged. items: [[key, signature], …] → their summaries. */
export async function corrections(items) {
    const channel = await connect();
    const id = seq++;
    const reply = await new Promise((resolve, reject) => {
        pending.set(id, { resolve, reject, ticket: false });
        try { channel.postMessage({ t: 'f', id, q: items }); }
        catch (error) { pending.delete(id); reject(error); }
    });
    return { list: Array.isArray(reply.f) ? reply.f : [], version: reply.fv };
}

/** Called when the learning memory changed. */
export function onFeedback(listener) { feedbackListeners.add(listener); }
/** Called when the backend greets on a new connection after an earlier one was lost. */
export function onReconnect(listener) { reconnectListeners.add(listener); }

export function cancel(id) {
    if (!port || !pending.has(id)) return;
    try { port.postMessage({ t: 'x', id }); } catch {}
}

/** Tell the backend that a queued request became more or less urgent. */
export function reprioritize(id, pri) {
    if (!port || !pending.has(id)) return;
    try { port.postMessage({ t: 'p', id, pri }); } catch {}
}

/** Called whenever the backend reports an (almost) empty queue. */
export function onIdle(listener) { idleListeners.add(listener); }
export const isIdle = () => perf.queue <= 1 && pending.size <= 2;

// ------------------------------------------------------------------------------- sizing
/** Detector input size for an image, from the speed and the queue the backend last reported (shared/sizing.js). */
export const pickSize = (naturalLongest) => inputSize(naturalLongest, perf.t320, perf.queue);

// ------------------------------------------------------------------------------- pixels
// At most a few in-page encodes at once: they share the page's main thread.
let grabbing = 0;
const grabWaiters = [];

/**
 * Downscale an image, video or canvas and return it as a JPEG data URL. Throws if cross-origin tainted.
 * `stillWanted` (optional) is called when the encode's turn comes and may throw: a picture withdrawn while it waited is not encoded.
 */
export async function grab(source, size, stillWanted) {
    while (grabbing >= 3) await new Promise((resolve) => grabWaiters.push(resolve));
    grabbing++;
    try {
        stillWanted?.();
        return await encode(source, size);
    } finally {
        grabbing--;
        grabWaiters.shift()?.();
    }
}

export async function encode(source, size) {
    const width = source.naturalWidth || source.videoWidth || source.width;
    const height = source.naturalHeight || source.videoHeight || source.height;
    if (!width || !height) throw new Error('no pixels');
    const scale = Math.min(1, size / Math.max(width, height));
    const canvas = new OffscreenCanvas(Math.max(1, Math.round(width * scale)), Math.max(1, Math.round(height * scale)));
    const ctx = canvas.getContext('2d', { alpha: false });
    ctx.fillStyle = 'rgb(128,128,128)';                                 // transparent pixels on mid-gray, as the models expect
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(source, 0, 0, canvas.width, canvas.height);        // synchronous snapshot
    const blob = await canvas.convertToBlob({ type: 'image/jpeg', quality: 0.85 });   // throws if tainted
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = () => reject(reader.error);
        reader.readAsDataURL(blob);
    });
}

const ANIMATED = /^image\/(gif|webp|png|apng|avif)$/i;
const ANIMATED_MAX_BYTES = 8e6;
/** The file's own bytes as a data URL, when readable from this page and possibly animated; otherwise null. */
async function originalBytes(url, source) {
    if (url.startsWith('data:')) return null;
    const likely = /\.(gif|webp|png|apng|avif)(\?|#|$)/i.test(url) || url.startsWith('blob:') || !/\.(jpe?g)(\?|#|$)/i.test(url);
    if (!likely) return null;
    try {
        const response = await fetch(url, { credentials: 'same-origin', cache: 'force-cache', mode: url.startsWith('blob:') || sameOrigin(url) ? 'same-origin' : 'cors' });
        if (!response.ok) return null;
        const type = (response.headers.get('content-type') || '').split(';')[0].trim();
        if (!ANIMATED.test(type)) return null;
        const blob = await response.blob();
        if (blob.size > ANIMATED_MAX_BYTES) return null;
        return await new Promise((resolve, reject) => { const r = new FileReader(); r.onload = () => resolve(r.result); r.onerror = () => reject(r.error); r.readAsDataURL(blob); });
    } catch { return null; }
}

function loadImage(url) {
    return new Promise((resolve, reject) => {
        const image = new Image();
        image.onload = () => resolve(image);
        image.onerror = () => reject(new Error('image load failed'));
        image.src = url;
    });
}

// ------------------------------------------------------------------------------- URL → analysis
function sameOrigin(url) {
    try { return new URL(url, location.href).origin === location.origin; } catch { return false; }
}

export function hash(text) {
    let h1 = 0xdeadbeef ^ text.length, h2 = 0x41c6ce57;
    for (let i = 0; i < text.length; i++) {
        const c = text.charCodeAt(i);
        h1 = Math.imul(h1 ^ c, 2654435761);
        h2 = Math.imul(h2 ^ c, 1597334677);
    }
    return (h2 >>> 0).toString(36) + (h1 >>> 0).toString(36) + text.length.toString(36);
}

const localCache = new Map();

/**
 * Does a cached analysis hold everything the current settings ask for? The same rule as the backend cache (offscreen.js):
 * with extra models on, CLIP must have run (x ≥ 5 values; ≥ 8 with the face model) and with the backend's current detector.
 * 0.15 and before: the page cache checked the size only, so turning the extra models on — or a model change — kept serving
 * detector-only results for pictures already seen on the page (review of 0.15, finding 5).
 */
export function complete(analysis, level = extraLevel) {
    if (!analysis) return false;
    if (analysis.skip || analysis.blank || level === 0) return true;
    if (perf.model && analysis.d && analysis.d !== perf.model) return false;
    if (analysis.ex) return true;                                   // an early exit is complete by design
    return Array.isArray(analysis.x) && analysis.x.length >= (level >= 2 ? 8 : 5);
}

function remember(url, analysis) {
    localCache.delete(url);
    localCache.set(url, analysis);
    if (localCache.size > 800) localCache.delete(localCache.keys().next().value);
}

/**
 * Get the analysis for an image URL. Tries, in order: this page's cache, the backend cache,
 * a backend fetch of the URL, and pixels read in the page (same-origin, data:, blob:, CORS).
 * `size` may be a function, evaluated when the request is actually sent.
 */
export async function analyzeUrl(url, size, pri, getSource, ticket) {
    const sizeNow = () => (typeof size === 'function' ? size() : size);
    const hidden = () => typeof document !== 'undefined' && document.visibilityState === 'hidden';
    const cached = localCache.get(url);
    let wanted = sizeNow();
    // A result of this page is reused as long as the learning memory it was answered with is the current one.
    if (cached && (cached.s >= wanted || cached.s >= 480) && complete(cached) && cached.fv === perf.fv) return cached;
    if (hidden()) await whenVisible();
    await connect();
    wanted = sizeNow();              // the size belongs to the moment the request is sent, with the backend's speed and queue known
    // A picture withdrawn (ticket.gone: it left the page or scrolled away before it was sent) or a tab that went to the
    // background is not encoded and not sent; the caller puts it back to "wait" and asks again when it is wanted.
    const stillWanted = () => { if (ticket?.gone || hidden()) throw new Error('cancelled'); };
    stillWanted();

    const isData = url.startsWith('data:'), isBlob = url.startsWith('blob:');
    const source = getSource ? getSource() : null;
    const local = isData || isBlob || sameOrigin(url) || (source && source.crossOrigin != null);
    const fk = hash(url);            // the picture's key in the learning memory (main.js: keyOf)
    const key = isBlob ? null : isData ? 'd:' + fk : 'u:' + url;
    // Pixels read in the page: the original bytes when the file may be animated (GIF, WebP, APNG, AVIF) — the backend then
    // checks several frames — otherwise a JPEG of what is drawn. 0.16: before, a same-origin animation was reduced to one
    // still frame, and its clear verdict covered the whole animation (review of 0.15, finding 7).
    const pixels = async () => (isData ? url : (await originalBytes(url, source)) || grab(source || await loadImage(url), wanted, stillWanted));
    const fatal = (error) => /cancelled|disconnected/.test(error.message);
    const ask = (payload) => { stillWanted(); return send({ key, fk, S: wanted, pri, ...payload }, ticket); };
    const viaPixels = async () => ask({ data: await pixels() });
    const viaFetch = () => ask({ url });

    let reply;
    if (isBlob) {
        reply = await viaPixels();
    } else if (local) {
        reply = await ask({ local: true });      // cache lookup only
        if (reply.need === 'pixels') {
            try { reply = await viaPixels(); }
            catch (error) {
                if (fatal(error) || isData) throw error;
                reply = await viaFetch();
            }
        }
    } else {
        try { reply = await viaFetch(); }
        catch (error) {
            if (fatal(error)) throw error;
            reply = await viaPixels();          // backend could not fetch it; works only if readable here
        }
    }
    if (!reply.a) throw new Error('no analysis');
    if (!isBlob) remember(url, reply.a);
    return reply.a;
}
