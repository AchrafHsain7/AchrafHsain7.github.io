// LowerYourGaze — content script: the fail-closed gate.
// Every image, video, canvas and CSS background starts covered and is revealed only by a clear verdict.
// AGPL-3.0.
import { DEFAULTS, STORAGE_KEY, COVER_KEY, TINY_PX, CANVAS_MIN_PX } from '../shared/constants.js';
import { ENSEMBLE } from '../shared/ensemble-data.js';
import { decide, setEnsembleEnabled, systemCovers, keywordStep, showSpreads } from '../shared/verdict.js';
import { cueOf } from '../shared/context.js';
import { shadowCss } from './css.js';
import { send, connect, cancel, reprioritize, perf, pickSize, grab, analyzeUrl, onIdle, isIdle, hash, setExtraLevel, correct, corrections, onFeedback, onReconnect } from './backend.js';
import { VideoScreen } from './screen.js';

const SVG_NS = 'http://www.w3.org/2000/svg';
const XHTML_NS = 'http://www.w3.org/1999/xhtml';
const ATTR = 'data-lyg';
const BG_ATTR = 'data-lyg-bg';
const PSEUDO_ATTR = 'data-lyg-pb';
const SCREEN_ATTR = 'data-lyg-screen';
const MO_OPTIONS = {
    childList: true, subtree: true, attributes: true, characterData: true,
    attributeFilter: ['src', 'srcset', 'sizes', 'poster', 'href', 'xlink:href', 'class', 'style', 'alt', 'title', 'aria-label', 'controls', ATTR, BG_ATTR, PSEUDO_ATTR, SCREEN_ATTR],
};
const TEXT_ATTRS = new Set(['alt', 'title', 'aria-label']);
const VIDEO = {
    // screenHoldMs / tailMs: system lab round 2 (video simulator on v7 and generated videos, test split, three machine speeds):
    // a 1.5 s hold and a 400 ms tail halve the flicker of the 0.9 releases (strict 16.7 → 8.6 switches/min, balanced 21 → 10)
    // at equal or lower exposure (strict 6.5 → 6.2 %, balanced 12.7 → 8.9 % on the fast machine).
    balanced: { need: 3, spanMs: 900, holdMs: 4000, screenHoldMs: 1500, tailMs: 400 },
    strict: { need: 5, spanMs: 2000, holdMs: 8000, screenHoldMs: 1500, tailMs: 400 },
};
const BG_SKIP = new Set(['img', 'video', 'script', 'style', 'link', 'meta', 'head', 'title', 'br', 'canvas', 'iframe', 'source', 'template', 'noscript']);

let settings = { ...DEFAULTS };
let active = true;          // filtering is on for this page
let siteMode = 'normal';    // 'normal' | 'anyone' | 'all'
let pageCueLevel = 0;      // words in the page's address, title or breadcrumb: 2 strong, 1 soft, 0 none
let contextKey = '';
let gen = 0;

const states = new WeakMap();        // element → state
const pseudoStates = new WeakMap();  // element → state of its ::before / ::after backgrounds
const tracked = new WeakSet();       // elements handed to the IntersectionObservers
const near = new WeakSet();          // close to the viewport: checked now
const far = new WeakSet();           // further out: checked ahead of time when the detector is idle
const farWaiting = new Set();
const rootSet = new WeakSet();
const rootRefs = [];
const defsByRoot = new WeakMap();
const screens = new WeakSet();       // overlay canvases we created
let sheet = null;
let filterSeq = 0;

const topUrl = () => {
    try {
        const chain = location.ancestorOrigins;
        return chain && chain.length ? chain[chain.length - 1] : location.href;
    } catch { return location.href; }
};
const topHost = (() => {
    try { return new URL(topUrl()).hostname.replace(/^www\./, ''); }
    catch { return (location.hostname || '').replace(/^www\./, ''); }
})();

// ------------------------------------------------------------------------------- helpers
const isSvgUrl = (url) => /^data:image\/svg/i.test(url) || /\.svg(?:$|[?#])/i.test(url);

function inViewport(rect) {
    return rect.bottom > 0 && rect.right > 0 && rect.top < innerHeight && rect.left < innerWidth;
}

// ------------------------------------------------------------------------------- words near a picture
// Words around a picture make its own decision stricter; they never cover it by themselves. Three scopes:
// the picture's own text (alt, title, label, its link, its caption), the card or section around it (its label
// and headings), and the page (address, title, breadcrumb). The nearer the words, the larger the step.
const SECTION_SEL = 'article, section, li, figure, [role="article"], [role="listitem"], [class*="card" i], [class*="product" i], [class*="tile" i], [class*="item" i]';
const SECTION_HEAD = 'h1, h2, h3, h4, h5, h6, figcaption, [class*="title" i], [id*="title" i], [class*="caption" i]';
const MAX_SECTION_PICTURES = 12;     // a "section" holding more pictures than this is a listing, not a card: page scope instead

/** The picture's own words: alt, title and label, the link it sits in, the figure caption beside it. */
function ownText(el) {
    let text = `${el.getAttribute('alt') || ''} ${el.getAttribute('title') || ''} ${el.getAttribute('aria-label') || ''}`;
    for (let node = el.parentElement, depth = 0; node && depth < 2; node = node.parentElement, depth++) {
        const label = node.getAttribute('aria-label') || node.getAttribute('title');
        if (label) text += ` ${label}`;
    }
    const link = el.closest('a');
    if (link) text += ` ${link.getAttribute('title') || ''} ${link.getAttribute('aria-label') || ''} ${(link.textContent || '').slice(0, 160)}`;
    const caption = el.closest('figure')?.querySelector('figcaption');
    if (caption) text += ` ${(caption.textContent || '').slice(0, 200)}`;
    return text;
}

/** Words of the card or section around the picture: its label and its headings. Empty when there is no small container. */
function sectionText(el) {
    let node = el.parentElement?.closest(SECTION_SEL);
    for (let hops = 0; node && hops < 3; hops++, node = node.parentElement?.closest(SECTION_SEL)) {
        if (node === document.body || node === document.documentElement) return '';
        if (node.querySelectorAll('img, video, picture').length > MAX_SECTION_PICTURES) return '';
        let text = `${node.getAttribute('aria-label') || ''} ${node.getAttribute('title') || ''}`;
        for (const head of [...node.querySelectorAll(SECTION_HEAD)].slice(0, 4)) text += ` ${(head.textContent || '').slice(0, 160)}`;
        if (text.trim()) return text;
    }
    return '';
}

const contextOn = () => settings.context !== 'off' && settings.context !== false;

/** Nothing on this page is revealed: the viewer set this site to "Everything". */
const coverAll = () => siteMode === 'all';

/** Use the "anyone" rule (no person clears) instead of the chosen strictness: the viewer set this site to "Anyone". */
const elevatedFor = () => siteMode === 'anyone';

let cuesRead = false;       // some picture on this page has read the words around it

/** Strictness step for this picture from the words around it (cached per picture; the page part is read live). */
function keywordBonus(el, st) {
    if (!contextOn()) return 0;
    if (el && st && st.cues === undefined) {
        try { st.cues = [cueOf(ownText(el)), cueOf(sectionText(el))]; } catch { st.cues = [0, 0]; }
        cuesRead = true;
    }
    const [own, section] = st?.cues || [0, 0];
    return keywordStep(own, section, pageCueLevel);
}

/** The key of an image address (hash), cached on the picture's state for its current address. */
function keyOf(st, url = st?.url) {
    if (!url) return null;
    if (st.keyUrl !== url) { st.keyUrl = url; st.key = hash(url); }
    return st.key;
}

// The picture's key in the learning memory went to the backend with the request (backend.js: fk); what the memory says about
// it came back with the analysis (analysis.f), so no key is needed here.
const blocks = (analysis, el, st) => decide(analysis, settings.strictness, elevatedFor(), null, keywordBonus(el, st)).block;

// Words change after a picture was judged: a site that recycles its cards (YouTube's lists) gives an image element a new title,
// label or caption, or fills them in late. The cached words of the pictures nearby are dropped, and a picture whose words
// changed is judged again from its stored result — no new detector work, and a video keeps playing (0.18 — review of 0.17,
// text finding 1: the words were read once per picture and never again).
const textDirty = new Set();
let textTimer = 0;
const TEXT_FLUSH_MS = 250, TEXT_MAX_SCOPES = 64, TEXT_MAX_PICTURES = 200;
const PICTURE_SEL = 'img, input[type="image" i], image, canvas, video';

const hasWords = (node) => node.nodeType === 3 ? !!node.data.trim() : node.nodeType === 1 && !node.matches(PICTURE_SEL) && !!node.textContent?.trim();
function wordsChanged(record) {
    for (const node of record.addedNodes) if (hasWords(node)) return true;
    for (const node of record.removedNodes) if (hasWords(node)) return true;
    return false;
}

function markText(node) {
    if (!node || node.nodeType !== 1 || !contextOn()) return;
    textDirty.add(node);
    if (!textTimer) textTimer = setTimeout(flushText, TEXT_FLUSH_MS);
}

/**
 * The element whose pictures may read words from `node`: its link, figure or card, widened to the cards around it. Null for
 * a listing (more pictures than a card holds): words added to a long list belong to its new items, which are read fresh.
 */
function textScope(node) {
    if (node === document.body || node === document.documentElement) return null;
    const many = (el) => el.querySelectorAll('img, video, picture').length > MAX_SECTION_PICTURES;
    let scope = node.closest(`a, figure, ${SECTION_SEL}`) || node;
    if (scope === document.body || scope === document.documentElement || many(scope)) return node.matches(PICTURE_SEL) ? node : null;
    for (let hops = 0; hops < 2; hops++) {
        const up = scope.parentElement?.closest(SECTION_SEL);
        if (!up || up === document.body || up === document.documentElement) break;
        if (up.querySelectorAll('img, video, picture').length > MAX_SECTION_PICTURES) break;
        scope = up;
    }
    return scope;
}

function flushText() {
    textTimer = 0;
    if (!active) { textDirty.clear(); return; }
    const scopes = new Set();
    let looked = 0;
    for (const node of textDirty) {
        textDirty.delete(node);
        const scope = node.isConnected ? textScope(node) : null;
        if (scope) scopes.add(scope);
        if (scopes.size >= TEXT_MAX_SCOPES || ++looked >= 4 * TEXT_MAX_SCOPES) break;     // the rest waits for the next round
    }
    let seen = 0;
    for (const scope of scopes) {
        const list = [scope, ...scope.querySelectorAll(PICTURE_SEL)];
        for (const el of list) {
            const st = states.get(el);
            if (!st || st.cues === undefined) continue;
            if (++seen > TEXT_MAX_PICTURES) break;
            const before = st.cues;
            st.cues = undefined;
            keywordBonus(el, st);
            if (before && before[0] === st.cues[0] && before[1] === st.cues[1]) continue;
            rejudgeOne(el, st);
        }
    }
    if (textDirty.size) textTimer = setTimeout(flushText, TEXT_FLUSH_MS);
}


// ------------------------------------------------------------------------------- the viewer's own choices
// "Show this image / video" and "Cover this image / video" from the right-click menu, the popup or a
// keyboard shortcut. A choice overrules the detector for that one picture. Images are remembered by
// address: "show" until the page is closed, "cover" permanently. A video's choice lasts until it
// loads something else.
const manualUrls = new Map();      // image address → 'show' | 'cover'
const manualEls = new WeakMap();   // video or canvas → { mode, src }
let coverHashes = new Set();       // stored "cover" choices, as hashes of image addresses

function manualFor(el, st) {
    const own = manualEls.get(el);
    if (own) {
        if (own.src === (el.currentSrc || el.src || '')) return own.mode;
        manualEls.delete(el);                                  // it plays something else now
    }
    if (!manualUrls.size && !coverHashes.size) return null;
    const urls = st.kind === 'img' ? [st.url] : st.kind === 'bg' ? (st.urls || []) : [];
    for (const url of urls) { const mode = url && manualUrls.get(url); if (mode) return mode; }
    if (coverHashes.size && urls.length) {
        st.hashes ||= urls.filter(Boolean).map(hash);
        for (const key of st.hashes) if (coverHashes.has(key)) return 'cover';
    }
    return null;
}

// ------------------------------------------------------------------------------- verdict → DOM
function syncAttr(el, st, name = ATTR) {
    let want = st.attr ?? null;
    const manual = manualFor(el, st);
    if (manual === 'show') want = 'c';
    else if (manual === 'cover') want = 'b';
    const have = el.getAttribute(name);
    if (want === null) { if (have !== null) el.removeAttribute(name); }
    else if (have !== want) el.setAttribute(name, want);
}

/** The DOM attributes mirror our state; anything else that writes them is overruled. */
function police(el, name) {
    const st = name === PSEUDO_ATTR ? pseudoStates.get(el) : states.get(el);
    const mine = st && (name === BG_ATTR ? st.kind === 'bg' : name === PSEUDO_ATTR ? true : st.kind !== 'bg');
    if (mine) syncAttr(el, st, name);
    else if (el.hasAttribute(name)) el.removeAttribute(name);
}

/** Withdraw a request: one already sent is cancelled in the backend, one not sent yet (hidden tab, pixels being read) never goes. */
function withdraw(ticket) {
    if (!ticket) return;
    if (ticket.id) cancel(ticket.id); else ticket.gone = true;
}

function release(el, st) {
    withdraw(st.ticket);
    for (const ticket of st.tickets || []) withdraw(ticket);
    if (st.timer) clearTimeout(st.timer);
    dropRegion(el, st);
    farWaiting.delete(el);
}

function applyVerdict(el, st) {
    // A choice made before this picture's result arrived is learned now (0.18 — review of 0.17, corrections finding 6).
    if (pendingLearn.size && st.kind === 'img') {
        const key = keyOf(st), y = pendingLearn.get(key);
        if (y !== undefined) { pendingLearn.delete(key); learn(el, st, y); }
    }
    // A site the viewer set to "Everything" reveals nothing; otherwise each picture is judged on its own.
    const verdict = coverAll()
        ? { block: true, reasons: ['site'], regions: null }
        : decide(st.analysis, settings.strictness, elevatedFor(), null, keywordBonus(el, st));
    st.verdict = verdict;
    dropRegion(el, st);
    if (!verdict.block) st.attr = 'c';
    else if (settings.mode === 'region' && st.kind === 'img' && el.localName === 'img' && verdict.regions && buildRegion(el, st, verdict.regions)) st.attr = 'r';
    else st.attr = 'b';
    syncAttr(el, st);
}

// ------------------------------------------------------------------------------- region blur
function defsFor(root) {
    let svg = defsByRoot.get(root);
    if (svg && svg.isConnected) return svg;
    svg = document.createElementNS(SVG_NS, 'svg');
    svg.setAttribute('data-lyg-defs', '');
    svg.setAttribute('aria-hidden', 'true');
    svg.setAttribute('width', '0');
    svg.setAttribute('height', '0');
    svg.style.cssText = 'position:absolute!important;width:0!important;height:0!important;overflow:hidden!important;pointer-events:none!important';
    (root === document ? document.documentElement : root).appendChild(svg);
    defsByRoot.set(root, svg);
    return svg;
}

const regionResize = new ResizeObserver((entries) => {
    for (const entry of entries) {
        const el = entry.target, st = states.get(el);
        if (!st || st.attr !== 'r' || !st.analysis) continue;
        if (st.regionBox === `${el.offsetWidth}x${el.offsetHeight}`) continue;
        applyVerdict(el, st);
    }
});

function dropRegion(el, st) {
    if (!st.filter) return;
    st.filter.remove();
    st.filter = null;
    el.style.removeProperty('--lyg-rf');
    regionResize.unobserve(el);
}

/** Blur only the given regions (normalised image coordinates) of an <img>. False → use full blur. */
function buildRegion(img, st, regions) {
    const W = img.offsetWidth, H = img.offsetHeight, nw = img.naturalWidth, nh = img.naturalHeight;
    if (!W || !H || !nw || !nh || !regions.length) return false;
    const cs = getComputedStyle(img);
    const px = (value) => parseFloat(value) || 0;
    const left = px(cs.borderLeftWidth) + px(cs.paddingLeft), top = px(cs.borderTopWidth) + px(cs.paddingTop);
    const cw = W - left - px(cs.borderRightWidth) - px(cs.paddingRight);
    const ch = H - top - px(cs.borderBottomWidth) - px(cs.paddingBottom);
    if (cw <= 0 || ch <= 0) return false;

    let dw, dh;
    if (cs.objectFit === 'fill') { dw = cw; dh = ch; }
    else if (cs.objectFit === 'contain' || cs.objectFit === 'cover') {
        const scale = cs.objectFit === 'contain' ? Math.min(cw / nw, ch / nh) : Math.max(cw / nw, ch / nh);
        dw = nw * scale; dh = nh * scale;
    } else return false;
    const position = cs.objectPosition.trim().split(/\s+/);
    if (position.length !== 2) return false;
    const offset = (token, free) => (token.endsWith('%') ? free * parseFloat(token) / 100 : token.endsWith('px') ? parseFloat(token) : NaN);
    const ox = offset(position[0], cw - dw), oy = offset(position[1], ch - dh);
    if (!Number.isFinite(ox) || !Number.isFinite(oy)) return false;

    const clamp = (v) => Math.min(1, Math.max(0, v));
    const boxes = [];
    for (const [x1, y1, x2, y2] of regions) {
        const ex1 = clamp((left + ox + x1 * dw) / W), ey1 = clamp((top + oy + y1 * dh) / H);
        const ex2 = clamp((left + ox + x2 * dw) / W), ey2 = clamp((top + oy + y2 * dh) / H);
        if (ex2 - ex1 > 0 && ey2 - ey1 > 0) boxes.push([ex1, ey1, ex2 - ex1, ey2 - ey1]);
    }
    if (!boxes.length) return false;

    const root = img.getRootNode();
    const svg = defsFor(root instanceof ShadowRoot ? root : document);
    const make = (name, attrs) => {
        const node = document.createElementNS(SVG_NS, name);
        for (const [key, value] of Object.entries(attrs)) node.setAttribute(key, String(value));
        return node;
    };
    const id = `lyg-f-${++filterSeq}`;
    const blurPx = Math.max(10, Math.min(40, Number(settings.blur) || 28));
    const filter = make('filter', { id, primitiveUnits: 'objectBoundingBox', x: 0, y: 0, width: 1, height: 1, 'color-interpolation-filters': 'sRGB' });
    filter.append(make('feGaussianBlur', { in: 'SourceGraphic', stdDeviation: `${blurPx / W} ${blurPx / H}`, result: 'soft' }));
    let blurred = 'soft';
    if (settings.gray) { filter.append(make('feColorMatrix', { in: 'soft', type: 'saturate', values: 0, result: 'grey' })); blurred = 'grey'; }
    const mask = make('feMerge', { result: 'mask' });
    boxes.forEach(([x, y, width, height], i) => {
        filter.append(make('feFlood', { 'flood-color': '#000', x, y, width, height, result: `r${i}` }));
        mask.append(make('feMergeNode', { in: `r${i}` }));
    });
    filter.append(mask);
    filter.append(make('feComposite', { in: blurred, in2: 'mask', operator: 'in', result: 'cut' }));
    const final = make('feMerge', {});
    final.append(make('feMergeNode', { in: 'SourceGraphic' }), make('feMergeNode', { in: 'cut' }));
    filter.append(final);
    svg.append(filter);

    st.filter = filter;
    st.regionBox = `${W}x${H}`;
    img.style.setProperty('--lyg-rf', `url(#${id})`);
    regionResize.observe(img);
    return true;
}

// ------------------------------------------------------------------------------- images
// <img>, <input type="image"> and SVG <image> share one path.
const sizeWatch = new ResizeObserver((entries) => {
    for (const entry of entries) {
        const el = entry.target, st = states.get(el);
        if (!st || (st.kind !== 'img' && st.kind !== 'cv')) { sizeWatch.unobserve(el); continue; }
        if (st.tiny) {
            const rect = el.getBoundingClientRect();
            const floor = st.kind === 'cv' ? CANVAS_MIN_PX : TINY_PX;
            if (Math.min(rect.width, rect.height) >= floor) { states.delete(el); sizeWatch.unobserve(el); st.kind === 'cv' ? evaluateCanvas(el) : evaluateImg(el); }
        } else if (st.status === 'wait') (st.kind === 'cv' ? advanceCanvas : advanceImg)(el, st);
        else sizeWatch.unobserve(el);
    }
});

function imageUrl(el) {
    if (el.localName === 'img') return el.currentSrc || el.src || '';
    if (el.localName === 'input') return el.src || '';
    return el.href?.baseVal || el.getAttribute('href') || el.getAttribute('xlink:href') || '';       // SVG <image>
}

function watch(el) {
    if (tracked.has(el)) return;
    tracked.add(el);
    nearView.observe(el);
    farView.observe(el);
}

function evaluateImg(el) {
    if (!active || !settings.images) return;
    watch(el);
    let url = imageUrl(el);
    if (url && el.localName !== 'img') { try { url = new URL(url, el.baseURI).href; } catch {} }
    let st = states.get(el);
    if (st && st.kind === 'img' && st.url === url && st.gen === gen) {
        syncAttr(el, st);
        if (st.status === 'wait') advanceImg(el, st);
        return;
    }
    if (st) release(el, st);
    st = { kind: 'img', url, gen, status: 'wait', attr: null, tries: 0 };
    states.set(el, st);
    syncAttr(el, st);                 // attribute removed → covered until proven clear
    advanceImg(el, st);
}

function advanceImg(el, st) {
    if (st.status !== 'wait' || !st.url) return;
    if (isSvgUrl(st.url)) { st.status = 'done'; st.attr = 'c'; syncAttr(el, st); return; }
    const isImg = el.localName === 'img';
    if (isImg && (!el.complete || !el.naturalWidth)) return;      // the load event re-enters
    const isNear = near.has(el);
    if (!isNear) {
        // Further down the page: check ahead of time, but only while the detector has nothing better to do.
        if (!far.has(el)) return;
        if (!isIdle()) { if (farWaiting.size > 600) farWaiting.clear(); farWaiting.add(el); return; }
    }
    const rect = el.getBoundingClientRect();
    if (rect.width < 1 || rect.height < 1) { sizeWatch.observe(el); return; }
    if (Math.min(rect.width, rect.height) < TINY_PX || (isImg && Math.min(el.naturalWidth, el.naturalHeight) < 12)) {
        st.status = 'done'; st.tiny = true; st.attr = 'c';
        syncAttr(el, st);
        sizeWatch.observe(el);
        return;
    }
    farWaiting.delete(el);
    st.status = 'queued';
    st.ticket = {};
    st.pri = isNear ? (inViewport(rect) ? 1 : 3) : 6;
    const natural = isImg ? Math.max(el.naturalWidth, el.naturalHeight) : Math.max(rect.width, rect.height) * (devicePixelRatio || 1);
    analyzeUrl(st.url, () => pickSize(natural), st.pri, () => (isImg ? el : null), st.ticket).then((analysis) => {
        if (states.get(el) !== st) return;
        st.status = 'done'; st.ticket = null; st.analysis = analysis;
        applyVerdict(el, st);
    }, (error) => {
        if (states.get(el) !== st) return;
        st.ticket = null;
        if (/cancelled/.test(error.message)) {
            st.status = 'wait';
            if (near.has(el)) advanceImg(el, st);      // it came back into view while the cancel was in flight
            return;
        }
        st.status = 'error';
        if (st.tries++ < 2) st.timer = setTimeout(() => {
            st.timer = 0;
            if (states.get(el) === st && st.status === 'error') { st.status = 'wait'; advanceImg(el, st); }
        }, 2500 * st.tries);
    });
}

// The detector reports an empty queue: check a few images that are not near the viewport yet.
onIdle(() => {
    if (!active || !farWaiting.size) return;
    let budget = 3;
    for (const el of farWaiting) {
        farWaiting.delete(el);
        const st = states.get(el);
        if (!st || st.status !== 'wait' || !el.isConnected) continue;
        advanceImg(el, st);
        if (--budget <= 0) break;
    }
});

// ------------------------------------------------------------------------------- canvases
/** 16×16 luminance thumbnail of a canvas. Throws SecurityError when the canvas is cross-origin tainted. */
function canvasThumb(canvas) {
    // A fresh surface every time: drawing one tainted canvas would poison a shared one for good.
    const probe = new OffscreenCanvas(16, 16).getContext('2d', { willReadFrequently: true, alpha: false });
    probe.fillStyle = '#808080';
    probe.fillRect(0, 0, 16, 16);
    probe.drawImage(canvas, 0, 0, 16, 16);
    const rgba = probe.getImageData(0, 0, 16, 16).data;
    const thumb = new Uint8Array(256);
    let lo = 255, hi = 0;
    for (let i = 0, p = 0; i < 256; i++, p += 4) {
        const v = (rgba[p] * 3 + rgba[p + 1] * 6 + rgba[p + 2]) / 10;
        thumb[i] = v; if (v < lo) lo = v; if (v > hi) hi = v;
    }
    thumb.blank = hi - lo < 10;
    return thumb;
}

function thumbDiff(a, b) {
    let sum = 0;
    for (let i = 0; i < 256; i++) sum += Math.abs(a[i] - b[i]);
    return sum / 256;
}

function evaluateCanvas(canvas) {
    if (!active || !settings.canvases) return;
    if (canvas.hasAttribute(SCREEN_ATTR)) {
        if (screens.has(canvas)) return;                 // our own video screen
        canvas.removeAttribute(SCREEN_ATTR);             // a page cannot exempt its canvas by copying the marker
    }
    watch(canvas);
    let st = states.get(canvas);
    if (st && st.kind === 'cv' && st.gen === gen) { syncAttr(canvas, st); if (st.status === 'wait') advanceCanvas(canvas, st); return; }
    if (st) release(canvas, st);
    st = { kind: 'cv', gen, status: 'wait', attr: null, thumb: null, timer: 0 };
    states.set(canvas, st);
    syncAttr(canvas, st);
    advanceCanvas(canvas, st);
}

function advanceCanvas(canvas, st) {
    if (st.status !== 'wait' || !near.has(canvas)) return;
    const rect = canvas.getBoundingClientRect();
    if (rect.width < 1 || rect.height < 1) { sizeWatch.observe(canvas); return; }
    if (Math.min(rect.width, rect.height) < CANVAS_MIN_PX || Math.min(canvas.width, canvas.height) < 32) {
        st.status = 'done'; st.tiny = true; st.attr = 'c';
        syncAttr(canvas, st);
        sizeWatch.observe(canvas);
        return;
    }
    if (coverAll()) return;
    st.status = 'live';
    stepCanvas(canvas, st);
}

/** Canvases change without notice: watch a thumbnail and re-run the detector when the picture changes. */
async function stepCanvas(canvas, st) {
    st.timer = 0;
    if (states.get(canvas) !== st || !canvas.isConnected || !active || !settings.canvases) return;
    if (st.busy) { st.again = true; return; }
    st.busy = true;
    const strict = settings.strictness === 'strict' || elevatedFor();
    let next = 1000;
    try {
        if (coverAll()) {
            st.attr = null; syncAttr(canvas, st);
        } else if (near.has(canvas) && !document.hidden) {
            const thumb = canvasThumb(canvas);
            const changed = !st.thumb || thumbDiff(thumb, st.thumb) > 5;
            if (thumb.blank) {
                // Nothing drawn, or a WebGL canvas whose buffer cannot be read from outside its frame.
                st.thumb = thumb; st.attr = strict ? null : 'c';
                syncAttr(canvas, st);
            } else if (changed || st.attr === null) {
                // A new picture: strict covers it until it is checked; balanced keeps showing a canvas that was clear.
                if (changed && (strict || st.attr !== 'c')) { st.attr = null; syncAttr(canvas, st); }
                st.thumb = null;                         // committed only once the new picture has a verdict
                await connect();                         // the backend's greeting: its speed sets the size of the snapshot (pickSize)
                if (states.get(canvas) !== st) return;
                const size = pickSize(Math.max(canvas.width, canvas.height));
                // One immutable snapshot is both what the models judge and what the canvas is compared with afterwards. 0.17:
                // before, the comparison thumbnail was taken before the pixels, which could wait behind other encodes — a picture
                // B could be judged while the canvas was compared with A (review of 0.16, finding 5).
                const scale = Math.min(1, size / Math.max(canvas.width, canvas.height, 1));
                const shot = new OffscreenCanvas(Math.max(1, Math.round(canvas.width * scale)), Math.max(1, Math.round(canvas.height * scale)));
                const shotCtx = shot.getContext('2d', { alpha: false });
                shotCtx.fillStyle = 'rgb(128,128,128)'; shotCtx.fillRect(0, 0, shot.width, shot.height);
                shotCtx.drawImage(canvas, 0, 0, shot.width, shot.height);       // synchronous
                const sent = canvasThumb(shot);
                const reply = await send({ data: await grab(shot, size), S: size, pri: 2 });
                if (states.get(canvas) !== st) return;
                st.analysis = reply.a;
                const cv = decide(reply.a, settings.strictness, elevatedFor(), null, keywordBonus(canvas, st));
                // The verdict belongs to the picture that was sent. If the canvas now shows a different picture (by the same
                // 16 × 16 comparison that detects changes; a redraw of the same picture does not count), a clear verdict must not
                // reveal it: the canvas keeps the state it had during the check and is checked again at once. A cover still
                // applies (0.16; before, the old verdict was applied to the changed canvas — review of 0.15, finding 6).
                let moved;
                try { moved = thumbDiff(canvasThumb(canvas), sent) > 5; } catch { moved = true; }
                if (moved && !cv.block) {
                    st.again = true;                     // the canvas keeps the state it had while this check ran (strict: covered)
                } else {
                    st.thumb = sent;
                    st.attr = cv.block ? 'b' : 'c';
                    syncAttr(canvas, st);
                }
                next = 600;
            }
        }
    } catch (error) {
        // Cross-origin tainted: its pixels cannot be read. Strict keeps it covered; balanced shows it.
        if (error?.name === 'SecurityError') { st.attr = strict ? null : 'c'; syncAttr(canvas, st); next = 4000; }
        else { st.attr = null; syncAttr(canvas, st); next = 1500; }      // the check failed: covered until it succeeds
    } finally {
        st.busy = false;
    }
    if (states.get(canvas) !== st || !canvas.isConnected) return;
    if (st.again) { st.again = false; next = 0; }
    st.timer = setTimeout(() => stepCanvas(canvas, st), next);
}

/** The page drew on a canvas (announced by page-hook.js): look at it now instead of at the next poll. */
function canvasDrawn(canvas) {
    const st = states.get(canvas);
    if (!st || st.kind !== 'cv') { evaluateCanvas(canvas); return; }
    if (st.status !== 'live') { if (st.status === 'wait') advanceCanvas(canvas, st); return; }
    if (st.busy) { st.again = true; return; }
    if (st.timer) clearTimeout(st.timer);
    stepCanvas(canvas, st);
}

// ------------------------------------------------------------------------------- CSS backgrounds
// Elements whose backgrounds are to be looked at: a stack, so what changed last (a hover, a class change) is looked at first,
// also while a scan of the whole page is still being worked through. An element queued several times — its class and its
// style changed in one step, or it changed again while it waited — is looked at once: an older entry is skipped when the
// element has been looked at since that entry was made. (0.19.4 looked once per entry: three style computations each time.)
const bgPending = [], bgStamp = [];
const bgLooked = new WeakMap();      // element → the clock when it was last looked at
let bgClock = 0;
let bgTimer = 0;
function queueBg(el) { bgPending.push(el); bgStamp.push(++bgClock); }

function extractUrls(value) {
    const urls = [];
    const re = /url\((?:"((?:[^"\\]|\\.)*)"|'((?:[^'\\]|\\.)*)'|([^)]*))\)/g;
    let match;
    while ((match = re.exec(value))) urls.push((match[1] ?? match[2] ?? match[3] ?? '').replace(/\\(.)/g, '$1').trim());
    return urls.filter(Boolean);
}

/**
 * Bring an element's background state (or its pseudo-elements' state) in line with its computed style.
 * `value` is the computed background-image; `map`/`attr` select the element or pseudo-element track.
 */
function reconcileBg(el, value, map, attr) {
    let st = map.get(el);
    const hasUrl = value && value !== 'none' && value.includes('url(');
    const urls = hasUrl ? extractUrls(value) : [];
    const photos = urls.filter((url) => !isSvgUrl(url));
    if (!photos.length) {
        // No photo background. Inline-style backgrounds are hidden by CSS until marked clear.
        const inline = attr === BG_ATTR && urls.length > 0;
        if (st) { release(el, st); map.delete(el); }
        if (inline) { st = { kind: 'bg', url: '', gen, status: 'done', attr: 'c' }; map.set(el, st); syncAttr(el, st, attr); }
        else if (el.hasAttribute(attr)) el.removeAttribute(attr);
        return;
    }
    const signature = photos.join(' ');
    if (st && st.url === signature && st.gen === gen) { syncAttr(el, st, attr); if (st.status === 'wait') advanceBg(el, st, attr); return; }
    if (st) release(el, st);
    const width = el.offsetWidth, height = el.offsetHeight;
    st = { kind: 'bg', url: signature, urls: photos.slice(0, 3), over: photos.length > 3, gen, status: 'wait', attr: 'u' };
    map.set(el, st);
    if (width && height && Math.min(width, height) < TINY_PX) { st.status = 'done'; st.attr = 'c'; }      // icon-sized
    syncAttr(el, st, attr);            // hidden until proven clear
    if (st.status !== 'wait') return;
    watch(el);
    advanceBg(el, st, attr);
}

function checkBg(el) {
    if (!el.isConnected || !active || !settings.backgrounds) return;
    reconcileBg(el, getComputedStyle(el).backgroundImage, states, BG_ATTR);
    const before = getComputedStyle(el, '::before').backgroundImage;
    const after = getComputedStyle(el, '::after').backgroundImage;
    const pseudo = [before, after].filter((v) => v && v !== 'none' && v.includes('url(')).join(', ');
    if (pseudo || pseudoStates.has(el)) reconcileBg(el, pseudo, pseudoStates, PSEUDO_ATTR);
}

function advanceBg(el, st, attr) {
    if (st.status !== 'wait' || !near.has(el) || coverAll()) return;
    st.status = 'queued';
    if (st.over) { st.status = 'done'; st.attr = 'b'; syncAttr(el, st, attr); return; }
    const rect = el.getBoundingClientRect();
    const natural = Math.max(rect.width, rect.height) * (devicePixelRatio || 1) * 1.5;
    st.tickets = st.urls.map(() => ({}));
    Promise.all(st.urls.map((url, i) => analyzeUrl(url, () => pickSize(natural), inViewport(rect) ? 2 : 4, null, st.tickets[i]))).then((list) => {
        if ((attr === BG_ATTR ? states : pseudoStates).get(el) !== st) return;
        st.status = 'done'; st.tickets = null; st.analyses = list;
        st.attr = list.some((analysis) => blocks(analysis, el, st)) ? 'b' : 'c';
        syncAttr(el, st, attr);
    }, (error) => {
        if ((attr === BG_ATTR ? states : pseudoStates).get(el) !== st) return;
        st.tickets = null;
        st.status = /cancelled/.test(error.message) ? 'wait' : 'error';   // stays hidden
        if (st.status === 'wait' && near.has(el)) advanceBg(el, st, attr);
    });
}

function flushBg(budgetMs = 6) {
    const started = performance.now();
    while (bgPending.length) {
        const el = bgPending.pop(), queuedAt = bgStamp.pop();
        if ((bgLooked.get(el) || 0) > queuedAt) continue;
        bgLooked.set(el, ++bgClock);
        checkBg(el);
        if (performance.now() - started > budgetMs) {
            if (!bgTimer) bgTimer = setTimeout(() => { bgTimer = 0; flushBg(10); }, 0);
            return;
        }
    }
}

let rescanTimer = 0;
function scheduleRescan(delay = 400) {
    if (rescanTimer) return;
    rescanTimer = setTimeout(() => { rescanTimer = 0; rescanAll(); }, delay);
}

// ------------------------------------------------------------------------------- video
// Two ways to gate a video. "screen": frames are checked before they are shown (see screen.js).
// "direct": the real video is revealed after clear samples and re-hidden on a hit or a scene cut;
// used when a screen cannot be laid over the video, and when the user chooses it.
const CUT_THRESHOLD = 26;

function wantsScreen(video) {
    return settings.videoMode !== 'direct' && typeof video.requestVideoFrameCallback === 'function'
        && !video.controls && document.fullscreenElement !== video
        && manualFor(video, VIDEO_KIND) !== 'show';             // shown by the viewer: the real video plays
}
const VIDEO_KIND = { kind: 'vid' };
const lastCover = new WeakMap();      // video → was its previous sampled frame covered?
const clearRun = new WeakMap();       // video → samples in a row that are clear without the band
const RELEASE_SAMPLES = 3;

const screenDeps = {
    send,
    // Frames of one video are judged with hysteresis: a score hovering at the threshold does not flicker. The band is
    // bounded: it ends at a scene cut (the new scene is judged on its own) and after RELEASE_SAMPLES samples that are
    // clear on their own — otherwise a man who follows a woman, scoring just under the threshold, stays covered.
    verdict: (analysis, video, fresh = false) => {
        const elevated = elevatedFor(), bonus = keywordBonus(video, states.get(video));
        let was = fresh ? false : (lastCover.get(video) ?? false);
        const raw = decide(analysis, settings.strictness, elevated, false, bonus);
        const run = raw.block ? 0 : (clearRun.get(video) || 0) + 1;
        clearRun.set(video, run);
        if (run >= RELEASE_SAMPLES) was = false;
        const verdict = was ? decide(analysis, settings.strictness, elevated, true, bonus) : raw;
        lastCover.set(video, verdict.block);
        return verdict.block ? (verdict.weak ? 'w' : 'b') : 'c';
    },
    settings: () => ({
        blur: settings.blur, gray: settings.gray, strict: settings.strictness === 'strict',
        holdMs: (VIDEO[settings.strictness] || VIDEO.strict).screenHoldMs,
        tailMs: (VIDEO[settings.strictness] || VIDEO.strict).tailMs,
        freezeMs: Number.isFinite(+settings.videoFreezeMs) ? +settings.videoFreezeMs : 700,
        delayMs: +settings.videoDelayMs || 0,
        fast: settings.videoSample === 'fast',
    }),
    similarity: () => ({
        mode: settings.videoSimilar || 'off', ssim: +settings.videoSimSsim || 0.875, chroma: +settings.videoSimColour || 6,
        edge: +settings.videoSimEdge || 1, shift: settings.videoSimShift !== false, refreshMs: +settings.videoSimRefreshMs || 0,
        clip: +settings.videoSimClip || 0, fit: settings.videoSimBy === 'fit' ? ENSEMBLE.videoSim || null : null,
    }),
    isNear: (video) => near.has(video),
    locked: (video) => (manualFor(video, VIDEO_KIND) === 'cover' ? 'manual' : coverAll() ? 'site' : ''),
    isActive: () => active && settings.videos,
    extraLevel: () => (settings.extras ? 1 : 0),
    sampleSize: (modelMs) => (perf.t320 && perf.t320 <= 40 && modelMs < 120 ? 480 : 320),     // 0.15: the models' own time, not capture → verdict
    unusable: (video) => {
        const st = states.get(video);
        if (st?.kind === 'vid' && st.screen) { st.noScreen = true; trackVideo(video, true); }
    },
};

function setVideo(video, st, attr) {
    st.attr = attr;
    syncAttr(video, st);
}

function trackVideo(video, rebuild = false) {
    if (!active || !settings.videos) return;
    if (!tracked.has(video)) {
        tracked.add(video);
        nearView.observe(video);
        try { video.disablePictureInPicture = true; } catch {}    // PiP windows ignore page CSS
    }
    let st = states.get(video);
    const useScreen = wantsScreen(video) && !st?.noScreen;
    if (!st || st.kind !== 'vid' || st.gen !== gen || rebuild || useScreen !== !!st.screen || st.screen?.dead) {
        const noScreen = st?.noScreen && st.gen === gen;
        if (st?.kind === 'vid') stopVideo(video, st);
        st = { kind: 'vid', gen, attr: null, clears: 0, firstClear: 0, hold: 0, busy: false, timer: 0, lastTime: -1, cutAt: 0, rvfc: 0, thumb: null, noScreen, screen: null,
            level: 1, levelTryAt: 0 };      // direct mode starts with CLIP, as the screen does (0.17 — review of 0.16, finding 4)
        states.set(video, st);
        syncAttr(video, st);
        if (useScreen && !noScreen) {
            st.screen = new VideoScreen(video, screenDeps);
            for (const canvas of st.screen.canvases) screens.add(canvas);
        }
    }
    if (st.screen) st.screen.poke(); else kickVideo(video);
}

function stopVideo(video, st) {
    if (st.timer) clearTimeout(st.timer);
    st.timer = 0;
    if (st.screen) { st.screen.destroy(); st.screen = null; }
    video.style.removeProperty('--lyg-vbg');
}

function resetVideo(video) {
    const st = states.get(video);
    if (!st || st.kind !== 'vid') { trackVideo(video); return; }
    if ((wantsScreen(video) && !st.noScreen) !== !!st.screen) { trackVideo(video); return; }
    if (st.screen) { st.screen.reset(); return; }
    st.clears = 0; st.unreadable = false; st.lastTime = -1; st.afterCut = false; st.thumb = null; st.cutAt = performance.now();
    setVideo(video, st, null);
    kickVideo(video);
}

function kickVideo(video) {
    const st = states.get(video);
    if (!st || st.kind !== 'vid') return;
    if (st.screen) { st.screen.poke(); return; }
    if (st.timer || st.busy) return;
    st.timer = setTimeout(() => { st.timer = 0; stepVideo(video, st); }, 0);
}

/** Direct mode: while a video is revealed, a hard cut hides it again before the detector has seen the new scene. */
function watchCuts(video, st) {
    if (st.rvfc || typeof video.requestVideoFrameCallback !== 'function') return;
    const onFrame = () => {
        st.rvfc = 0;
        if (states.get(video) !== st || st.screen || !active || !settings.videos || !settings.videoCuts) return;
        if (st.attr === 'c' && !st.unreadable) {
            try {
                st.cutCtx ||= new OffscreenCanvas(16, 16).getContext('2d', { willReadFrequently: true, alpha: false });
                st.cutCtx.drawImage(video, 0, 0, 16, 16);
                const rgba = st.cutCtx.getImageData(0, 0, 16, 16).data;
                const thumb = new Uint8Array(256);
                for (let i = 0, p = 0; i < 256; i++, p += 4) thumb[i] = (rgba[p] * 3 + rgba[p + 1] * 6 + rgba[p + 2]) / 10;
                if (st.thumb && thumbDiff(thumb, st.thumb) > CUT_THRESHOLD) {
                    st.clears = 0; st.afterCut = true; st.cutAt = performance.now();
                    setVideo(video, st, null);
                    kickVideo(video);
                }
                st.thumb = thumb;
            } catch { st.thumb = null; st.cutCtx = null; }
        } else {
            st.thumb = null;
        }
        if (!video.paused && !video.ended && video.isConnected) st.rvfc = video.requestVideoFrameCallback(onFrame);
    };
    st.rvfc = video.requestVideoFrameCallback(onFrame);
}

/** Direct mode: a tiny, heavily blurred preview behind the hidden frames, so a covered video does not look broken. */
function setPreview(video) {
    try {
        const tiny = document.createElement('canvas');
        tiny.width = 24; tiny.height = Math.max(8, Math.round(24 * video.videoHeight / video.videoWidth));
        const ctx = tiny.getContext('2d');
        ctx.filter = settings.gray ? 'grayscale(1) blur(1px)' : 'blur(1px)';
        ctx.drawImage(video, 0, 0, tiny.width, tiny.height);
        video.style.setProperty('--lyg-vbg', `url("${tiny.toDataURL('image/jpeg', 0.6)}")`);
    } catch {}
}

async function stepVideo(video, st) {
    if (states.get(video) !== st || st.screen || !video.isConnected || !active || !settings.videos) return;
    if (manualFor(video, st)) { syncAttr(video, st); return; }        // the viewer decided: nothing to check
    const rule = VIDEO[settings.strictness] || VIDEO.balanced;
    let delay = 0;      // 0 → stop until an event kicks the loop again
    try {
        if (!near.has(video) || video.readyState < 2 || !video.videoWidth || coverAll()) {
            // nothing rendered yet, or this site reveals nothing
        } else if (video.mediaKeys || st.unreadable) {
            setVideo(video, st, null);              // protected or cross-origin frames cannot be read: stay hidden
        } else if (video.poster && video.played.length === 0 && video.currentTime === 0) {
            // the poster is on screen and frames cannot vouch for it
        } else if ((video.paused || video.ended) && st.lastTime === video.currentTime) {
            // this still frame already has its verdict
        } else {
            st.busy = true;
            const size = perf.t320 && perf.t320 <= 40 ? 480 : 320;
            const time = video.currentTime;
            const still = video.paused || video.ended;
            const grabbedAt = performance.now();
            let data;
            try { data = await grab(video, size); }
            catch (error) { st.unreadable = true; setVideo(video, st, null); throw error; }
            if (st.attr !== 'c') setPreview(video);
            // CLIP runs beside the detector only while verdicts stay quick (same rule as the video screen).
            // The models' own time sets the level, with a trial of CLIP every 10 s while detector-only (0.17, as the screen).
            if (st.level === 1 && st.modelMs > 130) { st.level = 0; st.levelTryAt = performance.now() + 10000; }
            const trial = st.level === 0 && performance.now() >= st.levelTryAt;
            const lvl = settings.extras ? (trial ? 1 : st.level) : 0;
            const reply = await send({ data, S: size, pri: 0, vid: true, x: lvl });
            if (states.get(video) !== st) return;
            const now = performance.now();
            const model = Number.isFinite(reply.ms?.model) ? reply.ms.model : null;
            if (trial && model !== null) { if (model <= 130) { st.level = 1; st.modelMs = model; } else st.levelTryAt = performance.now() + 10000; }
            else if (model !== null) st.modelMs = st.modelMs === undefined ? model : st.modelMs + (model - st.modelMs) * 0.2;
            const letter = screenDeps.verdict(reply.a, video), block = letter !== 'c';
            if (st.cutAt > grabbedAt) {
                // the scene changed after this frame was taken: its verdict says nothing about what is on screen
            } else if (reply.a.blank) {
                st.clears = 0;                      // no evidence: keep the current state
            } else if (block) {
                st.clears = 0; st.afterCut = false; st.hold = now + rule.holdMs;
                setVideo(video, st, 'b');
            } else if (still && video.currentTime === time) {
                setVideo(video, st, 'c');           // a still frame is exactly what is displayed
            } else {
                // Right after a cut out of a clear scene, balanced mode accepts one clear frame of the new scene.
                const quick = st.afterCut && settings.strictness !== 'strict';
                if (st.clears++ === 0) st.firstClear = now;
                if (now >= st.hold && (quick || (st.clears >= rule.need && now - st.firstClear >= rule.spanMs))) {
                    st.afterCut = false;
                    setVideo(video, st, 'c');
                }
            }
            if (still && video.currentTime === time) st.lastTime = time;
            delay = st.attr !== 'c' ? 120 : settings.videoCuts ? (settings.strictness === 'strict' ? 300 : 500) : 200;
        }
    } catch {
        // The check failed (backend restarting, disconnected, a decode error): what is on screen is no longer vouched for.
        // Cover now and require fresh clear evidence before showing again (0.16; before, a clear video stayed clear through
        // failures, with a retry 1.5 s later — review of 0.15, finding 3).
        if (states.get(video) === st) { st.clears = 0; st.afterCut = false; st.hold = 0; setVideo(video, st, null); }
        delay = st.unreadable ? 0 : 1500;
    } finally {
        st.busy = false;
    }
    if (states.get(video) !== st || !video.isConnected) return;
    if (settings.videoCuts && !video.paused && !video.ended) watchCuts(video, st);
    if (!delay && !video.paused && !video.ended && near.has(video) && !st.unreadable) delay = 700;
    if (delay) st.timer = setTimeout(() => { st.timer = 0; stepVideo(video, st); }, delay);
}

// ------------------------------------------------------------------------------- visibility
function onNear(el) {
    const st = states.get(el);
    if (!st) { if (el.localName === 'img') evaluateImg(el); }
    else if (st.kind === 'img') advanceImg(el, st);
    else if (st.kind === 'cv') { if (st.status === 'wait') advanceCanvas(el, st); }
    else if (st.kind === 'vid') kickVideo(el);
    else if (st.kind === 'bg') advanceBg(el, st, BG_ATTR);
    const pseudo = pseudoStates.get(el);
    if (pseudo) advanceBg(el, pseudo, PSEUDO_ATTR);
}

/** Raise or lower the priority of whatever this element has queued. */
function setUrgency(el, urgent) {
    for (const st of [states.get(el), pseudoStates.get(el)]) {
        if (!st || st.status !== 'queued') continue;
        const pri = urgent ? 2 : 6;
        if (st.ticket?.id) reprioritize(st.ticket.id, pri);
        for (const ticket of st.tickets || []) if (ticket.id) reprioritize(ticket.id, pri);
    }
}

function cancelQueued(el) {
    for (const st of [states.get(el), pseudoStates.get(el)]) {
        if (!st || st.status !== 'queued') continue;
        withdraw(st.ticket);
        for (const ticket of st.tickets || []) withdraw(ticket);
    }
}

const nearView = new IntersectionObserver((entries) => {
    for (const entry of entries) {
        const el = entry.target;
        if (entry.isIntersecting) { near.add(el); setUrgency(el, true); onNear(el); continue; }
        near.delete(el);
        // Scrolled past but still within look-ahead range: keep the request, behind the visible ones.
        if (far.has(el)) setUrgency(el, false); else cancelQueued(el);
    }
}, { rootMargin: '300px 200px' });

const farView = new IntersectionObserver((entries) => {
    for (const entry of entries) {
        const el = entry.target;
        if (!entry.isIntersecting) { far.delete(el); farWaiting.delete(el); if (!near.has(el)) cancelQueued(el); continue; }
        far.add(el);
        const st = states.get(el);
        if (st?.kind === 'img' && st.status === 'wait') advanceImg(el, st);
    }
}, { rootMargin: '2000px 600px' });

// ------------------------------------------------------------------------------- DOM traversal
function shadowOf(el) {
    try { return chrome.dom?.openOrClosedShadowRoot?.(el) || el.shadowRoot || null; }
    catch { return el.shadowRoot || null; }
}

// Only some elements can carry a shadow root (div, span, p, section, …, and custom elements): for the others the look-up — an
// extension call, the largest single cost of a scan — is skipped. Which names can is asked of the browser itself, once per
// name, by trying it on a fresh element that never enters the page; no list is kept here that could fall behind the browser.
const hostNames = new Map();        // local name → can an element of this name carry a shadow root?
function canHostShadow(tag) {
    let can = hostNames.get(tag);
    if (can === undefined) {
        if (tag.includes('-')) can = true;          // a custom element: creating one here could run the page's constructor, so it is not tried
        else { try { document.createElementNS(XHTML_NS, tag).attachShadow({ mode: 'closed' }); can = true; } catch (error) { can = error?.name !== 'NotSupportedError'; } }
        hostNames.set(tag, can);
    }
    return can;
}

function visit(el) {
    const tag = el.localName;
    if (el.namespaceURI === XHTML_NS) {
        if (tag === 'img') evaluateImg(el);
        else if (tag === 'video') trackVideo(el);
        else if (tag === 'canvas') evaluateCanvas(el);
        else if (tag === 'input') { if (el.type === 'image') evaluateImg(el); }
        else if (settings.backgrounds && !BG_SKIP.has(tag)) queueBg(el);
        if (canHostShadow(tag)) {
            const root = shadowOf(el);
            if (root) adoptRoot(root);
        }
    } else if (tag === 'image' && el.namespaceURI === SVG_NS) {
        evaluateImg(el);
    }
}

/**
 * Look at an element and everything under it. `seen` (one batch of mutation records): elements already looked at in this
 * batch are not looked at again — the parser reports a parent and then each child, and each report covers the whole subtree.
 */
function scan(node, seen = null) {
    if (seen?.has(node)) return;
    if (node.nodeType === 1) { visit(node); seen?.add(node); }
    if (!node.querySelectorAll) return;
    for (const el of node.querySelectorAll('*')) { visit(el); seen?.add(el); }
}

function liveRoots() {
    const roots = [document];
    for (let i = rootRefs.length - 1; i >= 0; i--) {
        const root = rootRefs[i].deref();
        if (root && root.host?.isConnected) roots.push(root); else if (!root) rootRefs.splice(i, 1);
    }
    return roots;
}

/** Text that says what the page is about: its address, title, breadcrumb trail and declared keywords. */
function pageCue() {
    let text = location.href;
    try {
        text += ` | ${document.title || ''}`;
        const crumb = document.querySelector('nav[aria-label*="breadcrumb" i], [class*="breadcrumb" i], [itemtype*="BreadcrumbList"]');
        if (crumb) text += ` | ${(crumb.textContent || '').slice(0, 300)}`;
        for (const meta of document.querySelectorAll('meta[property="og:title"], meta[name="keywords"]')) text += ` | ${(meta.content || '').slice(0, 300)}`;
        if (window.top !== window) text += ` | ${document.referrer}`;
    } catch {}
    return text;
}

/** Re-read the page's text cues. Returns true when the page's standing changed. */
function refreshContext() {
    const key = pageCue();
    if (key === contextKey) return false;
    contextKey = key;
    const parts = key.split(' | ');
    // Strong words count in the address and the titles; soft words only in the titles, breadcrumb and keywords (not the address).
    const level = parts.some((part) => cueOf(part, false) === 2) ? 2 : cueOf(parts.slice(1).join(' '), false) >= 1 ? 1 : 0;
    if (level === pageCueLevel) return false;
    pageCueLevel = level;
    return true;
}

/**
 * Re-apply the rule to everything already analysed (no new detector work). With `videos` false (corrections or words
 * changed — they do not change how video frames are judged), a playing video is left alone.
 */
function rejudgeAll(videos = true) {
    for (const scope of liveRoots()) {
        for (const el of scope.querySelectorAll(`img, input[type="image" i], image, canvas, video, [${BG_ATTR}], [${PSEUDO_ATTR}]`)) {
            const st = states.get(el);
            if (st?.kind === 'vid') { if (videos) resetVideo(el); }
            else if (st) rejudgeOne(el, st, !videos);
            const pseudo = pseudoStates.get(el);
            if (pseudo?.analyses) { pseudo.attr = pseudo.analyses.some((a) => blocks(a, el, pseudo)) ? 'b' : 'c'; syncAttr(el, pseudo, PSEUDO_ATTR); }
        }
    }
}

/** Judge one picture again from its stored result. A video is not touched: its next frames read the new words. */
function rejudgeOne(el, st, again = true) {
    if (st.kind === 'img' && st.analysis) applyVerdict(el, st, again);
    else if (st.kind === 'cv' && st.analysis) { st.attr = blocks(st.analysis, el, st) ? 'b' : 'c'; syncAttr(el, st); }
    else if (st.kind === 'bg' && st.analyses) { st.attr = st.analyses.some((a) => blocks(a, el, st)) ? 'b' : 'c'; syncAttr(el, st, BG_ATTR); }
}

// Corrections changed (here or in another tab), or the backend started again: everything already judged is judged again
// (0.18 — review of 0.17, corrections findings 1 and 3: "check it again" removed the correction but kept the verdict it had
// made, and a correction made in one tab reached the other tabs only for pictures they had not judged yet). The backend
// holds the learning memory; the page asks it what the memory now says about each picture it has judged — one message for
// the page — and then applies the rule again to the stored results (no new detector work).
function judgedAnalyses() {
    const out = new Map();              // analysis → the picture's key in the learning memory
    const note = (st) => {
        if (!st) return;
        if (st.kind === 'img' && st.analysis) out.set(st.analysis, keyOf(st));
        else if (st.kind === 'cv' && st.analysis) out.set(st.analysis, null);
        else if (st.kind === 'bg' && st.analyses) st.analyses.forEach((analysis, i) => out.set(analysis, st.urls?.[i] ? hash(st.urls[i]) : null));
    };
    for (const scope of liveRoots()) {
        for (const el of scope.querySelectorAll(`img, input[type="image" i], image, canvas, [${BG_ATTR}], [${PSEUDO_ATTR}]`)) { note(states.get(el)); note(pseudoStates.get(el)); }
    }
    return out;
}

/**
 * The connection to the backend was lost and is back (the backend started again): pictures whose check had failed — and had
 * used up its retries while the backend was away — are tried again, instead of staying covered until the page is reloaded.
 */
function retryFailed() {
    if (!active) return;
    for (const scope of liveRoots()) {
        for (const el of scope.querySelectorAll(`img, input[type="image" i], image, [${BG_ATTR}], [${PSEUDO_ATTR}]`)) {
            const st = states.get(el), pseudo = pseudoStates.get(el);
            if (st?.status === 'error') {
                if (st.timer) { clearTimeout(st.timer); st.timer = 0; }
                st.status = 'wait'; st.tries = 0;
                if (st.kind === 'img') advanceImg(el, st); else if (st.kind === 'bg') advanceBg(el, st, BG_ATTR);
            }
            if (pseudo?.status === 'error') { pseudo.status = 'wait'; advanceBg(el, pseudo, PSEUDO_ATTR); }
        }
    }
}

let refreshing = false, refreshAgain = false;
async function refreshCorrections() {
    if (refreshing) { refreshAgain = true; return; }
    refreshing = true;
    try {
        do {
            refreshAgain = false;
            const stale = [...judgedAnalyses()].filter(([analysis]) => analysis.fv !== perf.fv);
            if (!stale.length) continue;
            const answer = await corrections(stale.map(([analysis, key]) => [key, Array.isArray(analysis.e) ? analysis.e : null]));
            stale.forEach(([analysis], i) => { analysis.f = answer.list[i] ?? null; analysis.fv = answer.version; });
            if (active) rejudgeAll(false);
        } while (refreshAgain);
    } catch {
        // The backend went away. Its next connection announces the memory again, and this runs again.
    } finally {
        refreshing = false;
    }
}

function rescanAll() {
    if (!active) return;
    if (refreshContext()) gen++;        // the page's standing changed: everything is evaluated afresh
    for (const root of liveRoots()) {
        if (root !== document) addSheet(root);
        scan(root);
    }
    flushBg(12);
}

// ------------------------------------------------------------------------------- shadow roots
function addSheet(root) {
    if (!sheet) return;
    try {
        const current = root.adoptedStyleSheets;
        if (!current.includes(sheet)) root.adoptedStyleSheets = [...current, sheet];
    } catch {
        if (!root.querySelector('style[data-lyg-style]')) {
            const style = document.createElement('style');
            style.setAttribute('data-lyg-style', '');
            style.textContent = shadowCss(settings, active);
            root.appendChild(style);
        }
    }
}

let hoverAt = 0;
function listen(root) {
    root.addEventListener('load', (event) => {
        const el = event.target;
        if (el?.localName === 'img') evaluateImg(el);
        else if (el?.localName === 'link' && settings.backgrounds) scheduleRescan(300);
    }, true);
    for (const type of ['play', 'playing', 'loadeddata', 'canplay', 'seeked', 'pause', 'timeupdate']) {
        root.addEventListener(type, (event) => { if (event.target?.localName === 'video') { if (states.get(event.target)?.kind === 'vid') kickVideo(event.target); else trackVideo(event.target); } }, true);
    }
    for (const type of ['seeking', 'emptied', 'loadstart']) {
        root.addEventListener(type, (event) => { if (event.target?.localName === 'video') resetVideo(event.target); }, true);
    }
    root.addEventListener('lyg-canvas', (event) => {
        if (active && settings.canvases && event.target?.localName === 'canvas' && !screens.has(event.target)) canvasDrawn(event.target);
    }, true);
    root.addEventListener('lyg-shadow', (event) => {
        const host = event.target;
        if (host?.nodeType !== 1) return;
        const shadow = shadowOf(host);
        if (shadow) adoptRoot(shadow);
    }, true);
    // Backgrounds that only appear on hover: look at what the pointer is over, and its ancestors.
    root.addEventListener('pointerover', (event) => {
        if (!active || !settings.backgrounds) return;
        const now = performance.now();
        if (now - hoverAt < 80) return;
        hoverAt = now;
        let node = event.target;
        for (let depth = 0; node && node.nodeType === 1 && depth < 5; depth++, node = node.parentElement) {
            if (node.namespaceURI === XHTML_NS && !BG_SKIP.has(node.localName)) queueBg(node);
        }
        // Styles settle after the event; look once now and once after transitions start.
        queueMicrotask(flushBg);
        setTimeout(() => { let n = event.target; for (let d = 0; n && n.nodeType === 1 && d < 5; d++, n = n.parentElement) if (n.namespaceURI === XHTML_NS && !BG_SKIP.has(n.localName)) queueBg(n); flushBg(); }, 120);
    }, { capture: true, passive: true });
}

function adoptRoot(root) {
    if (rootSet.has(root)) return;
    rootSet.add(root);
    rootRefs.push(new WeakRef(root));
    addSheet(root);
    // Component libraries often assign adoptedStyleSheets right after attachShadow; re-add ours after them.
    queueMicrotask(() => addSheet(root));
    setTimeout(() => addSheet(root), 250);
    observer.observe(root, MO_OPTIONS);
    listen(root);
    scan(root);
}

// ------------------------------------------------------------------------------- mutations
let lastSeenHref = '', lastSeenTitle = '';
const observer = new MutationObserver((records) => {
    if (!active) return;
    let seen = null;            // elements scanned in this batch
    if ((location.href !== lastSeenHref || document.title !== lastSeenTitle)) {
        lastSeenHref = location.href; lastSeenTitle = document.title;
        if (refreshContext()) { gen++; scheduleRescan(0); }
    }
    for (const record of records) {
        const target = record.target;
        if (record.type === 'characterData') { markText(target.parentElement); continue; }
        if (record.type === 'childList') {
            // Words added or removed (a title filled in, a recycled card's text replaced); new pictures read theirs when scanned.
            // Until some picture has read its words there is nothing to read again (and looking through added nodes for
            // words costs time on every piece the parser adds).
            if (cuesRead && contextOn() && wordsChanged(record)) markText(target);
            for (const node of record.addedNodes) if (node.nodeType === 1) scan(node, seen ||= new Set());
            const tag = target.localName;
            if (tag === 'picture') for (const img of target.querySelectorAll('img')) evaluateImg(img);
            else if (tag === 'video') resetVideo(target);
            const root = target.getRootNode?.();
            if (root && root !== document && rootSet.has(root)) addSheet(root);
            continue;
        }
        const name = record.attributeName, tag = target.localName;
        if (TEXT_ATTRS.has(name)) { markText(target); continue; }
        if (name === ATTR || name === BG_ATTR || name === PSEUDO_ATTR) police(target, name);
        else if (name === SCREEN_ATTR) { if (tag === 'canvas' && !screens.has(target)) evaluateCanvas(target); }
        else if (tag === 'img' || tag === 'image' || (tag === 'input' && target.type === 'image')) {
            if (name === 'src' || name === 'srcset' || name === 'sizes' || name === 'href' || name === 'xlink:href') evaluateImg(target);
            else if (name === 'style') {
                const st = states.get(target);
                if (st?.attr === 'r' && st.filter && !target.style.getPropertyValue('--lyg-rf')) target.style.setProperty('--lyg-rf', `url(#${st.filter.id})`);
            }
        } else if (tag === 'source') {
            const parent = target.parentElement;
            if (parent?.localName === 'picture') for (const img of parent.querySelectorAll('img')) evaluateImg(img);
            else if (parent?.localName === 'video') resetVideo(parent);
        } else if (tag === 'video') {
            if (name === 'src' || name === 'poster') resetVideo(target);
            else if (name === 'controls') trackVideo(target);
        } else if ((name === 'class' || name === 'style') && settings.backgrounds && target.namespaceURI === XHTML_NS && !BG_SKIP.has(tag)) {
            queueBg(target);
        }
    }
    flushBg();
});

// ------------------------------------------------------------------------------- the viewer's choices: actions
let pointerAt = null;       // where the context menu was last opened in this frame
const pendingLearn = new Map();     // image key → +1 cover / −1 show, chosen before the picture's result arrived

/**
 * Learn from a choice: a correction when it disagrees with what the extension decides by itself (models and words, without
 * earlier corrections). The choice itself applies here at once (manualFor); the correction is handed to the backend, which
 * holds the learning memory, applies every tab's choices one at a time, and tells every tab that the memory changed
 * (0.18 — review of 0.17, corrections finding 5: each tab wrote its whole list, so two tabs could undo each other's choices).
 */
function learn(el, st, y) {
    const key = keyOf(st);
    if (!key || !st.analysis) return;
    const bonus = coverAll() ? 0 : keywordBonus(el, st);
    const sys = systemCovers(st.analysis, settings.strictness, elevatedFor(), bonus);
    const e = Array.isArray(st.analysis.e) ? st.analysis.e : null;
    const spread = showSpreads(st.analysis, keywordBonus(el, st));     // a show of a picture CLIP or strong words flagged stays its own
    correct({ op: 'record', k: key, y, e, sys, spread });
}
function unlearn(key) {
    if (key) correct({ op: 'forget', k: key });
}

function hitsAt(x, y) {
    const out = [], seen = new Set();
    const collect = (scope) => {
        let list = [];
        try { list = scope.elementsFromPoint(x, y); } catch {}
        for (const el of list) {
            if (seen.has(el)) continue;
            seen.add(el);
            const shadow = shadowOf(el);
            if (shadow && !seen.has(shadow)) { seen.add(shadow); collect(shadow); }
            out.push(el);
        }
    };
    collect(document);
    return out;
}

const holds = (rect, point) => rect.width > 0 && rect.height > 0
    && point.x >= rect.left && point.x <= rect.right && point.y >= rect.top && point.y <= rect.bottom;

function smallestAt(selector, point, accept) {
    let best = null, bestArea = Infinity;
    for (const scope of liveRoots()) {
        for (const el of scope.querySelectorAll(selector)) {
            if (!accept(el)) continue;
            const rect = el.getBoundingClientRect();
            if (holds(rect, point) && rect.width * rect.height < bestArea) { best = el; bestArea = rect.width * rect.height; }
        }
    }
    return best;
}

/** The video under the pointer. With `orMain`, or without a pointer, falls back to this frame's main video. */
function findVideo(point, orMain) {
    if (point) {
        for (const el of [...point.path, ...hitsAt(point.x, point.y)]) if (el.localName === 'video') return el;
        const under = smallestAt('video', point, () => true);
        if (under || !orMain) return under;
    }
    let best = null, bestScore = 0;
    for (const scope of liveRoots()) {
        for (const video of scope.querySelectorAll('video')) {
            const rect = video.getBoundingClientRect();
            const width = Math.min(rect.right, innerWidth) - Math.max(rect.left, 0), height = Math.min(rect.bottom, innerHeight) - Math.max(rect.top, 0);
            if (width < 120 || height < 90) continue;
            const score = width * height * (video.paused ? 1 : 4);
            if (score > bestScore) { best = video; bestScore = score; }
        }
    }
    return best;
}

/**
 * The pictures under the pointer: the one that was hit, and the pictures of about its size stacked with it. A thumbnail
 * often has a second picture over it — YouTube lays its moving preview (an animated WebP) over the still one while the
 * pointer rests on it — and "Show this image" has to reach the picture that stays when the preview goes (0.18: only the
 * preview was shown, and the still thumbnail under it stayed covered).
 */
function picturesAt(point) {
    const first = findPicture(point);
    if (!first) return [];
    const out = [first], seen = new Set([first.el]);
    const area = (el) => { const r = el.getBoundingClientRect(); return r.width * r.height; };
    const size = area(first.el);
    const add = (found) => {
        if (!found || seen.has(found.el)) return;
        seen.add(found.el);
        const a = area(found.el);
        if (holds(found.el.getBoundingClientRect(), point) && a >= size / 4 && a <= size * 4) out.push(found);
    };
    for (const el of [...point.path, ...hitsAt(point.x, point.y)]) add(pickPicture(el));
    for (const scope of liveRoots()) for (const el of scope.querySelectorAll('img, canvas, input[type="image" i]')) if (!seen.has(el)) add(pickPicture(el));
    return out.slice(0, 4);
}

function pickPicture(el) {
    const st = states.get(el);
    if (st?.kind === 'img' && st.url && !st.tiny) return { el, st, attr: ATTR };
    if (st?.kind === 'cv' && !screens.has(el)) return { el, st, attr: ATTR };
    if (st?.kind === 'bg' && st.urls?.length) return { el, st, attr: BG_ATTR };
    const pseudo = pseudoStates.get(el);
    if (pseudo?.urls?.length) return { el, st: pseudo, attr: PSEUDO_ATTR };
    return null;
}

/** The picture under the pointer: an image, a canvas, or an element with a photo background. */
function findPicture(point) {
    if (!point) return null;
    const pick = pickPicture;
    const hits = hitsAt(point.x, point.y);
    for (const el of [...point.path, ...hits]) { const found = pick(el); if (found) return found; }
    const under = smallestAt('img, canvas, input[type="image"]', point, (el) => !!pick(el));
    if (under) return pick(under);
    for (let node = hits[0]; node; node = node.parentElement) { const found = pick(node); if (found) return found; }
    return null;
}

function resyncAll() {
    for (const scope of liveRoots()) {
        for (const el of scope.querySelectorAll('*')) {
            const st = states.get(el);
            if (st && st.kind !== 'vid') syncAttr(el, st, st.kind === 'bg' ? BG_ATTR : ATTR);
            const pseudo = pseudoStates.get(el);
            if (pseudo) syncAttr(el, pseudo, PSEUDO_ATTR);
        }
    }
}

function storeCovers() {
    const list = [...coverHashes].slice(-4000);
    chrome.storage.local.set({ [COVER_KEY]: list }).catch(() => {});
}

/**
 * Apply a choice. kind: 'image' | 'video' | 'any'; mode: 'show' | 'cover' | 'auto' | 'toggle'.
 * Returns what was changed, for the caller's feedback.
 */
function applyChoice(kind, mode, point) {
    const done = [];
    if (kind === 'video' || (kind === 'any' && point)) {
        const video = findVideo(point, kind === 'video');
        const st = video && states.get(video);
        if (st?.kind === 'vid') {
            let next = mode;
            if (mode === 'toggle') next = manualFor(video, st) === 'show' ? 'auto' : 'show';
            else if (mode === 'toggle-cover') next = manualFor(video, st) === 'cover' ? 'auto' : 'cover';
            if (next === 'auto') manualEls.delete(video);
            else manualEls.set(video, { mode: next, src: video.currentSrc || video.src || '' });
            trackVideo(video, true);
            done.push(`video:${next}`);
        }
    }
    if ((kind === 'image' || kind === 'any') && mode !== 'toggle' && mode !== 'toggle-cover') {
        let stored = false, urlsChanged = false;
        for (const { el, st, attr } of picturesAt(point)) {
            if (st.kind === 'cv') {
                if (mode === 'auto') manualEls.delete(el); else manualEls.set(el, { mode, src: '' });
                syncAttr(el, st, attr);
            } else {
                const urls = (st.kind === 'img' ? [st.url] : st.urls).filter(Boolean);
                for (const url of urls) {
                    if (mode === 'auto') manualUrls.delete(url); else manualUrls.set(url, mode);
                    const key = hash(url);
                    if (mode === 'cover') { if (!coverHashes.has(key)) { coverHashes.add(key); stored = true; } }
                    else if (coverHashes.delete(key)) stored = true;
                }
                st.hashes = null;
                urlsChanged = true;
                // A choice that overrules what the extension decides by itself is a correction to learn from. "Check it again"
                // removes it and judges the picture again at once (0.18: the verdict the correction had made stayed).
                if (st.kind === 'img') {
                    const key = keyOf(st);
                    pendingLearn.delete(key);
                    if (mode === 'auto') { unlearn(key); if (st.analysis) applyVerdict(el, st, true); }
                    else if (st.analysis) learn(el, st, mode === 'cover' ? 1 : -1);
                    else pendingLearn.set(key, mode === 'cover' ? 1 : -1);
                }
            }
            done.push(`image:${mode}`);
        }
        if (stored) storeCovers();
        if (urlsChanged) resyncAll();
    }
    return done;
}

// ------------------------------------------------------------------------------- settings
function setFlag(name, on) {
    const root = document.documentElement;
    if (!root) return;
    if (on) root.setAttribute(name, ''); else root.removeAttribute(name);
}

function applySettings(next) {
    const previous = settings, wasActive = active, previousMode = siteMode;
    settings = { ...DEFAULTS, ...(next || {}) };
    setExtraLevel(settings.extras ? 2 : 0); setEnsembleEnabled(settings.extras);
    const chosen = (settings.sites || {})[topHost] || ((settings.paused || []).includes(topHost) ? 'off' : 'normal');
    siteMode = chosen === 'anyone' || chosen === 'all' ? chosen : 'normal';
    active = !!settings.enabled && chosen !== 'off';

    const root = document.documentElement;
    if (root) {
        setFlag('data-lyg-off', !active);
        setFlag('data-lyg-noimg', !settings.images);
        setFlag('data-lyg-novid', !settings.videos);
        setFlag('data-lyg-nobg', !settings.backgrounds);
        setFlag('data-lyg-nocv', !settings.canvases);
        root.style.setProperty('--lyg-blur', `${Number(settings.blur) || 28}px`);
        root.style.setProperty('--lyg-gray', settings.gray ? '1' : '0');
    }
    try { sheet?.replaceSync(shadowCss(settings, active)); } catch {}

    const coverageChanged = wasActive !== active || previous.images !== settings.images
        || previous.videos !== settings.videos || previous.backgrounds !== settings.backgrounds
        || previous.canvases !== settings.canvases || previous.videoMode !== settings.videoMode
        || (previousMode === 'all') !== (siteMode === 'all') || previous.context !== settings.context || previous.extras !== settings.extras;
    const verdictChanged = previous.strictness !== settings.strictness || previous.mode !== settings.mode
        || previous.blur !== settings.blur || previous.gray !== settings.gray || previous.videoCuts !== settings.videoCuts
        || previousMode !== siteMode;
    const stopVideos = () => { for (const scope of liveRoots()) for (const video of scope.querySelectorAll('video')) { const st = states.get(video); if (st?.kind === 'vid') { stopVideo(video, st); if (st.rvfc) { try { video.cancelVideoFrameCallback(st.rvfc); } catch {} st.rvfc = 0; } states.delete(video); } } };
    if (!active) {
        if (wasActive) stopVideos();
        return;
    }
    // The Videos switch alone turned off: remove every screen and stop direct checks too (0.16; before, only turning the whole
    // extension off did, so a screen stayed over a video that the CSS no longer hid — review of 0.15, finding 4).
    if (previous.videos && !settings.videos) stopVideos();
    if (coverageChanged) { gen++; rescanAll(); return; }
    if (verdictChanged) rejudgeAll();
}

// ------------------------------------------------------------------------------- start
function start() {
    try { sheet = new CSSStyleSheet(); sheet.replaceSync(shadowCss(settings, active)); } catch { sheet = null; }
    refreshContext();
    observer.observe(document, MO_OPTIONS);
    listen(document);
    applySettings(settings);
    scan(document);
    flushBg();

    chrome.storage.local.get(STORAGE_KEY).then((stored) => applySettings(stored[STORAGE_KEY]), () => {});
    onFeedback(refreshCorrections);
    onReconnect(retryFailed);
    chrome.storage.local.get(COVER_KEY).then((stored) => {
        const list = stored[COVER_KEY];
        if (Array.isArray(list) && list.length) { for (const key of list) coverHashes.add(key); resyncAll(); }
    }, () => {});
    chrome.storage.onChanged.addListener((changes, area) => {
        if (area !== 'local') return;
        if (changes[STORAGE_KEY]) applySettings(changes[STORAGE_KEY].newValue);
        if (changes[COVER_KEY]) { coverHashes = new Set(changes[COVER_KEY].newValue || []); resyncAll(); }
    });
    // Right-click menu, popup buttons and keyboard shortcuts: show or cover one image or video.
    window.addEventListener('contextmenu', (event) => {
        pointerAt = { x: event.clientX, y: event.clientY, path: event.composedPath().filter((node) => node.nodeType === 1).slice(0, 16) };
    }, true);
    chrome.runtime.onMessage.addListener((msg, sender, respond) => {
        if (msg?.t !== 'lyg-choice' || !active) return;
        const done = applyChoice(msg.kind, msg.mode, msg.main ? null : pointerAt);
        if (done.length || !msg.main) respond({ done });
    });
    // The popup asks the top frame how this page is being treated.
    if (window.top === window) chrome.runtime.onMessage.addListener((msg, sender, respond) => {
        if (msg?.t === 'lyg-page') respond({ active, siteMode, cue: active && contextOn() ? pageCueLevel : 0, coverAll: active && coverAll(), anyone: active && elevatedFor() });
    });

    const settle = () => { applySettings(settings); rescanAll(); };
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', settle, { once: true });
    window.addEventListener('load', () => {
        rescanAll();
        setTimeout(rescanAll, 1500);
        setTimeout(rescanAll, 5000);
    }, { once: true });
    window.addEventListener('pageshow', (event) => { if (event.persisted) rescanAll(); });
    for (const type of ['popstate', 'hashchange']) window.addEventListener(type, () => { if (active && refreshContext()) { gen++; rescanAll(); } });
    document.addEventListener('fullscreenchange', () => {
        if (!active) return;
        for (const scope of liveRoots()) for (const video of scope.querySelectorAll('video')) trackVideo(video);
    });
}

if (!globalThis.__lygStarted) {
    globalThis.__lygStarted = true;
    start();
}
