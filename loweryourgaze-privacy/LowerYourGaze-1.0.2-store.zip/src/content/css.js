// LowerYourGaze — the gate's CSS. One source for the manifest stylesheet (document) and the
// constructed stylesheet adopted into every shadow root. AGPL-3.0.
const BLUR = 'blur(var(--lyg-blur, 28px)) grayscale(var(--lyg-gray, 1))';
// A CSS blur fades to transparent towards the element's edges, so whatever lies behind the element
// shows through. The spread shadow gives the blur opaque grey to pull in instead; clip-path trims it
// back to the box. Result: an opaque blurred box that cannot be seen through.
const OPAQUE = `filter: ${BLUR} !important; clip-path: inset(0) !important; box-shadow: 0 0 0 calc(var(--lyg-blur, 28px) * 3) #7d7d7d !important;`;
const HIDE_BG = 'background-size: 0 0 !important; background-repeat: no-repeat !important;';

function body({ images, videos, backgrounds, canvases }, scope) {
    const img = scope('img'), vid = scope('vid'), bg = scope('bg'), cv = scope('cv');
    const out = [];
    // Anything without an explicit clear verdict is covered: unverified, blocked and errored alike.
    if (images) {
        out.push(`${img} img:not([data-lyg="c"]):not([data-lyg="r"]), ${img} input[type="image" i]:not([data-lyg="c"]) { ${OPAQUE} }`);
        // Region mode: per-element SVG filter; falls back to the full blur if the variable is lost.
        out.push(`${img} img[data-lyg="r"] { filter: var(--lyg-rf, ${BLUR}) !important; clip-path: inset(0) !important; box-shadow: 0 0 0 calc(var(--lyg-blur, 28px) * 3) #7d7d7d !important; }`);
        out.push(`${img} svg image:not([data-lyg="c"]) { opacity: 0 !important; }`);
    }
    // Video frames are moved out of the element's box instead of being filtered (filters on decoded
    // video render black on some GPUs). What shows is the element's background: a tiny blurred
    // preview, or the overlay screen drawn by the content script.
    if (videos) out.push(`${vid} video:not([data-lyg="c"]) { object-position: -99999px -99999px !important; background: #17191b var(--lyg-vbg, none) center / 100% 100% no-repeat !important; }`);
    if (canvases) out.push(`${cv} canvas:not([data-lyg="c"]):not([data-lyg-screen]) { ${OPAQUE} }`);
    // CSS backgrounds are hidden rather than blurred so that foreground text stays readable.
    // Inline-style backgrounds are hidden from the first paint; stylesheet ones once the scan finds them.
    if (backgrounds) {
        out.push(`${bg} [data-lyg-bg="u"], ${bg} [data-lyg-bg="b"], ${bg} [style*="background"][style*="url("]:not([data-lyg-bg="c"]) { ${HIDE_BG} }`);
        out.push(`${bg} [data-lyg-pb="u"]::before, ${bg} [data-lyg-pb="u"]::after, ${bg} [data-lyg-pb="b"]::before, ${bg} [data-lyg-pb="b"]::after { ${HIDE_BG} }`);
    }
    return out.join('\n');
}

/** Static stylesheet injected by the manifest at document_start. Switches live on <html>. */
export function documentCss() {
    const flags = { img: 'data-lyg-noimg', vid: 'data-lyg-novid', bg: 'data-lyg-nobg', cv: 'data-lyg-nocv' };
    return `/* Generated from src/content/css.js — do not edit. */\n` +
        body({ images: true, videos: true, backgrounds: true, canvases: true }, (k) => `html:not([data-lyg-off]):not([${flags[k]}])`) + '\n';
}

/** Stylesheet for shadow roots, regenerated when settings change. */
export function shadowCss(settings, active) {
    if (!active) return '';
    return body(settings, () => '').replace(/^ +/gm, '');
}
