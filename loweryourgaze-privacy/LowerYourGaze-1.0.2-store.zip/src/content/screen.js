// LowerYourGaze — the video screen. The real <video> is kept out of sight by CSS; this module shows
// what the viewer sees on two canvases laid over it:
//   - a "sharp" canvas that displays buffered frames at the video's own resolution, and
//   - a "blur" canvas that draws a heavy blur, and two label canvases above it ("LowerYourGaze": the app's green, and the
//     same text in bright green whose opacity pulses).
// Frames are buffered for a fraction of a second. A frame is shown sharp only when detector samples
// taken before and after it are clear, with no scene cut in between. AGPL-3.0.

import { mayShow, explain, maybeCut } from '../shared/reveal.js';
import { signature, similar, SIG_W, SIG_H } from '../shared/framesig.js';

const cosine = (a, b) => { let d = 0, na = 0, nb = 0; for (let i = 0; i < a.length; i++) { d += a[i] * b[i]; na += a[i] * a[i]; nb += b[i] * b[i]; } return na && nb ? d / Math.sqrt(na * nb) : 0; };

const MAX_FRAMES = 48;
const MAX_BUFFER_BYTES = 256e6;     // rough cap on buffered frame memory (one visible video; hidden tabs hold none)
const MAX_FRAME_WIDTH = 1920;       // larger videos are buffered at this width
const MIN_FRAME_WIDTH = 640;        // frames are buffered at the size they are shown, never below this (the models need it)
const LABEL_COLOUR = '#1a9159';     // the app's green (logo)
const LABEL_GLOW = '#3ddc84';       // the bright green it pulses to
const MAX_PENDING = 3;              // frame copies in flight; beyond this, frames are skipped
const MIN_CAPTURE_MS = 12;          // at most one copy per 12 ms (0.16)
const CUT_THRESHOLD = 26;           // mean absolute luminance change between checked frames, 0–255
const CUT_CHECK_MS = 0;             // scene-cut check on every frame (system lab: 1–3-frame flashes slipped between 40 ms checks)
const BLUR_REDRAW_MS = 125;
const BLUR_MAX_WIDTH = 1280;
const HOUSEKEEPING_MS = 500;
const MIN_DELAY_MS = 80;
const MAX_DELAY_MS = 480;
const STALL_MS = 700;               // a late verdict freezes the last shown (verified) frame up to this long before blurring
// Sample capacity (system lab, round 3). A machine that keeps up runs each video sample at 480 px with CLIP and the face
// model: frames with a woman shown sharp fell from 6.2 to 3.7 % (fast machine) and 6.5 to 4.9 % (two threads), the
// women never caught in a scene from 98 to 46. Slower machines (one thread) keep 320 px: with face, samples come too seldom.
// 0.15: these are the models' own time per sample (detector + CLIP + face), as the backend measures it — not capture → verdict
// time, which also counts waiting behind the page's pictures. Same ratios as the 0.11 limits on capture → verdict (480 / 200,
// 170 / 75 ms), less the ~25 % that copying, encoding and decoding added on a quiet page.
const RICH_DOWN_MODEL_MS = 360;     // model time above this: back to 320 px
const RICH_UP_MODEL_MS = 150;       // at 320 px with CLIP under this: try the larger sample again
const LEVEL_DOWN_MODEL_MS = 130;    // at 320 px: model time above this → the detector alone
// Same-picture check 'auto' (the default from 0.18): reuse is turned on for a video whose samples take more than
// AUTO_REUSE_ON_MS of model time on average (a slow machine), and off again below AUTO_REUSE_OFF_MS. On a fast machine the
// models judge every sample (smoother); on a slow one a frame that looks like the last judged one takes
// its verdict without waiting for the models. 0.18.1: 250 / 180 ms (owner: about 150 ms is normal on a 6-core machine).
const AUTO_REUSE_ON_MS = 250, AUTO_REUSE_OFF_MS = 180, AUTO_REUSE_SAMPLES = 5;
const LEVEL_RETRY_MS = 10000;       // … and every 10 s one sample tries detector + CLIP again; it stays if within the limit
// 0.17: a fixed "back up under 55 ms" never fired when the detector alone takes ~60 ms, so a video could stay detector-only
// for good (review of 0.16, finding 4). A trial sample measures the richer level itself.
const RICH_RETRY_MS = 10 * 60e3;    // a machine found too slow is tried again after this
const CAPACITY = { ms: 0, at: 0 };  // model time of rich samples, shared by the videos of all pages
try {
    chrome.storage?.local?.get('lygVideoCapacity2').then((got) => { if (got?.lygVideoCapacity2 && !CAPACITY.at) Object.assign(CAPACITY, got.lygVideoCapacity2); }, () => {});
} catch {}
const saveCapacity = () => { try { chrome.storage?.local?.set({ lygVideoCapacity2: { ms: Math.round(CAPACITY.ms), at: CAPACITY.at } }); } catch {} };     // model time (0.15; 0.11 kept capture → verdict)

const important = (style, name, value) => style.setProperty(name, value, 'important');

export class VideoScreen {
    /**
     * @param {HTMLVideoElement} video
     * @param {{send:Function, verdict:Function, settings:Function, isNear:Function, isActive:Function,
     *          sampleSize:Function, unusable:Function, locked:Function}} deps   locked(video) → '' | 'site' | 'manual'
     */
    constructor(video, deps) {
        this.video = video;
        this.deps = deps;
        const make = () => {
            const canvas = document.createElement('canvas');
            canvas.setAttribute('data-lyg-screen', '');
            canvas.setAttribute('aria-hidden', 'true');
            return canvas;
        };
        this.canvas = make();                 // sharp frames
        this.blurCanvas = make();
        this.labelCanvas = make();            // "LowerYourGaze" over the blur, in the app's green
        this.labelCtx = this.labelCanvas.getContext('2d', { alpha: true });
        this.glowCanvas = make();             // the same text in bright green; only its opacity pulses (compositor work only)
        this.glowCtx = this.glowCanvas.getContext('2d', { alpha: true });
        this.labelKey = '';
        // Only a visible tab keeps frames: a hidden tab releases its buffer (memory) and starts again when shown.
        this.onVisibility = () => { if (document.visibilityState === 'hidden') { this.clearBuffer(); this.showBlur(true); } else this.poke?.(); };
        document.addEventListener('visibilitychange', this.onVisibility);
        this.sharpCtx = this.canvas.getContext('bitmaprenderer');
        this.ctx = this.blurCanvas.getContext('2d', { alpha: true });
        this.tiny = new OffscreenCanvas(16, 16);
        this.tinyCtx = this.tiny.getContext('2d');
        this.newProbe();

        this.frames = [];           // { seq, t, mt, bitmap, bytes }
        this.bytes = 0;
        this.pending = 0;
        this.epoch = 0;             // bumped whenever the buffer is discarded
        this.samples = new Map();   // seq → { v: 'c' clear | 'b' block | 'n' blank, t }
        this.sampleSeqs = [];       // ascending
        this.cuts = [];             // { lo, hi }: a new scene starts at some frame in lo..hi
        this.prevSampleSeq = 0;     // frame number of the previous judged sample
        // Same-picture check (settings.videoSimilar): signatures of frames the model judged.
        this.anchor = null;         // { sig, seq, t, v }: the last frame the model judged
        this.anchorClear = null;    // { sig, seq }: the last frame the model judged clear
        this.sigCtx = null;
        this.seq = 0;
        this.lastSampled = 0;
        this.lastChecked = 0;       // seq of the last frame that had a scene-cut check
        this.lastCheckAt = 0;
        this.shown = 0;             // seq of the sharp frame on screen, 0 when blurred
        this.shownMt = 0;           // media time of that frame
        this.shownT = 0;            // its capture time
        this.lastCaptureT = -1e9;   // capture time of the last copy
        this.inflight = null;       // { sig, seq } of a changed frame the models are judging (reuse)
        this.autoReuse = false;     // 'auto': reuse is on for this video (slow machine)
        this.autoSince = 0;         // samples since 'auto' last switched
        this.blurMt = 0;            // media time of the frame the blur was last drawn from
        this.lastBlurAt = 0;
        this.stallAt = 0;
        this.sampling = false;
        this.unreadable = false;
        this.latency = 120;         // moving average: frame capture → verdict, ms (sets the display delay)
        this.modelMs = 100;         // moving average: the models' own time per sample, ms (sets the sample quality)
        this.sampleToken = 0;       // the newest model request; older completions change nothing
        this.boost = 0;             // extra delay added when verdicts arrive late
        this.thumb = null;
        this.geometry = null;
        this.failures = 0;
        this.captureFailures = 0;
        this.level = 1;             // extra models per sampled frame: 1 = CLIP, 0 = none
        this.levelTryAt = 0;        // when a detector-only video next tries CLIP again
        // rich: 480 px + CLIP + face per sample, unless this machine was recently found too slow for it
        this.sampleCount = 0;
        this.rich = !CAPACITY.ms || CAPACITY.ms <= RICH_DOWN_MODEL_MS || Date.now() - CAPACITY.at > RICH_RETRY_MS;
        if (this.rich && CAPACITY.ms && CAPACITY.ms <= RICH_DOWN_MODEL_MS) this.modelMs = CAPACITY.ms;
        this.legacy = false;        // copy frames through a 2D canvas instead of createImageBitmap(video)
        this.blankMismatch = 0;
        this.dead = false;
        this.rvfc = 0;

        this.onFrame = this.onFrame.bind(this);
        this.resize = new ResizeObserver(() => this.layout());
        this.resize.observe(video);
        this.timer = setInterval(() => this.housekeeping(), HOUSEKEEPING_MS);
        this.layout();
        this.showBlur(true);
        this.arm();
        this.poke();
    }

    get canvases() { return [this.canvas, this.blurCanvas, this.labelCanvas, this.glowCanvas]; }

    // --------------------------------------------------------------------------- geometry
    /** Size and position both canvases over the video. Returns false when that cannot be done. */
    layout() {
        if (this.dead) return false;
        const video = this.video, sharp = this.canvas, blur = this.blurCanvas;
        if (!video.isConnected) { this.destroy(); return false; }
        const cssW = video.offsetWidth, cssH = video.offsetHeight;
        if (!cssW || !cssH) {                                            // not laid out: nothing is visible either
            this.geometry = null;
            for (const canvas of this.canvases) important(canvas.style, 'display', 'none');
            return true;
        }
        try {
            if (sharp.previousSibling !== video || !sharp.isConnected) video.after(sharp);
            if (blur.previousSibling !== sharp || !blur.isConnected) sharp.after(blur);
            if (this.labelCanvas.previousSibling !== blur || !this.labelCanvas.isConnected) blur.after(this.labelCanvas);
            if (this.glowCanvas.previousSibling !== this.labelCanvas || !this.glowCanvas.isConnected) this.labelCanvas.after(this.glowCanvas);
        } catch { return this.fail('cannot attach'); }

        const cs = getComputedStyle(video);
        const want = video.getBoundingClientRect();
        const scaleX = want.width / cssW || 1, scaleY = want.height / cssH || 1;
        let worst = 0;
        for (const canvas of this.canvases) {
            const style = canvas.style;
            important(style, 'position', cs.position === 'fixed' ? 'fixed' : 'absolute');
            important(style, 'display', 'block');
            important(style, 'margin', '0');
            important(style, 'padding', '0');
            important(style, 'border', '0');
            important(style, 'pointer-events', 'none');
            if (canvas !== this.glowCanvas) important(style, 'opacity', '1');      // the glow's opacity is animated
            important(style, 'max-width', 'none');
            important(style, 'max-height', 'none');
            important(style, 'min-width', '0');
            important(style, 'min-height', '0');
            important(style, 'background', 'transparent');
            important(style, 'filter', 'none');
            important(style, 'clip-path', 'none');
            important(style, 'box-shadow', 'none');
            important(style, 'transform', cs.transform && cs.transform !== 'none' ? cs.transform : 'none');
            important(style, 'transform-origin', cs.transformOrigin || '50% 50%');
            important(style, 'z-index', cs.zIndex && cs.zIndex !== 'auto' ? cs.zIndex : 'auto');
            important(style, 'width', `${cssW}px`);
            important(style, 'height', `${cssH}px`);
            important(style, 'object-fit', canvas === sharp ? (cs.objectFit || 'contain') : 'fill');
            important(style, 'object-position', '50% 50%');
            if (!canvas.lygPlaced) { important(style, 'left', `${video.offsetLeft}px`); important(style, 'top', `${video.offsetTop}px`); canvas.lygPlaced = true; }
            // Correct for a containing block that differs from the video's offset parent.
            let have = canvas.getBoundingClientRect();
            if (Math.abs(have.left - want.left) > 0.75 || Math.abs(have.top - want.top) > 0.75) {
                important(style, 'left', `${(parseFloat(style.left) || 0) + (want.left - have.left) / scaleX}px`);
                important(style, 'top', `${(parseFloat(style.top) || 0) + (want.top - have.top) / scaleY}px`);
                have = canvas.getBoundingClientRect();
            }
            worst = Math.max(worst, Math.abs(have.left - want.left), Math.abs(have.top - want.top),
                Math.abs(have.width - want.width), Math.abs(have.height - want.height));
        }
        if (worst > 3) return this.fail('cannot align');
        this.failures = 0;

        // Geometry of the blur canvas (the sharp canvas takes each frame's own resolution).
        const dpr = Math.min(window.devicePixelRatio || 1, 2);
        let bw = Math.max(2, Math.round(cssW * dpr)), bh = Math.max(2, Math.round(cssH * dpr));
        if (bw > BLUR_MAX_WIDTH) { bh = Math.round(bh * BLUR_MAX_WIDTH / bw); bw = BLUR_MAX_WIDTH; }
        const vw = video.videoWidth || bw, vh = video.videoHeight || bh;
        let dw = bw, dh = bh;
        if (cs.objectFit === 'cover') { const s = Math.max(bw / vw, bh / vh); dw = vw * s; dh = vh * s; }
        else if (cs.objectFit !== 'fill') { const s = Math.min(bw / vw, bh / vh); dw = vw * s; dh = vh * s; }
        dw = Math.max(2, Math.round(dw)); dh = Math.max(2, Math.round(dh));
        const old = this.geometry;
        this.geometry = { bw, bh, dw, dh, dx: Math.round((bw - dw) / 2), dy: Math.round((bh - dh) / 2), dpr: bw / cssW };
        if (!old || old.bw !== bw || old.bh !== bh || old.dw !== dw || old.dh !== dh) {
            if (blur.width !== bw) blur.width = bw;
            if (blur.height !== bh) blur.height = bh;
            for (const label of [this.labelCanvas, this.glowCanvas]) {
                if (label.width !== bw) label.width = bw;
                if (label.height !== bh) label.height = bh;
            }
            this.labelKey = '';
            if (!this.shown) this.drawBlur(true);
        }
        this.applyVisibility();
        return true;
    }

    fail(reason) {
        if (++this.failures >= 3) this.deps.unusable(this.video, reason);
        return false;
    }

    applyVisibility() {
        important(this.canvas.style, 'visibility', this.shown ? 'visible' : 'hidden');
        important(this.blurCanvas.style, 'visibility', this.shown ? 'hidden' : 'visible');
        important(this.labelCanvas.style, 'visibility', this.shown ? 'hidden' : 'visible');
        important(this.glowCanvas.style, 'visibility', this.shown ? 'hidden' : 'visible');
        this.pulse(!this.shown);
    }

    /** The label pulses from the app's green to bright green while the video is covered (not with reduced motion). */
    pulse(on) {
        const label = this.glowCanvas;
        if (!on) { if (this.pulseAnim) { this.pulseAnim.cancel(); this.pulseAnim = null; } return; }
        if (this.pulseAnim || matchMedia('(prefers-reduced-motion: reduce)').matches) return;
        try { this.pulseAnim = label.animate([{ opacity: 0 }, { opacity: 1 }, { opacity: 0 }], { duration: 2400, iterations: Infinity, easing: 'ease-in-out' }); } catch {}
    }

    // --------------------------------------------------------------------------- buffer
    drop(frame) {
        if (frame.bitmap) { try { frame.bitmap.close(); } catch {} frame.bitmap = null; }
        this.bytes -= frame.bytes;
        frame.bytes = 0;
    }

    clearBuffer() {
        this.epoch++;
        this.sampleToken++;          // a request in flight now belongs to the old buffer: its result is dropped
        this.sampling = false; this.samplingChange = false; this.inflight = null;
        this.lastCaptureT = -1e9;    // the new buffer's first frame is never refused by the rate limit (0.17 — review of 0.16, finding 3)
        for (const frame of this.frames) this.drop(frame);
        this.frames = [];
        this.bytes = 0;
        this.samples.clear(); this.sampleSeqs = []; this.cuts = []; this.prevSampleSeq = 0; this.anchor = null; this.anchorClear = null; this.changed = null;
        this.thumb = null;
        this.lastChecked = 0;
    }

    /** A fresh read-back surface: one cross-origin frame taints a canvas for good. */
    newProbe() {
        this.probe = new OffscreenCanvas(16, 16).getContext('2d', { willReadFrequently: true, alpha: false });
    }

    /** New source or a seek: nothing buffered says anything about what comes next. */
    reset() {
        this.unreadable = false;
        this.newProbe();
        this.clearBuffer();
        this.showBlur(true);
        this.poke();
    }

    /** Copy the video's current frame into the buffer (asynchronous, GPU-side where available). */
    /** @param {number} [mediaTime] the presented frame's media time from requestVideoFrameCallback (0.15; video.currentTime
     *  can be a frame off, which matters at 1–3-frame appearances) */
    capture(mediaTime) {
        const video = this.video;
        if (video.readyState < 2 || !video.videoWidth || this.pending >= MAX_PENDING) return;
        const t = performance.now();
        // At most one copy per MIN_CAPTURE_MS (≈ 83 a second): a 120 fps video is copied every other frame, so the buffer spans
        // the display delay (review of 0.15, finding 2). Frames not copied are never shown.
        if (t - this.lastCaptureT < MIN_CAPTURE_MS) return;
        this.lastCaptureT = t;
        const seq = ++this.seq, mt = Number.isFinite(mediaTime) ? mediaTime : video.currentTime, epoch = this.epoch;
        this.checkCut(seq, t);
        // Buffered at the size the video is shown (memory: a 1080p frame is 8 MB, the same frame at 1280 px 3.7 MB).
        const shownWidth = Math.round((video.offsetWidth || video.videoWidth) * Math.min(window.devicePixelRatio || 1, 2));
        const limit = Math.min(MAX_FRAME_WIDTH, Math.max(MIN_FRAME_WIDTH, shownWidth));
        let width = video.videoWidth, height = video.videoHeight;
        if (width > limit) { height = Math.round(height * limit / width); width = limit; }
        const keep = (bitmap) => {
            if (this.dead || epoch !== this.epoch || (this.shown && seq <= this.shown)) { bitmap.close(); return; }     // late copy: never step back
            const frame = { seq, t, mt, bitmap, bytes: bitmap.width * bitmap.height * 4 };
            this.pushFrame(frame);
            this.tick();
            this.sample();
        };
        if (this.legacy) {
            try {
                const copy = new OffscreenCanvas(width, height);
                copy.getContext('2d', { alpha: false }).drawImage(video, 0, 0, width, height);
                keep(copy.transferToImageBitmap());
            } catch { this.deps.unusable(this.video, 'cannot copy frames'); }
            return;
        }
        this.pending++;
        const options = width === video.videoWidth ? undefined : { resizeWidth: width, resizeHeight: height, resizeQuality: 'low' };
        createImageBitmap(video, options).then((bitmap) => {
            this.pending--;
            this.captureFailures = 0;
            keep(bitmap);
        }, () => {
            this.pending--;
            if (++this.captureFailures >= 6) this.useLegacy();
        });
    }

    /** createImageBitmap(video) fails or returns empty frames on this machine: copy through a canvas instead. */
    useLegacy() {
        if (this.legacy) return;
        this.legacy = true;
        this.clearBuffer();
        this.showBlur(true);
    }

    /**
     * Scene-cut check against the previous checked frame, on a 16×16 thumbnail. Read-backs are costly,
     * so not every frame is checked; a cut is recorded as the range of frames it may have happened at.
     */
    checkCut(seq, now) {
        if (this.unreadable || now - this.lastCheckAt < CUT_CHECK_MS) return;
        this.lastCheckAt = now;
        try {
            this.probe.drawImage(this.video, 0, 0, 16, 16);
            const rgba = this.probe.getImageData(0, 0, 16, 16).data;
            const thumb = new Uint8Array(256);
            for (let i = 0, p = 0; i < 256; i++, p += 4) thumb[i] = (rgba[p] * 3 + rgba[p + 1] * 6 + rgba[p + 2]) / 10;
            if (this.thumb) {
                let sum = 0;
                for (let i = 0; i < 256; i++) sum += Math.abs(thumb[i] - this.thumb[i]);
                const diff = sum / 256;
                if (diff > CUT_THRESHOLD) {
                    this.cuts.push({ lo: this.lastChecked + 1, hi: seq });
                    if (this.cuts.length > 64) this.cuts.shift();
                }
            }
            this.thumb = thumb;
            this.lastChecked = seq;
        } catch { this.unreadable = true; }       // cross-origin frames cannot be read, only drawn
    }

    // --------------------------------------------------------------------------- detector samples
    /**
     * Sample the newest buffered frame. Without the same-picture check every sample runs the models, one at a time.
     * With 'reuse' / 'both', a frame that looks like the last frame the models judged (no scene cut since) takes that
     * verdict at once — also while a model check is running — and only a changed picture waits for the models. A clear
     * verdict older than refreshMs is re-checked in the background, without holding the picture back.
     */
    /** The same-picture settings in force for this video ('auto' resolved). */
    similarity() {
        const sim = this.deps.similarity?.() || { mode: 'off' };
        return sim.mode === 'auto' ? { ...sim, mode: this.autoReuse ? 'reuse' : 'off', auto: true } : sim;
    }

    /** 'auto': turn reuse on or off from the machine's speed. Switching drops the anchors, so nothing is reused across it. */
    updateAutoReuse(sim) {
        if (!sim.auto) return;
        this.autoSince++;
        const want = this.autoReuse ? this.modelMs > AUTO_REUSE_OFF_MS
            : this.modelMs > AUTO_REUSE_ON_MS && this.autoSince >= AUTO_REUSE_SAMPLES;
        if (want === this.autoReuse) return;
        this.autoReuse = want; this.autoSince = 0;
        this.anchor = null; this.anchorClear = null; this.changed = null; this.inflight = null;
    }

    async sample() {
        if (this.dead || this.unreadable || this.deps.locked(this.video)) return;
        let frame = null;
        for (let i = this.frames.length - 1; i >= 0; i--) if (this.frames[i].bitmap) { frame = this.frames[i]; break; }
        if (!frame || frame.seq <= this.lastSampled) return;
        const sim = this.similarity();
        const reuse = sim.mode === 'reuse' || sim.mode === 'both';
        if (this.sampling && !reuse) return;
        let sig = null, refresh = false;
        if (sim.mode !== 'off') {
            try { sig = this.signatureOf(frame.bitmap); } catch (error) { if (error?.name === 'SecurityError') { this.unreadable = true; return; } }
        }
        // Reuse needs: no changed picture waiting for the models (it would be vouched for by a later reused verdict), no model
        // check of a changed picture running, no scene cut since the anchor, and the same picture as the anchor.
        // 0.16: a weak cover is never reused (a copy is not a second detection), and only a verdict the model gave itself is an
        // anchor (a "keep" override is not — see below).
        const like = sig && this.anchor && this.anchor.v !== 'w' && !maybeCut(this.cuts, this.anchor.seq, frame.seq) && similar(this.anchor.sig, sig, sim);
        if (reuse && like && !this.changed && !(this.sampling && this.samplingChange)) {
            // A reused verdict older than refreshMs is checked again in the background — a cover as well as a clear (0.15: a
            // covered anchor was never re-checked, so a false cover could last as long as the picture stayed alike).
            refresh = sim.refreshMs > 0 && frame.t - this.anchor.t > sim.refreshMs && !this.sampling;
            this.lastSampled = frame.seq;
            this.record(frame, this.anchor.v, this.anchor);
            // Displaying a frame consumes its pixels; a frame that is also due for a re-check is first copied for the models
            // below, and shown by the next tick (0.17; before, tick() could show — and empty — the frame first, so the re-check
            // failed silently — review of 0.16, finding 2).
            if (!refresh) { this.tick(); return; }
        } else if (reuse && sig && this.sampling && !this.changed) {
            // The models are busy. A frame that differs from what they are judging — the changed frame in flight, or the anchor
            // during a background re-check — is the first change after it: it is judged next, not skipped (0.16; before, a
            // frame was compared with the old anchor while a changed frame was in flight, so a second change was not queued —
            // review of 0.15, similarity finding 3).
            const ref = this.samplingChange ? this.inflight : this.anchor;
            if (!ref || maybeCut(this.cuts, ref.seq, frame.seq) || !similar(ref.sig, sig, sim)) this.changed = frame;
        }
        if (this.sampling) return;                     // a changed picture waits for the running model check
        if (reuse && this.changed) {                   // judge the first changed frame itself, not only a later one
            if (this.changed.bitmap && this.changed.seq > (this.prevSampleSeq || 0)) frame = this.changed;
            else this.lostChange(this.changed);
            this.changed = null;
            if (frame !== this.frames[this.frames.length - 1]) sig = null;     // its own signature is computed below
        }
        this.sampling = true;
        this.samplingChange = reuse && !refresh;
        this.inflight = null;
        this.lastSampled = Math.max(this.lastSampled, frame.seq);
        // Each model request belongs to the buffer it was taken from (epoch) and to this request (token). A result that comes
        // back after a seek or a new source is dropped before it touches any state, and only the newest request may end the
        // "sampling" state (0.15: an old result was applied to the cleared buffer, and its completion cleared newer work's flag).
        const epoch = this.epoch, token = ++this.sampleToken;
        const stale = () => this.dead || epoch !== this.epoch || token !== this.sampleToken;
        let retryIn = 0;
        try {
            if (!sig && sim.mode !== 'off') sig = this.signatureOf(frame.bitmap);
            if (this.samplingChange && sig) this.inflight = { sig, seq: frame.seq };
            const extra = this.deps.extraLevel();
            if (this.rich && this.sampleCount >= 3 && this.modelMs > RICH_DOWN_MODEL_MS) { this.rich = false; CAPACITY.ms = this.modelMs; CAPACITY.at = Date.now(); saveCapacity(); }
            else if (!this.rich && this.level === 1 && this.modelMs < RICH_UP_MODEL_MS) this.rich = true;
            const rich = this.rich && extra >= 1 && !this.deps.settings().fast;
            const size = rich ? 480 : this.deps.sampleSize(this.modelMs);
            const scale = Math.min(1, size / Math.max(frame.bitmap.width, frame.bitmap.height));
            const small = new OffscreenCanvas(Math.max(1, Math.round(frame.bitmap.width * scale)), Math.max(1, Math.round(frame.bitmap.height * scale)));
            small.getContext('2d', { alpha: false }).drawImage(frame.bitmap, 0, 0, small.width, small.height);     // synchronous copy
            const blob = await small.convertToBlob({ type: 'image/jpeg', quality: 0.85 });
            const data = await new Promise((resolve, reject) => {
                const reader = new FileReader();
                reader.onload = () => resolve(reader.result);
                reader.onerror = () => reject(reader.error);
                reader.readAsDataURL(blob);
            });
            // Video frames get the detector plus CLIP (plus face when rich); when the models themselves are too slow on this
            // machine, the detector alone. 0.15: decided on model time, not on capture → verdict time, which also counts waiting
            // behind the page's pictures — a busy page used to take CLIP and the face model away from the video.
            if (this.level === 1 && this.modelMs > LEVEL_DOWN_MODEL_MS) { this.level = 0; this.levelTryAt = performance.now() + LEVEL_RETRY_MS; }
            const trial = !rich && this.level === 0 && extra >= 1 && performance.now() >= this.levelTryAt;
            const lvl = rich ? 2 : trial ? 1 : Math.min(this.level, extra);
            const reply = await this.deps.send({ data, S: size, pri: 0, vid: true, x: lvl });
            if (stale()) return;
            // A scene cut since the previous sample — or no previous sample in this buffer (after a seek or a new source): this
            // frame is judged on its own, without the previous frame's cover.
            const fresh = this.prevSampleSeq === 0 || maybeCut(this.cuts, this.prevSampleSeq, frame.seq);
            this.prevSampleSeq = frame.seq;
            let verdict = reply.a.blank ? 'n' : this.deps.verdict(reply.a, this.video, fresh);   // 'b' covered, 'w' weakly covered, 'c' clear
            let kept = 0;
            if (sig) {
                const model = verdict, clear = this.anchorClear;
                // 'keep': a cover on a frame that looks like the last clear one — by its pixels, or (optionally) by CLIP — is dropped.
                // Protected content and pictures CLIP alone was sure of are never dropped this way.
                if ((sim.mode === 'keep' || sim.mode === 'both') && (verdict === 'b' || verdict === 'w') && !reply.a.pc && reply.a.ex !== 1
                    && clear && !maybeCut(this.cuts, clear.seq, frame.seq)) {
                    if (similar(clear.sig, sig, sim)) kept = 1;
                    else if (sim.clip > 0 && clear.e && Array.isArray(reply.a.e) && cosine(clear.e, reply.a.e) >= sim.clip) kept = 2;
                    if (kept) verdict = 'c';
                }
                if (model === 'c') this.anchorClear = { sig, seq: frame.seq, e: Array.isArray(reply.a.e) ? reply.a.e : null };
                // A cover dropped by "keep" is not the model's clear: it must not become an anchor that clears later frames
                // without a model run (0.16 — review of 0.15, similarity finding 4). The next frame is judged by the models.
                if (kept) this.anchor = null;
                else if (verdict !== 'n') this.anchor = { sig, seq: frame.seq, t: frame.t, v: verdict };
            }
            if (verdict === 'n' && !this.legacy && this.thumb) {
                // The copy is empty but the video is not: the copies cannot be trusted.
                let low = 255, high = 0;
                for (const value of this.thumb) { if (value < low) low = value; if (value > high) high = value; }
                if (high - low > 48) { if (++this.blankMismatch >= 3) { this.useLegacy(); return; } }
                else this.blankMismatch = 0;
            } else if (verdict !== 'n') this.blankMismatch = 0;
            this.record(frame, verdict);
            // The first sample of a video often waits for the models to load: it does not count. Outliers are clipped.
            // latency (capture → verdict) sets the display delay; modelMs (the models' own time) sets the sample quality.
            if (this.sampleCount++ > 0) {
                this.latency += (Math.min(1000, performance.now() - frame.t) - this.latency) * 0.2;
                const model = Number.isFinite(reply.ms?.model) ? reply.ms.model : null;
                if (trial && model !== null) {
                    if (model <= LEVEL_DOWN_MODEL_MS) { this.level = 1; this.modelMs = model; }     // the richer level fits: keep it
                    else this.levelTryAt = performance.now() + LEVEL_RETRY_MS;
                } else if (model !== null) this.modelMs += (Math.min(1000, model) - this.modelMs) * 0.2;
            }
            this.updateAutoReuse(sim);
            if (rich && this.rich) { CAPACITY.ms = this.modelMs; if (!CAPACITY.at || Date.now() - CAPACITY.at > 60e3) { CAPACITY.at = Date.now(); saveCapacity(); } }
        } catch (error) {
            if (stale()) return;
            if (error?.name === 'SecurityError') this.unreadable = true;
            else retryIn = 600;
        } finally {
            if (token === this.sampleToken) { this.sampling = false; this.samplingChange = false; }
        }
        if (stale()) return;
        this.tick();
        if (retryIn) setTimeout(() => this.sample(), retryIn); else this.sample();
    }

    /** @param {{seq:number, t:number}} [origin] the model sample a reused verdict is copied from (provenance, 0.16) */
    record(frame, verdict, origin = null) {
        if (!this.samples.has(frame.seq)) {
            let at = this.sampleSeqs.length;                       // a background re-check can land behind newer samples
            while (at > 0 && this.sampleSeqs[at - 1] > frame.seq) at--;
            this.sampleSeqs.splice(at, 0, frame.seq);
        }
        this.samples.set(frame.seq, origin ? { v: verdict, t: frame.t, o: origin.o ?? origin.seq, h: origin.h ?? origin.t } : { v: verdict, t: frame.t });
        if (this.sampleSeqs.length > 256) for (const old of this.sampleSeqs.splice(0, 128)) this.samples.delete(old);
    }

    /**
     * Put a copied frame into the buffer (copies can finish out of order). Over the limits, thin the buffer instead of cutting its
     * oldest end: the oldest frames are the ones the display delay is about to reach (0.16; before, at 120 fps the 48 frames
     * spanned less than the 480 ms delay, so no frame was ever old enough to show — review of 0.15, finding 2). The frame
     * removed is the one closest in time to its neighbours; the oldest and the newest stay.
     */
    pushFrame(frame) {
        let at = this.frames.length;
        while (at > 0 && this.frames[at - 1].seq > frame.seq) at--;
        this.frames.splice(at, 0, frame);
        this.bytes += frame.bytes;
        while (this.frames.length > MAX_FRAMES || (this.bytes > MAX_BUFFER_BYTES && this.frames.length > 4)) {
            // The changed frame queued for the models is pinned: thinning never removes it (0.17 — review of 0.16, finding 1).
            let best = -1, gap = Infinity;
            for (let i = 1; i < this.frames.length - 1; i++) {
                if (!this.frames[i].bitmap || this.frames[i] === this.changed) continue;
                const g = this.frames[i + 1].t - this.frames[i - 1].t;
                if (g < gap) { gap = g; best = i; }
            }
            if (best < 0) { const old = this.frames.shift(); if (old === this.changed) { this.lostChange(old); this.changed = null; } this.drop(old); continue; }
            this.drop(this.frames.splice(best, 1)[0]);
        }
    }

    /**
     * A changed frame queued for the models could not be judged (its pixels are gone). Its change is not silently skipped: the
     * reuse anchor is dropped, so nothing after it is cleared by reuse — the next frame goes to the models (0.17).
     */
    lostChange(frame) {
        this.anchor = null;
    }

    /** Signature of a buffered frame (64 × 36). Shrunk on the GPU first, so only a small copy is read back. */
    signatureOf(bitmap) {
        if (!this.sigCtx) {
            this.sigMid = new OffscreenCanvas(256, 144).getContext('2d', { alpha: false });
            this.sigCtx = new OffscreenCanvas(SIG_W, SIG_H).getContext('2d', { willReadFrequently: true, alpha: false });
            for (const ctx of [this.sigMid, this.sigCtx]) { ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high'; }
        }
        this.sigMid.drawImage(bitmap, 0, 0, 256, 144);
        this.sigCtx.drawImage(this.sigMid.canvas, 0, 0, SIG_W, SIG_H);
        return signature(this.sigCtx.getImageData(0, 0, SIG_W, SIG_H).data);
    }

    /** May this buffered frame be shown sharp?  true / false, or null while the verdict is pending. */
    displayable(frame) {
        const { holdMs, tailMs } = this.deps.settings();
        return mayShow(frame, this.sampleSeqs, this.samples, this.cuts, holdMs, tailMs);
    }

    /** Is the frame on screen still allowed by the display rule? (A held / frozen frame must stay allowed.) */
    shownStillAllowed() {
        return !!this.shown && this.displayable({ seq: this.shown, t: this.shownT }) === true;
    }

    /** How late frames are shown. Automatic: about twice the time a verdict takes. Or fixed (settings.videoDelayMs). */
    delay() {
        const fixed = this.deps.settings().delayMs;
        if (fixed > 0) return Math.max(MIN_DELAY_MS, fixed);
        return Math.min(MAX_DELAY_MS, Math.max(MIN_DELAY_MS, 2.1 * this.latency + 30) + this.boost);
    }

    // --------------------------------------------------------------------------- display
    tick() {
        if (this.dead || !this.geometry) return;
        const video = this.video, now = performance.now();
        const live = !video.paused && !video.ended && !video.seeking;
        let target = null, sharp = false;
        const hold = () => {
            // Hold the last shown frame — only while the display rule still allows it — for at most freezeMs (0.15).
            if (!this.shown || !this.shownStillAllowed()) return false;
            if (!this.stallAt) this.stallAt = now;
            if (now - this.stallAt >= (this.deps.settings().freezeMs ?? STALL_MS)) return false;
            return true;
        };
        if (this.deps.locked(this.video)) {
            // the page is covered as a whole, or the viewer covered this video: stays blurred
        } else if (live) {
            const limit = now - this.delay();
            for (let i = this.frames.length - 1; i >= 0; i--) if (this.frames[i].t <= limit) { target = this.frames[i]; break; }
            if (!target) {
                // No buffered frame is old enough. With a frame on screen this is the display delay having grown (or a gap in
                // the copies): the timeline never steps back into dropped frames — the frame on screen is held while it stays
                // allowed, up to freezeMs (0.16; before, the screen blurred although every verdict was clear — review of 0.15,
                // finding 1). Without one, the video is just starting.
                if (hold()) return;
            } else {
                const reason = this.explainFrame(target);
                sharp = reason === 'ok';
                if (reason === 'pending' && !this.unreadable) {
                    this.boost = Math.min(240, this.boost + 12);          // verdicts are late: wait longer
                    if (hold()) return;
                } else {
                    this.stallAt = 0;
                    if (this.boost > 0) this.boost -= 0.25;
                }
            }
        } else {
            // A still frame is judged by its own sample; without one, the frame already on screen stays only while the display
            // rule still allows it (0.15: before, a shown frame stayed sharp on pause whatever its own sample said).
            target = this.frames[this.frames.length - 1] || null;
            const own = target && this.samples.get(target.seq);
            if (own) sharp = own.v !== 'b' && own.v !== 'w';
            else sharp = !!target && this.shown === target.seq && this.displayable(target) === true;
        }
        if (sharp) {
            if (this.shown !== target.seq && target.bitmap) {
                const { width, height } = target.bitmap;
                if (this.canvas.width !== width || this.canvas.height !== height) { this.canvas.width = width; this.canvas.height = height; }
                this.sharpCtx.transferFromImageBitmap(target.bitmap);       // zero-copy; the frame keeps its own resolution
                target.bitmap = null;
                this.bytes -= target.bytes; target.bytes = 0;
                const wasBlurred = !this.shown;
                this.shown = target.seq;
                this.shownMt = target.mt;
                this.shownT = target.t;
                this.stallAt = 0;
                if (wasBlurred) this.applyVisibility();
            } else if (this.shown !== target.seq) {
                sharp = false;                   // its pixels are gone (already displayed once)
            }
        }
        // Not allowed → blurred, also when the frame is the one already on screen (0.15: "already shown" no longer overrides a
        // rejection by the display rule).
        if (!sharp) this.showBlur(false, target);
        if (target) while (this.frames.length && this.frames[0].seq < target.seq) this.drop(this.frames.shift());
    }

    /** The display rule's answer for a frame, with its reason ('ok', 'pending', 'cover', 'hold', 'tail'). */
    explainFrame(frame) {
        const { holdMs, tailMs } = this.deps.settings();
        return explain(frame, this.sampleSeqs, this.samples, this.cuts, holdMs, tailMs);
    }

    /** Switch to the blur canvas and keep it fresh. */
    showBlur(force, frame) {
        const wasSharp = this.shown !== 0;
        if (wasSharp) {
            this.shown = 0;
            this.applyVisibility();
            try { this.sharpCtx.transferFromImageBitmap(null); } catch {}
        }
        this.drawBlur(force || wasSharp, frame);
    }

    /**
     * Draw a heavy blur of a frame (a tiny thumbnail stretched over the screen) plus a label. The frame is the buffered one the
     * screen would show now (the delayed timeline) when its pixels are still there; otherwise the live video. 0.15: before, the
     * live video was always drawn — content not yet checked.
     */
    drawBlur(force, frame = null) {
        const g = this.geometry;
        if (!g) return;
        const now = performance.now();
        if (!force && now - this.lastBlurAt < BLUR_REDRAW_MS) return;
        this.lastBlurAt = now;
        const ctx = this.ctx, settings = this.deps.settings(), video = this.video;
        ctx.clearRect(0, 0, g.bw, g.bh);
        let drawn = false;
        if (frame?.bitmap || (video.readyState >= 2 && video.videoWidth)) {
            const tw = Math.max(6, Math.min(48, Math.round(g.dw / (2.2 * (settings.blur || 28) * g.dpr))));
            const th = Math.max(4, Math.round(tw * g.dh / g.dw));
            if (this.tiny.width !== tw || this.tiny.height !== th) { this.tiny.width = tw; this.tiny.height = th; }
            try {
                this.tinyCtx.filter = settings.gray ? 'grayscale(1)' : 'none';
                const source = frame?.bitmap || video;
                this.tinyCtx.drawImage(source, 0, 0, tw, th);
                this.blurMt = frame?.bitmap ? frame.mt : video.currentTime;
                ctx.imageSmoothingEnabled = true;
                ctx.imageSmoothingQuality = 'high';
                ctx.drawImage(this.tiny, 0, 0, tw, th, g.dx, g.dy, g.dw, g.dh);
                drawn = true;
            } catch { /* fall through to the flat panel */ }
        }
        if (!drawn) { ctx.fillStyle = '#17191b'; ctx.fillRect(g.dx, g.dy, g.dw, g.dh); this.blurMt = frame ? frame.mt : video.currentTime; }
        this.drawLabel();
    }

    /**
     * The label: a small "LowerYourGaze" at the top left of the covered video, so the viewer knows the extension is covering it
     * (not a broken player). Drawn twice, in the app's green and in bright green, only when the size changes.
     */
    drawLabel() {
        const g = this.geometry;
        if (!g) return;
        const key = `${g.bw}x${g.bh}`;
        if (key === this.labelKey) return;
        this.labelKey = key;
        const size = Math.max(10, Math.round(12 * g.dpr));
        const font = `700 ${size}px Georgia, 'Times New Roman', serif`;
        const ctx = this.labelCtx, glow = this.glowCtx;
        ctx.clearRect(0, 0, g.bw, g.bh); glow.clearRect(0, 0, g.bw, g.bh);
        ctx.font = font;
        const pad = Math.round(size * 0.6), width = ctx.measureText('LowerYourGaze').width + 2 * pad, height = size + 2 * pad;
        if (g.dw < width + 3 * pad || g.dh < 3 * height) return;            // too small to carry a label
        const x = g.dx + pad * 1.5, y = g.dy + pad * 1.5;
        ctx.fillStyle = 'rgba(14, 20, 16, 0.62)';
        ctx.beginPath(); ctx.roundRect(x, y, width, height, height / 2); ctx.fill();
        for (const [c, colour] of [[ctx, LABEL_COLOUR], [glow, LABEL_GLOW]]) {
            c.font = font;
            c.textBaseline = 'middle';
            c.textAlign = 'left';
            c.fillStyle = colour;
            c.fillText('LowerYourGaze', x + pad, y + height / 2 + 1);
        }
    }

    // --------------------------------------------------------------------------- driving
    onFrame(now, metadata) {
        this.rvfc = 0;
        if (this.dead) return;
        if (this.deps.isActive() && this.deps.isNear(this.video) && !document.hidden) {
            this.capture(metadata?.mediaTime);
            this.tick();
        }
        this.arm();
    }

    arm() {
        if (this.dead || this.rvfc) return;
        this.rvfc = this.video.requestVideoFrameCallback(this.onFrame);
    }

    /** Something changed without a new frame being presented (pause, seek end, first data). */
    poke() {
        if (this.dead || !this.deps.isActive()) return;
        if (!this.geometry) { this.layout(); if (!this.geometry) return; }
        const video = this.video;
        const newest = this.frames[this.frames.length - 1];
        if ((video.paused || video.ended || !this.frames.length) && !this.pending && (!newest || newest.mt !== video.currentTime)) this.capture();
        this.tick();
        this.sample();
        this.arm();
    }

    housekeeping() {
        if (this.dead) return;
        if (!this.video.isConnected) { this.destroy(); return; }
        if (!this.layout()) return;
        if (this.video.mediaKeys) this.unreadable = true;
        this.tick();
        if (!this.sampling) this.sample();
    }

    destroy() {
        if (this.dead) return;
        this.dead = true;
        clearInterval(this.timer);
        this.resize.disconnect();
        try { if (this.rvfc) this.video.cancelVideoFrameCallback(this.rvfc); } catch {}
        for (const frame of this.frames) this.drop(frame);
        this.frames = [];
        document.removeEventListener('visibilitychange', this.onVisibility);
        this.pulse(false);
        for (const canvas of this.canvases) canvas.remove();
    }
}
