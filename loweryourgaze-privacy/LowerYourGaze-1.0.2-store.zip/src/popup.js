// LowerYourGaze — popup. AGPL-3.0.
import { DEFAULTS, STORAGE_KEY, COVER_KEY } from './shared/constants.js';
import { FEEDBACK_KEY } from './shared/feedback.js';

const $ = (id) => document.getElementById(id);
const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
let stored = {};                    // what is in storage: only the values that differ from DEFAULTS
let settings = { ...DEFAULTS };
let host = '';
let tabId = null;

// ------------------------------------------------------------------------------- storage
async function load() {
    stored = (await chrome.storage.local.get(STORAGE_KEY))[STORAGE_KEY] || {};
    settings = { ...DEFAULTS, ...stored };
    settings.context = settings.context === 'off' || settings.context === false ? 'off' : 'on';
}

/** Settings are stored sparsely: a value equal to its default is removed, so a later default change reaches it. */
async function save(patch) {
    const next = { ...stored, ...patch };
    for (const key of Object.keys(next)) if (key in DEFAULTS && same(next[key], DEFAULTS[key])) delete next[key];
    stored = next;
    settings = { ...DEFAULTS, ...next };
    await chrome.storage.local.set({ [STORAGE_KEY]: next });
    render();
}

const siteChoice = () => (settings.sites || {})[host] || ((settings.paused || []).includes(host) ? 'off' : 'normal');

// ------------------------------------------------------------------------------- render
function format(output, value) {
    const d = output.dataset;
    if (Number(value) === 0 && d.zero) return d.zero;
    const shown = Number(value) * Number(d.scale || 1);
    const text = d.digits ? shown.toFixed(Number(d.digits)) : String(Math.round(shown));
    return d.unit ? `${text} ${d.unit}` : text;
}

function paintRange(input) {
    const min = Number(input.min), max = Number(input.max), value = Number(input.value);
    input.style.setProperty('--p', `${((value - min) / (max - min)) * 100}%`);
    const output = input.parentElement.querySelector('output');
    if (output) output.textContent = format(output, value);
}

function render() {
    // This site
    const choice = siteChoice();
    const state = !host ? 'na' : settings.enabled && choice !== 'off' ? 'on' : 'off';
    $('hero').dataset.state = state;
    $('eye').src = state === 'on' ? '../icons/logo-on.svg' : '../icons/logo-off.svg';
    $('host').textContent = host || 'This page';
    $('state').textContent = state === 'na' ? 'Pages like this one are not filtered'
        : state === 'on' ? (choice === 'all' ? 'Covering everything here' : choice === 'anyone' ? 'Covering everyone here' : 'Filtering is on')
        : settings.enabled ? 'Off on this site' : 'Off on all sites';
    $('site-on').checked = state === 'on';
    $('site-on').disabled = !host;
    const note = $('hero-note');
    note.hidden = settings.enabled;
    if (!settings.enabled) {
        note.textContent = 'LowerYourGaze is paused on all sites. ';
        const button = document.createElement('button');
        button.type = 'button'; button.textContent = 'Turn it back on';
        button.addEventListener('click', () => save({ enabled: true }));
        note.append(button);
    }

    // Bound controls
    for (const group of document.querySelectorAll('.seg[data-key]')) {
        for (const button of group.querySelectorAll('button')) button.setAttribute('aria-checked', String(button.value === String(settings[group.dataset.key])));
    }
    for (const input of document.querySelectorAll('input[type=checkbox][data-key]')) {
        input.checked = input.dataset.on ? settings[input.dataset.key] === input.dataset.on : !!settings[input.dataset.key];
    }
    for (const input of document.querySelectorAll('input[type=range][data-key]')) {
        input.value = settings[input.dataset.key];
        paintRange(input);
    }

    // Site mode
    for (const button of $('site-mode').querySelectorAll('button')) {
        button.setAttribute('aria-checked', String(button.value === (choice === 'off' ? '' : choice)));
        button.disabled = !host || state !== 'on';
    }
    for (const button of document.querySelectorAll('button[data-video]')) button.disabled = tabId === null || state !== 'on';

    // Video: show only what applies to the chosen check
    const verified = settings.videoMode !== 'direct';
    for (const row of document.querySelectorAll('[data-for]')) row.hidden = (row.dataset.for === 'verified') !== verified;
    $('reuse-params').hidden = !verified;
    $('reuse-params').classList.toggle('dim', settings.videoSimilar === 'off');
    $('video-desc').textContent = verified
        ? 'Before: frames are checked before you see them.'
        : 'After: plays at once and blurs when a check finds something.';
}

// ------------------------------------------------------------------------------- status
const setText = (el, text) => { if (el.textContent !== text) el.textContent = text; };    // no layout work when unchanged

async function refreshStatus() {
    const text = $('status'), dot = $('dot'), speed = $('speed');
    try {
        await chrome.runtime.sendMessage({ t: 'lyg-ensure' });
        const s = await chrome.runtime.sendMessage({ t: 'lyg-stats' });
        if (!s || !s.backend) {
            setText(speed, '');
            if (s?.error) { dot.dataset.s = 'bad'; setText(text, 'The detector could not start'); text.title = 'Everything stays blurred until it starts. Restarting the browser usually helps.'; return; }
            dot.dataset.s = ''; setText(text, s?.restarts ? 'Restarting the detector…' : 'Starting the detector…'); return;
        }
        if (s.runError) {            // the run-time watchdog reached its restart limit: pictures stay covered
            dot.dataset.s = 'bad'; setText(speed, '');
            setText(text, 'The detector stopped responding');
            text.title = 'Pictures stay covered. Restarting the browser starts it again.';
            return;
        }
        dot.dataset.s = 'ok';
        setText(text, 'Ready');
        text.title = `Checks run on this device: CPU, ${s.threads} thread${s.threads === 1 ? '' : 's'}.`;
        setText(speed, s.medianMs != null ? `${s.medianMs} ms/img` : '');
    } catch {
        dot.dataset.s = 'bad'; setText(text, 'The detector is not reachable'); setText(speed, '');
    }
}

// ------------------------------------------------------------------------------- two-step buttons
function confirmable(button, run, doneText) {
    const idle = button.textContent;
    let timer = 0;
    button.addEventListener('click', async () => {
        if (button.dataset.armed !== '1') {
            button.dataset.armed = '1';
            button.textContent = 'Click again to confirm';
            timer = setTimeout(() => { delete button.dataset.armed; button.textContent = idle; }, 4000);
            return;
        }
        clearTimeout(timer);
        delete button.dataset.armed;
        button.disabled = true;
        try { await run(); button.textContent = doneText; } catch { button.textContent = 'Could not finish, try again'; }
        button.dataset.done = '1';
        setTimeout(() => { delete button.dataset.done; button.textContent = idle; button.disabled = false; }, 2500);
    });
}

// ------------------------------------------------------------------------------- start
async function init() {
    await load();
    try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        const url = new URL(tab?.url || '');
        if (/^https?:$/.test(url.protocol)) { host = url.hostname.replace(/^www\./, ''); tabId = tab.id; }
    } catch {}
    render();

    // Tabs
    const tabs = [[$('tab-main'), $('panel-main')], [$('tab-adv'), $('panel-adv')]];
    for (const [tab] of tabs) {
        tab.addEventListener('click', () => {
            for (const [other, panel] of tabs) { const on = other === tab; other.setAttribute('aria-selected', String(on)); panel.hidden = !on; }
        });
    }

    // This site on / off
    $('site-on').addEventListener('change', (event) => {
        if (!host) return;
        const sites = { ...(settings.sites || {}) };
        const paused = (settings.paused || []).filter((h) => h !== host);
        if (event.target.checked) { if (sites[host] === 'off') delete sites[host]; save({ enabled: true, sites, paused }); }
        else { sites[host] = 'off'; save({ sites, paused }); }
    });
    for (const button of $('site-mode').querySelectorAll('button')) {
        button.addEventListener('click', () => {
            if (!host) return;
            const sites = { ...(settings.sites || {}) };
            if (button.value === 'normal') delete sites[host]; else sites[host] = button.value;
            save({ sites });
        });
    }

    // Bound controls
    for (const group of document.querySelectorAll('.seg[data-key]')) {
        for (const button of group.querySelectorAll('button')) button.addEventListener('click', () => save({ [group.dataset.key]: button.value }));
    }
    for (const input of document.querySelectorAll('input[type=checkbox][data-key]')) {
        input.addEventListener('change', () => save({ [input.dataset.key]: input.dataset.on ? (input.checked ? input.dataset.on : input.dataset.off) : input.checked }));
    }
    for (const input of document.querySelectorAll('input[type=range][data-key]')) {
        input.addEventListener('input', () => paintRange(input));
        input.addEventListener('change', () => save({ [input.dataset.key]: Number(input.value) }));
    }

    // Main video on this page
    for (const button of document.querySelectorAll('button[data-video]')) {
        button.addEventListener('click', async () => {
            let done = [];
            try { done = (await chrome.tabs.sendMessage(tabId, { t: 'lyg-choice', kind: 'video', mode: button.dataset.video, main: true }))?.done || []; } catch {}
            $('video-note').textContent = done.length
                ? { show: 'Shown until this video changes.', cover: 'Covered until this video changes.', auto: 'The check decides again.' }[button.dataset.video]
                : 'No video found on this page.';
        });
    }

    // Reset
    confirmable($('reset'), async () => {
        await chrome.storage.local.set({ [STORAGE_KEY]: { ...(stored.sites ? { sites: stored.sites } : {}), ...(stored.paused ? { paused: stored.paused } : {}) } });
        await load();
        render();
    }, 'Options reset');
    confirmable($('forget'), async () => {
        await chrome.storage.local.remove([FEEDBACK_KEY, COVER_KEY]);
        await chrome.runtime.sendMessage({ t: 'lyg-ensure' });
        await chrome.runtime.sendMessage({ t: 'lyg-clear-cache' });
    }, 'Learning memory deleted');

    $('guide').addEventListener('click', () => { chrome.tabs.create({ url: chrome.runtime.getURL('src/welcome.html') }); window.close(); });

    refreshStatus();
    setInterval(refreshStatus, 2000);
}
init();
