/* ==========================================================================
   MDP Network Animation for Hero Section
   Displays an animated Markov Decision Process visualization with:
   - States as glowing nodes (cyan)
   - Transitions as animated directional lines
   - Reward signals as pulsing gold highlights
   - Value gradients shown through node intensity
   ========================================================================== */

(function() {
  'use strict';

  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  
  if (prefersReducedMotion) {
    return;
  }

  // Color palette matching our CSS variables
  const COLORS = {
    dark: {
      state: '#00d4ff',
      stateGlow: 'rgba(0, 212, 255, 0.3)',
      reward: '#ffb800',
      rewardGlow: 'rgba(255, 184, 0, 0.4)',
      value: '#a855f7',
      valueGlow: 'rgba(168, 85, 247, 0.3)',
      action: '#10b981',
      transition: 'rgba(0, 212, 255, 0.15)',
      transitionActive: 'rgba(0, 212, 255, 0.4)',
      background: '#0a0e14'
    },
    light: {
      state: '#0096c8',
      stateGlow: 'rgba(0, 150, 200, 0.25)',
      reward: '#d97706',
      rewardGlow: 'rgba(217, 119, 6, 0.35)',
      value: '#7c3aed',
      valueGlow: 'rgba(124, 58, 237, 0.25)',
      action: '#059669',
      transition: 'rgba(0, 150, 200, 0.1)',
      transitionActive: 'rgba(0, 150, 200, 0.3)',
      background: '#fafbfc'
    }
  };

  class State {
    constructor(canvas, options, index, totalStates) {
      this.canvas = canvas;
      this.options = options;
      this.index = index;
      
      // Position states in a more structured way
      this.x = Math.random() * canvas.width;
      this.y = Math.random() * canvas.height;
      
      // Slower, more deliberate movement
      this.vx = (Math.random() - 0.5) * options.speed * 0.5;
      this.vy = (Math.random() - 0.5) * options.speed * 0.5;
      
      // State properties
      this.radius = Math.random() * 4 + 6; // Larger nodes
      this.value = Math.random(); // Simulated value function
      this.isTerminal = Math.random() < 0.1; // 10% chance terminal state
      this.rewardPulse = 0; // For reward animation
      this.pulsePhase = Math.random() * Math.PI * 2;
      
      // Connections to other states (will be populated later)
      this.connections = [];
    }

    update(time) {
      // Gentle floating motion
      this.x += this.vx + Math.sin(time * 0.001 + this.pulsePhase) * 0.2;
      this.y += this.vy + Math.cos(time * 0.001 + this.pulsePhase) * 0.2;

      // Soft boundary bouncing
      const padding = 50;
      if (this.x < padding || this.x > this.canvas.width - padding) {
        this.vx = -this.vx * 0.8;
        this.x = Math.max(padding, Math.min(this.canvas.width - padding, this.x));
      }
      if (this.y < padding || this.y > this.canvas.height - padding) {
        this.vy = -this.vy * 0.8;
        this.y = Math.max(padding, Math.min(this.canvas.height - padding, this.y));
      }

      // Decay reward pulse
      if (this.rewardPulse > 0) {
        this.rewardPulse *= 0.95;
      }
    }

    triggerReward() {
      this.rewardPulse = 1;
    }

    draw(ctx, colors, time) {
      const pulse = 1 + Math.sin(time * 0.003 + this.pulsePhase) * 0.1;
      const baseRadius = this.radius * pulse;
      
      // Outer glow based on value
      const glowRadius = baseRadius * (2 + this.value);
      const gradient = ctx.createRadialGradient(
        this.x, this.y, 0,
        this.x, this.y, glowRadius
      );
      
      if (this.rewardPulse > 0) {
        // Reward pulse - gold glow
        gradient.addColorStop(0, this.hexToRgba(colors.reward, 0.4 * this.rewardPulse));
        gradient.addColorStop(0.5, this.hexToRgba(colors.rewardGlow, 0.2 * this.rewardPulse));
        gradient.addColorStop(1, 'transparent');
      } else if (this.isTerminal) {
        // Terminal state - violet glow
        gradient.addColorStop(0, this.hexToRgba(colors.value, 0.3));
        gradient.addColorStop(0.5, this.hexToRgba(colors.valueGlow, 0.15));
        gradient.addColorStop(1, 'transparent');
      } else {
        // Regular state - cyan glow based on value
        const intensity = 0.15 + this.value * 0.2;
        gradient.addColorStop(0, this.hexToRgba(colors.state, intensity));
        gradient.addColorStop(0.5, this.hexToRgba(colors.stateGlow, intensity * 0.5));
        gradient.addColorStop(1, 'transparent');
      }
      
      ctx.beginPath();
      ctx.arc(this.x, this.y, glowRadius, 0, Math.PI * 2);
      ctx.fillStyle = gradient;
      ctx.fill();

      // Inner core
      ctx.beginPath();
      ctx.arc(this.x, this.y, baseRadius, 0, Math.PI * 2);
      
      if (this.rewardPulse > 0) {
        ctx.fillStyle = this.hexToRgba(colors.reward, 0.6 + this.rewardPulse * 0.4);
      } else if (this.isTerminal) {
        ctx.fillStyle = this.hexToRgba(colors.value, 0.7);
      } else {
        ctx.fillStyle = this.hexToRgba(colors.state, 0.4 + this.value * 0.3);
      }
      ctx.fill();
      
      // Bright center point
      ctx.beginPath();
      ctx.arc(this.x, this.y, baseRadius * 0.3, 0, Math.PI * 2);
      if (this.rewardPulse > 0) {
        ctx.fillStyle = colors.reward;
      } else if (this.isTerminal) {
        ctx.fillStyle = colors.value;
      } else {
        ctx.fillStyle = colors.state;
      }
      ctx.fill();
    }

    hexToRgba(color, alpha) {
      if (color.startsWith('rgba')) return color;
      if (color.startsWith('rgb')) {
        return color.replace('rgb', 'rgba').replace(')', `, ${alpha})`);
      }
      const r = parseInt(color.slice(1, 3), 16);
      const g = parseInt(color.slice(3, 5), 16);
      const b = parseInt(color.slice(5, 7), 16);
      return `rgba(${r}, ${g}, ${b}, ${alpha})`;
    }
  }

  class Transition {
    constructor(fromState, toState) {
      this.from = fromState;
      this.to = toState;
      this.progress = Math.random(); // Animation progress
      this.speed = 0.002 + Math.random() * 0.003;
      this.active = false;
      this.activeTime = 0;
    }

    update(time) {
      this.progress += this.speed;
      if (this.progress > 1) {
        this.progress = 0;
        // Small chance to trigger reward on destination
        if (Math.random() < 0.02) {
          this.to.triggerReward();
          this.active = true;
          this.activeTime = time;
        }
      }
      
      // Decay active state
      if (this.active && time - this.activeTime > 500) {
        this.active = false;
      }
    }

    draw(ctx, colors, time) {
      const dx = this.to.x - this.from.x;
      const dy = this.to.y - this.from.y;
      const distance = Math.sqrt(dx * dx + dy * dy);
      
      if (distance < 50 || distance > 300) return; // Skip if too close or too far

      // Draw base transition line
      ctx.beginPath();
      ctx.moveTo(this.from.x, this.from.y);
      ctx.lineTo(this.to.x, this.to.y);
      ctx.strokeStyle = this.active ? colors.transitionActive : colors.transition;
      ctx.lineWidth = this.active ? 2 : 1;
      ctx.stroke();

      // Draw animated particle along transition
      const particleX = this.from.x + dx * this.progress;
      const particleY = this.from.y + dy * this.progress;
      
      ctx.beginPath();
      ctx.arc(particleX, particleY, 3, 0, Math.PI * 2);
      ctx.fillStyle = this.active ? colors.reward : colors.action;
      ctx.fill();

      // Draw small arrowhead at midpoint
      const midX = this.from.x + dx * 0.6;
      const midY = this.from.y + dy * 0.6;
      const angle = Math.atan2(dy, dx);
      const arrowSize = 6;
      
      ctx.beginPath();
      ctx.moveTo(midX, midY);
      ctx.lineTo(
        midX - arrowSize * Math.cos(angle - Math.PI / 6),
        midY - arrowSize * Math.sin(angle - Math.PI / 6)
      );
      ctx.lineTo(
        midX - arrowSize * Math.cos(angle + Math.PI / 6),
        midY - arrowSize * Math.sin(angle + Math.PI / 6)
      );
      ctx.closePath();
      ctx.fillStyle = this.active ? colors.transitionActive : colors.transition;
      ctx.fill();
    }
  }

  class MDPNetwork {
    constructor(canvasId, options = {}) {
      this.canvas = document.getElementById(canvasId);
      if (!this.canvas) return;

      this.ctx = this.canvas.getContext('2d');
      this.states = [];
      this.transitions = [];
      this.animationId = null;
      this.isRunning = false;
      this.time = 0;

      this.options = {
        stateDensity: options.stateDensity || 0.000025,
        minStates: options.minStates || 15,
        maxStates: options.maxStates || 40,
        speed: options.speed || 0.3,
        connectionProbability: options.connectionProbability || 0.15,
        ...options
      };

      this.init();
    }

    getColors() {
      const theme = document.documentElement.getAttribute('data-theme') || 'dark';
      return COLORS[theme] || COLORS.dark;
    }

    calculateStateCount() {
      const area = this.canvas.width * this.canvas.height;
      let count = Math.floor(area * this.options.stateDensity);
      return Math.max(this.options.minStates, Math.min(this.options.maxStates, count));
    }

    init() {
      this.resize();
      this.createNetwork();
      this.bindEvents();
      this.start();
    }

    resize() {
      const rect = this.canvas.parentElement.getBoundingClientRect();
      this.canvas.width = rect.width;
      this.canvas.height = rect.height;
    }

    createNetwork() {
      this.states = [];
      this.transitions = [];
      
      const stateCount = this.calculateStateCount();
      
      // Create states
      for (let i = 0; i < stateCount; i++) {
        this.states.push(new State(this.canvas, this.options, i, stateCount));
      }

      // Create transitions (connections between states)
      for (let i = 0; i < this.states.length; i++) {
        for (let j = 0; j < this.states.length; j++) {
          if (i !== j && Math.random() < this.options.connectionProbability) {
            const dx = this.states[j].x - this.states[i].x;
            const dy = this.states[j].y - this.states[i].y;
            const distance = Math.sqrt(dx * dx + dy * dy);
            
            // Only connect nearby states
            if (distance < 250) {
              this.transitions.push(new Transition(this.states[i], this.states[j]));
            }
          }
        }
      }
    }

    drawGrid() {
      const colors = this.getColors();
      const gridSize = 50;
      
      this.ctx.strokeStyle = 'rgba(30, 42, 58, 0.3)';
      this.ctx.lineWidth = 0.5;
      
      // Vertical lines
      for (let x = 0; x < this.canvas.width; x += gridSize) {
        this.ctx.beginPath();
        this.ctx.moveTo(x, 0);
        this.ctx.lineTo(x, this.canvas.height);
        this.ctx.stroke();
      }
      
      // Horizontal lines
      for (let y = 0; y < this.canvas.height; y += gridSize) {
        this.ctx.beginPath();
        this.ctx.moveTo(0, y);
        this.ctx.lineTo(this.canvas.width, y);
        this.ctx.stroke();
      }
    }

    draw() {
      const colors = this.getColors();
      
      // Clear with slight fade for trail effect
      this.ctx.fillStyle = colors.background;
      this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
      
      // Draw subtle grid
      this.drawGrid();

      // Update and draw transitions first (behind states)
      this.transitions.forEach(transition => {
        transition.update(this.time);
        transition.draw(this.ctx, colors, this.time);
      });

      // Update and draw states
      this.states.forEach(state => {
        state.update(this.time);
        state.draw(this.ctx, colors, this.time);
      });

      this.time += 16; // Approximate frame time
    }

    animate() {
      if (!this.isRunning) return;
      
      this.draw();
      this.animationId = requestAnimationFrame(() => this.animate());
    }

    start() {
      if (this.isRunning) return;
      this.isRunning = true;
      this.animate();
    }

    stop() {
      this.isRunning = false;
      if (this.animationId) {
        cancelAnimationFrame(this.animationId);
        this.animationId = null;
      }
    }

    bindEvents() {
      let resizeTimeout;
      window.addEventListener('resize', () => {
        clearTimeout(resizeTimeout);
        resizeTimeout = setTimeout(() => {
          this.resize();
          this.createNetwork();
        }, 250);
      });

      document.addEventListener('visibilitychange', () => {
        if (document.hidden) {
          this.stop();
        } else {
          this.start();
        }
      });

      const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            this.start();
          } else {
            this.stop();
          }
        });
      }, { threshold: 0.1 });

      observer.observe(this.canvas);

      // Trigger random rewards occasionally
      setInterval(() => {
        if (this.isRunning && this.states.length > 0) {
          const randomState = this.states[Math.floor(Math.random() * this.states.length)];
          if (Math.random() < 0.3) {
            randomState.triggerReward();
          }
        }
      }, 2000);
    }

    destroy() {
      this.stop();
    }
  }

  // Initialize when DOM is ready
  document.addEventListener('DOMContentLoaded', () => {
    const heroCanvas = document.getElementById('hero-particles');
    if (heroCanvas) {
      new MDPNetwork('hero-particles', {
        stateDensity: 0.00003,
        minStates: 20,
        maxStates: 50,
        speed: 0.25,
        connectionProbability: 0.12
      });
    }
  });

  window.MDPNetwork = MDPNetwork;

})();
